package com.prabhu.gamebooster

import android.content.Context
import android.graphics.*
import android.view.View

/**
 * GT animation, drawn live.
 *  welcome = true : "WELCOME TO  GT"                         (app opening)
 *  welcome = false: "GT MODE ACTIVATING" -> "IMPROVING GAME" (Free Fire India launch)
 * Driven by update(seconds).
 */
class GtModeBurst(c: Context, private val welcome: Boolean) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var u = 0f
    fun update(sec: Float) { u = sec; invalidate() }

    private fun backOut(x: Float): Float { val t = x.coerceIn(0f, 1f) - 1f; val k = 1.9f; return 1f + t * t * ((k + 1f) * t + k) }
    private fun ss(a: Float, b: Float, x: Float): Float { val k = ((x - a) / (b - a)).coerceIn(0f, 1f); return k * k * (3f - 2f * k) }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val d = Util.dp(context, 1).toFloat()
        val cx = w / 2f; val cy = h * 0.46f
        cv.drawColor(Color.parseColor("#07080B"))
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, maxOf(w, h) * 0.6f, intArrayOf(Util.alpha(Util.ACC, 0x55), Util.alpha(Util.ACC2, 0x18), Color.TRANSPARENT),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, p); p.shader = null

        // sweeping slanted slash
        val sw = ((u - 0.05f) / 0.55f).coerceIn(0f, 1f)
        if (sw > 0f && sw < 1f) {
            p.color = Util.alpha(Util.ACC, (0x66 * (1f - sw)).toInt())
            val x = -w * 0.2f + w * 1.4f * sw
            path.reset(); path.moveTo(x, 0f); path.lineTo(x + w * 0.09f, 0f); path.lineTo(x - w * 0.06f, h); path.lineTo(x - w * 0.15f, h); path.close()
            cv.drawPath(path, p)
        }
        // shockwave rings
        p.style = Paint.Style.STROKE
        for (i in 0..2) {
            val tt = (u / 1.3f - i * 0.16f)
            if (tt <= 0f || tt >= 1f) continue
            p.strokeWidth = d * (6f - 4f * tt); p.color = Util.alpha(Util.ACC, (200 * (1f - tt)).toInt())
            cv.drawCircle(cx, cy, maxOf(w, h) * 0.55f * tt, p)
        }
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER

        // ---- GT letters ----
        val gtSize = if (welcome) 0.42f else 0.36f
        val sc = backOut((u - (if (welcome) 0.25f else 0f)) / 0.5f)
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC); p.letterSpacing = 0.1f
        p.textSize = h * gtSize * sc.coerceAtLeast(0.01f)
        val base = cy + p.textSize * 0.32f
        p.style = Paint.Style.STROKE; p.strokeWidth = d * 10f; p.color = Util.alpha(Util.ACC, 0x40); cv.drawText("GT", cx, base, p)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(cx - w * 0.15f, 0f, cx + w * 0.15f, 0f, Util.ACC, Util.ACC2, Shader.TileMode.CLAMP)
        cv.drawText("GT", cx, base, p); p.shader = null

        if (welcome) {
            val a1 = ss(0f, 0.35f, u)
            p.typeface = Util.HEAD; p.textSize = h * 0.07f; p.letterSpacing = 0.4f; p.color = Color.argb((255 * a1).toInt(), 255, 255, 255)
            cv.drawText("WELCOME  TO", cx, cy - h * 0.33f - (1f - a1) * h * 0.05f, p)
            val a2 = ss(0.9f, 1.4f, u)
            p.typeface = Util.BOLD; p.textSize = h * 0.04f; p.letterSpacing = 0.3f; p.color = Util.alpha(Util.MUTED, (255 * a2).toInt())
            cv.drawText("PRABHU GAME BOOSTER", cx, cy + h * 0.34f, p)
        } else {
            // status text: ACTIVATING -> IMPROVING GAME
            val first = u < 1.5f
            val a = if (first) ss(0.35f, 0.7f, u) else ss(1.5f, 1.8f, u)
            val dots = ".".repeat(((u * 4f).toInt() % 4))
            p.typeface = Util.HEAD; p.textSize = h * 0.07f; p.letterSpacing = 0.3f; p.color = Color.argb((255 * a).toInt(), 255, 255, 255)
            cv.drawText(if (first) "GT MODE ACTIVATING$dots" else "IMPROVING GAME$dots", cx, cy + h * 0.31f, p)
            p.typeface = Util.BOLD; p.textSize = h * 0.035f; p.letterSpacing = 0.25f; p.color = Util.alpha(Util.MUTED, (255 * ss(0.7f, 1.1f, u)).toInt())
            cv.drawText(Util.GAME_NAME.uppercase(), cx, cy + h * 0.39f, p)
            // progress bar + percent
            val bw = w * 0.36f; val by = h * 0.90f; val pr = (u / 2.2f).coerceIn(0f, 1f)
            p.letterSpacing = 0f; p.color = Color.parseColor("#262932"); cv.drawRoundRect(cx - bw / 2, by, cx + bw / 2, by + d * 5f, d * 3f, d * 3f, p)
            p.shader = LinearGradient(cx - bw / 2, 0f, cx + bw / 2, 0f, Util.ACC, Util.ACC2, Shader.TileMode.CLAMP)
            cv.drawRoundRect(cx - bw / 2, by, cx - bw / 2 + bw * pr, by + d * 5f, d * 3f, d * 3f, p); p.shader = null
            p.typeface = Util.BOLD; p.textSize = h * 0.032f; p.color = Util.ACC
            cv.drawText("${(pr * 100).toInt()}%", cx, by - d * 8f, p)
        }
    }
}
