package com.prabhu.gamebooster

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout

/**
 * Full-screen overlay shown just before Free Fire India opens: "GT MODE ACTIVATING" -> "IMPROVING GAME" (about 2.8 s).
 * The game is launched under the animation at ~2.2 s, then the overlay fades out.
 * (The "WELCOME TO GT" animation when the app opens is played inside MainActivity.)
 */
object GtIntro {
    @Volatile private var playing = false
    private const val DUR_MS = 2800L
    private const val LAUNCH_AT = 2200L
    private const val FADE_AT = 2650L

    fun play(ctx: Context, launch: () -> Boolean, onFail: () -> Unit) {
        val c = ctx.applicationContext
        if (playing) return
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(c)) { if (!launch()) onFail(); return }
        playing = true
        val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val h = Handler(Looper.getMainLooper())

        val root = FrameLayout(c).apply { setBackgroundColor(Color.parseColor("#FF07080B")); alpha = 0f; setOnTouchListener { _, _ -> true } }
        val gt = GtModeBurst(c, false)
        root.addView(gt, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT)
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        try { wm.addView(root, lp) } catch (e: Exception) { playing = false; if (!launch()) onFail(); return }

        var anim: ValueAnimator? = null
        fun remove() {
            anim?.cancel()
            try { wm.removeView(root) } catch (e: Exception) {}
            playing = false
        }

        root.animate().alpha(1f).setDuration(120).start()
        anim = ValueAnimator.ofFloat(0f, DUR_MS / 1000f).apply {
            duration = DUR_MS; interpolator = LinearInterpolator()
            addUpdateListener { gt.update(it.animatedValue as Float) }
            start()
        }
        h.postDelayed({ if (!launch()) { onFail(); remove() } }, LAUNCH_AT)
        h.postDelayed({ root.animate().alpha(0f).setDuration(450).withEndAction { remove() }.start() }, FADE_AT)
        h.postDelayed({ remove() }, 6000)   // safety: never leave the screen covered
    }
}
