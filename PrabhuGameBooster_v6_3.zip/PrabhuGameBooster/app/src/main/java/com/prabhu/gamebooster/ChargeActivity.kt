package com.prabhu.gamebooster

import android.app.Activity
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Dark, dim charging screen. Leave the phone idle while it charges. Tap anywhere to exit. */
class ChargeActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var pct: TextView
    private lateinit var state: TextView
    private lateinit var info: TextView
    private var alive = true

    @Suppress("DEPRECATION")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Util.initTheme(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val wl = window.attributes; wl.screenBrightness = 0.01f; window.attributes = wl
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LOW_PROFILE

        fun tv(sz: Float, col: Int, bold: Boolean = false) = TextView(this).apply {
            textSize = sz; setTextColor(col); gravity = Gravity.CENTER
            if (bold) typeface = Util.BOLD
        }
        pct = tv(72f, Util.ACC, true); state = tv(16f, Color.WHITE, true); info = tv(13f, Util.MUTED)
        info.setPadding(0, Util.dp(this, 8), 0, Util.dp(this, 20))
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(Color.BLACK)
            addView(tv(30f, Util.ACC)); addView(pct); addView(state); addView(info)
            addView(tv(11f, Color.parseColor("#555B68")).apply { text = "Leave the phone idle for the fastest charge.\nTap anywhere to exit." })
            setOnClickListener { finish() }
        }
        (col.getChildAt(0) as TextView).text = "⚡"
        setContentView(col)
        tick()
    }

    private fun tick() {
        if (!alive) return
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (bi != null) {
            val lv = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, 0); val sc = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val st = bi.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val plugged = bi.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            val temp = bi.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
            val mv = bi.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
            pct.text = "${lv * 100 / sc}%"
            state.text = when {
                st == BatteryManager.BATTERY_STATUS_FULL -> "FULLY CHARGED"
                plugged -> "CHARGING"
                else -> "NOT CHARGING - plug in the charger"
            }
            val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
            val ua = Math.abs(bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))
            val watts = mv / 1000.0 * ua / 1_000_000.0
            val left = if (Build.VERSION.SDK_INT >= 28) bm.computeChargeTimeRemaining() else -1L
            info.text = "%.1f°C".format(temp) + (if (plugged && ua > 0) "   |   ~%.1f W".format(watts) else "") +
                (if (plugged && left > 0) "   |   ${left / 60000} min to full" else "")
        }
        h.postDelayed({ tick() }, 2000)
    }

    override fun onDestroy() { alive = false; h.removeCallbacksAndMessages(null); super.onDestroy() }
}
