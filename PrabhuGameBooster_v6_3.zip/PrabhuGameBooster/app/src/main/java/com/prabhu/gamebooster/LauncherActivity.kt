package com.prabhu.gamebooster

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.GridView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * GT Launcher: a home screen (app drawer grid) where EVERY app can get your own logo + name.
 * Set it as your default Home app (Super Base > "Use as home launcher") and the new logos show on your home screen.
 */
class LauncherActivity : Activity() {
    private class Entry(val pkg: String, val label: String, val bmp: Bitmap)

    private var all: List<Entry> = emptyList()
    private var shown: List<Entry> = emptyList()
    private var showHidden = false
    private lateinit var grid: GridView
    private lateinit var search: EditText
    private val adapter = Adapter()
    private val placeholder: Bitmap by lazy { Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888) }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { reload() }
    }

    private fun dp(v: Int) = Util.dp(this, v)
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Apps.load(this)
        Util.initTheme(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(110, 0, 0, 0))
            setPadding(dp(10), dp(8), dp(10), dp(4))
            isFocusableInTouchMode = true
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        search = EditText(this).apply {
            hint = "Search apps"; setHintTextColor(Util.MUTED); setTextColor(Color.WHITE); textSize = 13f
            setSingleLine(); setPadding(dp(14), dp(9), dp(14), dp(9)); background = Util.glass(this@LauncherActivity, 20)
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { applyFilter() }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
        }
        bar.addView(search, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(barBtn("⚡") { startActivity(Intent(this, MainActivity::class.java)) })
        bar.addView(barBtn("⋮") { menu() })
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        grid = GridView(this).apply {
            adapter = this@LauncherActivity.adapter
            selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            verticalSpacing = dp(6); horizontalSpacing = dp(2); stretchMode = GridView.STRETCH_COLUMN_WIDTH
            setOnItemClickListener { _, _, pos, _ -> launch(shown[pos]) }
            setOnItemLongClickListener { _, _, pos, _ -> itemMenu(shown[pos]); true }
        }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(8) })
        setContentView(root)
        setColumns()
        root.requestFocus()
    }

    private fun barBtn(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        background = Util.glass(this@LauncherActivity, 20)
        layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply { leftMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun setColumns() {
        grid.numColumns = maxOf(3, resources.displayMetrics.widthPixels / dp(86))
    }

    override fun onConfigurationChanged(c: Configuration) { super.onConfigurationChanged(c); setColumns() }

    override fun onStart() {
        super.onStart()
        Apps.load(this)
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        }
        try { registerReceiver(pkgReceiver, f) } catch (e: Exception) {}
        reload()
    }

    override fun onStop() {
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) {}
        super.onStop()
    }

    // pressing Home again: back to the top, search cleared
    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        search.setText(""); grid.setSelection(0)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (search.text.isNotEmpty()) search.setText("") }

    // ---------------- list ----------------
    private fun reload() {
        Thread {
            val hidden = Apps.hidden(this)
            val items = ArrayList<Entry>()
            items.add(Entry(packageName, Apps.label(this, packageName), Apps.iconBitmap(this, packageName, 144)))
            for (it in Apps.launchables(this)) {
                if (!showHidden && it.pkg in hidden) continue
                items.add(Entry(it.pkg, Apps.label(this, it.pkg), Apps.iconBitmap(this, it.pkg, 144)))
            }
            items.sortBy { it.label.lowercase() }
            runOnUiThread { if (!isFinishing) { all = items; applyFilter() } }
        }.start()
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        shown = if (q.isEmpty()) all else all.filter { it.label.lowercase().contains(q) }
        adapter.notifyDataSetChanged()
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int): Any = shown[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val v = (cv as? LinearLayout) ?: LinearLayout(this@LauncherActivity).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(2), dp(6), dp(2), dp(4))
                addView(AppPicker.iconView(this@LauncherActivity, "", 54, placeholder))
                addView(TextView(this@LauncherActivity).apply {
                    textSize = 10.5f; setTextColor(Color.WHITE); maxLines = 1; gravity = Gravity.CENTER
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setShadowLayer(4f, 0f, 1f, Color.BLACK); setPadding(0, dp(4), 0, 0)
                })
            }
            val e = shown[p]
            (v.getChildAt(0) as android.widget.ImageView).setImageBitmap(e.bmp)
            (v.getChildAt(1) as TextView).text = e.label
            return v
        }
    }

    // ---------------- open an app ----------------
    private fun launch(e: Entry) {
        if (e.pkg == packageName) { startActivity(Intent(this, MainActivity::class.java)); return }
        if (e.pkg in Apps.list(this)) {
            // one of your booster apps: select it, clean RAM, GT intro, open
            Apps.setActive(this, e.pkg)
            Util.clean(this)
            GtIntro.play(this, { Util.launchGame(this, e.pkg) }) { toast("${e.label} not installed") }
            return
        }
        val li = packageManager.getLaunchIntentForPackage(e.pkg)
        if (li != null) startActivity(li) else toast("Cannot open ${e.label}")
    }

    // ---------------- long-press menu ----------------
    private fun themed(): AlertDialog.Builder = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun itemMenu(e: Entry) {
        val hid = e.pkg in Apps.hidden(this)
        val listed = e.pkg in Apps.list(this)
        val items = ArrayList<String>()
        items.add("🖼  Change logo (from gallery)")
        items.add("↺  Reset to original logo")
        items.add("✏  Rename")
        items.add(if (hid) "👁  Unhide app" else "🙈  Hide app")
        items.add(if (listed) "➖  Remove from booster list" else "🎮  Add to booster (game) list")
        items.add("ℹ  App info")
        if (e.pkg != packageName) items.add("🗑  Uninstall")
        themed().setTitle(e.label).setItems(items.toTypedArray()) { _, which ->
            when (which) {
                0 -> {
                    AppPicker.pendingPkg = e.pkg
                    val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }
                    try { startActivityForResult(Intent.createChooser(i, "Choose logo"), AppPicker.REQ_LOGO) }
                    catch (ex: Exception) { toast("No gallery / file picker found") }
                }
                1 -> { Apps.clearIcon(this, e.pkg); toast("Original logo restored"); reload() }
                2 -> {
                    val et = EditText(this).apply { setText(e.label); setSingleLine(); setSelectAllOnFocus(true) }
                    themed().setTitle("Rename").setView(et)
                        .setPositiveButton("SAVE") { _, _ -> Apps.setLabel(this, e.pkg, et.text.toString()); Apps.load(this); reload() }
                        .setNegativeButton("CANCEL", null).show()
                }
                3 -> { Apps.setHidden(this, e.pkg, !hid); toast(if (hid) "App unhidden" else "App hidden (⋮ > Show hidden apps)"); reload() }
                4 -> { if (listed) Apps.unlist(this, e.pkg) else Apps.add(this, e.pkg); toast(if (listed) "Removed from booster" else "Added to booster") }
                5 -> try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${e.pkg}")))
                } catch (ex: Exception) { toast("Cannot open app info") }
                6 -> try { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${e.pkg}"))) } catch (ex: Exception) { toast("Cannot uninstall") }
            }
        }.show()
    }

    private fun menu() {
        val items = arrayOf(if (showHidden) "🙈  Stop showing hidden apps" else "👁  Show hidden apps",
            "⚡  Booster dashboard", "🖼  Change wallpaper", "🏠  Default home app settings")
        themed().setItems(items) { _, which ->
            when (which) {
                0 -> { showHidden = !showHidden; reload() }
                1 -> startActivity(Intent(this, MainActivity::class.java))
                2 -> try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper")) } catch (ex: Exception) { toast("No wallpaper picker found") }
                3 -> try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) } catch (ex: Exception) { toast("Open Settings > Apps > Default apps > Home app") }
            }
        }.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != AppPicker.REQ_LOGO) return
        val pkg = AppPicker.pendingPkg; val u = data?.data
        if (res == RESULT_OK && pkg != null && u != null) {
            toast(if (Apps.setIconFromUri(this, pkg, u)) "Logo changed" else "Could not read that image")
            reload()
        }
        AppPicker.pendingPkg = null
    }
}
