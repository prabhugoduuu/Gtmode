package com.prabhu.gamebooster

import android.content.Context
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import android.os.Build
import android.os.PowerManager
import java.io.File

object SysInfo {
    val cores: Int = Runtime.getRuntime().availableProcessors()
    private var lastTotal = 0L
    private var lastIdle = 0L

    private fun read(p: String): String? = try { File(p).readText().trim() } catch (e: Exception) { null }

    fun cpuName(): String {
        if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotBlank() && Build.SOC_MODEL != "unknown")
            return Build.SOC_MANUFACTURER + " " + Build.SOC_MODEL
        val hw = read("/proc/cpuinfo")?.lineSequence()?.firstOrNull { it.startsWith("Hardware") }?.substringAfter(":")?.trim()
        return hw ?: Build.HARDWARE
    }

    // returns [avgMHz, maxMHz, loadPercentEstimate] or null
    fun cpuFreq(): IntArray? {
        var sumCur = 0L; var maxAll = 0L; var ratio = 0.0; var n = 0
        for (i in 0 until cores) {
            val c = read("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq")?.toLongOrNull()
            val m = read("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq")?.toLongOrNull()
            if (c != null && m != null && m > 0) { sumCur += c; if (m > maxAll) maxAll = m; ratio += c.toDouble() / m; n++ }
        }
        if (n == 0) return null
        return intArrayOf((sumCur / n / 1000).toInt(), (maxAll / 1000).toInt(), (ratio / n * 100).toInt())
    }

    // CPU load %, or -1 if this phone does not expose it
    fun cpuLoad(): Int {
        val line = read("/proc/stat")?.lineSequence()?.firstOrNull { it.startsWith("cpu ") }
        if (line != null) {
            val f = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (f.size >= 5) {
                val idle = f[3] + f[4]; val total = f.sum()
                val dt = total - lastTotal; val di = idle - lastIdle
                val had = lastTotal != 0L
                lastTotal = total; lastIdle = idle
                if (had && dt > 0) return ((dt - di) * 100 / dt).toInt().coerceIn(0, 100)
            }
        }
        return cpuFreq()?.get(2)?.coerceIn(0, 100) ?: -1
    }

    // GPU load %, or -1 if this phone does not expose it
    fun gpuLoad(): Int {
        read("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage")?.filter { it.isDigit() }?.toIntOrNull()?.let { return it.coerceIn(0, 100) }
        read("/sys/class/kgsl/kgsl-3d0/gpubusy")?.let { s ->
            val p = s.split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }
            if (p.size >= 2 && p[1] > 0) return (p[0] * 100 / p[1]).toInt().coerceIn(0, 100)
        }
        read("/sys/kernel/gpu/gpu_busy")?.filter { it.isDigit() }?.toIntOrNull()?.let { return it.coerceIn(0, 100) }
        File("/sys/class/devfreq").listFiles()
            ?.filter { it.name.contains("gpu", true) || it.name.contains("mali", true) || it.name.contains("kgsl", true) }
            ?.forEach { d ->
                val c = read(d.path + "/cur_freq")?.toLongOrNull(); val m = read(d.path + "/max_freq")?.toLongOrNull()
                if (c != null && m != null && m > 0) return (c * 100 / m).toInt().coerceIn(0, 100)
            }
        return -1
    }

    fun gpuName(): String = try {
        val d = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2); EGL14.eglInitialize(d, v, 0, v, 1)
        val attr = intArrayOf(EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT, EGL14.EGL_NONE)
        val cfgs = arrayOfNulls<EGLConfig>(1); val n = IntArray(1)
        EGL14.eglChooseConfig(d, attr, 0, cfgs, 0, 1, n, 0)
        val ctx = EGL14.eglCreateContext(d, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        val sf = EGL14.eglCreatePbufferSurface(d, cfgs[0], intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(d, sf, sf, ctx)
        val r = GLES20.glGetString(GLES20.GL_RENDERER) ?: "Unknown"
        EGL14.eglMakeCurrent(d, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
        EGL14.eglDestroySurface(d, sf); EGL14.eglDestroyContext(d, ctx)
        r
    } catch (e: Exception) { "Unknown" }

    fun thermal(c: Context): String {
        if (Build.VERSION.SDK_INT < 29) return "N/A"
        val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
        return when (pm.currentThermalStatus) { 0 -> "Normal"; 1 -> "Light"; 2 -> "Moderate"; 3 -> "Severe"; 4 -> "Critical"; else -> "Emergency" }
    }
}
