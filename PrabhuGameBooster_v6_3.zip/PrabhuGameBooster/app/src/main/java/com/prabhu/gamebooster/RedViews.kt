package com.prabhu.gamebooster

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import android.widget.TextView

/** Full-screen RedMagic-like background: dark base, centre glow, slanted side panels. */
class BgView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        cv.drawColor(Util.BG)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(w / 2f, h * 0.46f, maxOf(w, h) * 0.55f,
            intArrayOf(Util.alpha(Util.ACC, 0x44), Util.alpha(Util.ACC2, 0x14), Color.TRANSPARENT),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, p)
        p.shader = null
        // slanted side panels
        p.color = Util.alpha(Util.ACC, 0x14)
        path.reset(); path.moveTo(0f, 0f); path.lineTo(w * 0.17f, 0f); path.lineTo(w * 0.08f, h); path.lineTo(0f, h); path.close()
        cv.drawPath(path, p)
        path.reset(); path.moveTo(w, 0f); path.lineTo(w * 0.83f, 0f); path.lineTo(w * 0.92f, h); path.lineTo(w, h); path.close()
        cv.drawPath(path, p)
        // thin slanted edge lines
        p.style = Paint.Style.STROKE; p.strokeWidth = Util.dp(context, 1).toFloat(); p.color = Util.alpha(Util.ACC, 0x40)
        cv.drawLine(w * 0.17f, 0f, w * 0.08f, h, p)
        cv.drawLine(w * 0.83f, 0f, w * 0.92f, h, p)
        p.style = Paint.Style.FILL
    }
}

/** Centre hub: glowing disc with rotating rings and the live frame rate in the middle. */
class HubView(c: Context) : View(c) {
    private var big = "--"
    private var small = "FPS"
    private var top = ""
    private var spin = 0f
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    fun setValue(b: String, s: String, t: String) { big = b; small = s; top = t; invalidate() }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 12000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { spin = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() { anim?.cancel(); anim = null; super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val d = Util.dp(context, 1).toFloat()
        val cx = width / 2f; val cy = height / 2f
        val r = minOf(width, height) / 2f - d * 4f
        if (r <= 0f) return
        // outer glow
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, r, intArrayOf(Util.alpha(Util.ACC, 0x00), Util.alpha(Util.ACC, 0x55), Color.TRANSPARENT),
            floatArrayOf(0.6f, 0.86f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r, p); p.shader = null
        // dashed outer ring (rotating)
        p.style = Paint.Style.STROKE; p.strokeWidth = d * 2f; p.color = Util.alpha(Util.ACC, 0x99)
        p.pathEffect = DashPathEffect(floatArrayOf(d * 10f, d * 7f), 0f)
        cv.save(); cv.rotate(spin, cx, cy); cv.drawCircle(cx, cy, r * 0.97f, p); cv.restore()
        p.pathEffect = null
        // 4 thick arcs (rotating the other way)
        p.strokeWidth = d * 5f; p.strokeCap = Paint.Cap.ROUND
        rect.set(cx - r * 0.84f, cy - r * 0.84f, cx + r * 0.84f, cy + r * 0.84f)
        cv.save(); cv.rotate(-spin * 1.6f, cx, cy)
        p.color = Util.ACC
        for (i in 0..3) cv.drawArc(rect, i * 90f + 8f, 52f, false, p)
        cv.restore()
        // thin inner ring
        p.strokeWidth = d * 1.5f; p.strokeCap = Paint.Cap.BUTT; p.color = Util.alpha(Util.ACC2, 0xAA)
        cv.drawCircle(cx, cy, r * 0.70f, p)
        // dark core
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#E005070D")
        cv.drawCircle(cx, cy, r * 0.66f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = d * 1f; p.color = Util.alpha(Util.ACC, 0x55)
        cv.drawCircle(cx, cy, r * 0.66f, p)
        // text
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.typeface = Util.BOLD; p.color = Util.MUTED; p.textSize = r * 0.10f; p.letterSpacing = 0.14f
        cv.drawText(top, cx, cy - r * 0.34f, p)
        p.typeface = Util.HEAD; p.color = Color.WHITE; p.letterSpacing = 0f; p.textSize = r * 0.46f
        cv.drawText(big, cx, cy + r * 0.16f, p)
        p.typeface = Util.BOLD; p.color = Util.ACC; p.textSize = r * 0.13f; p.letterSpacing = 0.2f
        cv.drawText(small, cx, cy + r * 0.40f, p)
        p.letterSpacing = 0f
    }
}

/** Compact ring with a big centre value (used for CPU and GPU, like the Energy Cube panel). */
class MiniRing(c: Context, private val label: String) : View(c) {
    private var value = -1
    private var big = "--"
    private var unit = ""
    private var cap = ""
    private var col = Util.ACC
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val mx = Matrix()

    fun set(v: Int, b: String, u: String, color: Int, caption: String) { value = v; big = b; unit = u; col = color; cap = caption; invalidate() }

    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), Util.dp(context, 128)) }

    override fun onDraw(cv: Canvas) {
        val d = Util.dp(context, 1).toFloat()
        val dia = height - d * 20f
        val cx = width / 2f; val cy = dia / 2f + d * 2f
        val st = dia * 0.075f
        rect.set(cx - dia / 2f + st, cy - dia / 2f + st, cx + dia / 2f - st, cy + dia / 2f - st)
        p.style = Paint.Style.FILL; p.shader = null; p.color = Color.parseColor("#14FFFFFF")
        cv.drawCircle(cx, cy, dia / 2f - st * 1.6f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = st; p.strokeCap = Paint.Cap.ROUND
        p.color = Color.parseColor("#1FFFFFFF"); cv.drawArc(rect, 135f, 270f, false, p)
        if (value >= 0) {
            val sweep = 270f * value.coerceIn(2, 100) / 100f
            p.strokeWidth = st * 2f; p.color = Util.alpha(col, 0x28); cv.drawArc(rect, 135f, sweep, false, p)
            p.strokeWidth = st
            val sg = SweepGradient(cx, cy, intArrayOf(Util.alpha(col, 0x66), col, col), floatArrayOf(0f, 0.75f, 1f))
            mx.reset(); mx.setRotate(135f, cx, cy); sg.setLocalMatrix(mx)
            p.shader = sg; cv.drawArc(rect, 135f, sweep, false, p); p.shader = null
        }
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.typeface = Util.BOLD; p.color = Util.MUTED; p.textSize = dia * 0.095f; p.letterSpacing = 0.16f
        cv.drawText(label, cx, cy - dia * 0.20f, p)
        p.typeface = Util.HEAD; p.color = Color.WHITE; p.letterSpacing = 0f; p.textSize = dia * 0.26f
        cv.drawText(big, cx, cy + dia * 0.12f, p)
        p.typeface = Util.BOLD; p.color = col; p.textSize = dia * 0.11f
        cv.drawText(unit, cx, cy + dia * 0.28f, p)
        p.color = Util.MUTED; p.textSize = d * 9f
        cv.drawText(cap, width / 2f, height - d * 3f, p)
    }
}

/** Column of slanted segments that fill from the bottom (like the side bars in Energy Cube). */
class SlantBars(c: Context, private val mirror: Boolean) : View(c) {
    private var pct = -1
    private var col = Util.ACC
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    fun set(v: Int, color: Int) { pct = v; col = color; invalidate() }

    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(Util.dp(context, 24), Util.dp(context, 108)) }

    override fun onDraw(cv: Canvas) {
        val d = Util.dp(context, 1).toFloat()
        val n = 10
        val w = width.toFloat(); val h = height.toFloat() - d * 2f
        val segH = h / n; val gap = d * 2.5f; val skew = d * 8f
        cv.save()
        if (mirror) cv.scale(-1f, 1f, w / 2f, h / 2f)
        val lit = if (pct < 0) 0 else Math.ceil(pct.coerceIn(0, 100) * n / 100.0).toInt()
        p.style = Paint.Style.FILL
        for (i in 0 until n) {
            val y1 = h - i * segH; val y0 = y1 - (segH - gap)
            path.reset()
            path.moveTo(skew, y0); path.lineTo(w, y0); path.lineTo(w - skew, y1); path.lineTo(0f, y1); path.close()
            p.color = if (i < lit) Util.alpha(col, 0x55 + (0xAA * i / n)) else Color.parseColor("#1FFFFFFF")
            cv.drawPath(path, p)
        }
        cv.restore()
    }
}

/** Vertical list of performance modes (left rail style). */
class ModeList(c: Context, labels: List<String>, icons: List<String>, private val onPick: (Int) -> Unit) : LinearLayout(c) {
    private val rows = ArrayList<LinearLayout>()
    private val names = ArrayList<TextView>()

    init {
        orientation = VERTICAL
        val d = Util.dp(c, 1)
        labels.forEachIndexed { i, l ->
            val row = LinearLayout(c).apply {
                orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(d * 12, d * 8, d * 12, d * 8)
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, d * 3, 0, d * 3) }
                setOnClickListener { select(i); onPick(i) }
            }
            row.addView(TextView(c).apply { text = icons[i]; textSize = 14f; setPadding(0, 0, d * 10, 0) })
            val t = TextView(c).apply { text = l; textSize = 11.5f; typeface = Util.BOLD; letterSpacing = 0.1f }
            row.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            rows.add(row); names.add(t); addView(row)
        }
    }

    fun select(i: Int) {
        rows.forEachIndexed { k, r ->
            if (k == i) { r.background = Util.glassOn(context, 14); names[k].setTextColor(Color.WHITE) }
            else { r.background = Util.round(context, Color.parseColor("#90080C18"), 14, Color.parseColor("#18FFFFFF")); names[k].setTextColor(Util.MUTED) }
        }
    }
}

/** Small label + value chip for the top bar (battery, temperature, RAM, ping). */
class StatChip(c: Context, label: String) : LinearLayout(c) {
    private val v = TextView(c)

    init {
        orientation = VERTICAL; gravity = Gravity.CENTER
        val d = Util.dp(c, 1)
        setPadding(d * 9, d * 4, d * 9, d * 4)
        background = Util.glass(c, 11)
        addView(TextView(c).apply { text = label; textSize = 7.5f; typeface = Util.BOLD; setTextColor(Util.MUTED); letterSpacing = 0.14f; gravity = Gravity.CENTER })
        v.text = "--"; v.textSize = 12f; v.typeface = Util.HEAD; v.setTextColor(Color.WHITE); v.gravity = Gravity.CENTER
        addView(v)
    }

    fun set(t: String, color: Int) { v.text = t; v.setTextColor(color) }
}
