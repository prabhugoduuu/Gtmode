package com.prabhu.gamebooster

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings

object PowerTools {
    private const val SECURE = "android.permission.WRITE_SECURE_SETTINGS"

    /** True if Battery Saver is now ON. Needs the one-time adb grant (see README); otherwise returns false. */
    fun saverDirect(c: Context): Boolean {
        if (c.packageManager.checkPermission(SECURE, c.packageName) != PackageManager.PERMISSION_GRANTED) return false
        return try { Settings.Global.putInt(c.contentResolver, "low_power", 1) } catch (e: Exception) { false }
    }

    /** Switches Battery Saver on if allowed, otherwise opens its settings screen. Returns true when switched on directly. */
    fun batterySaver(c: Context): Boolean {
        if (saverDirect(c)) return true
        try { c.startActivity(Intent("android.settings.BATTERY_SAVER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) {
            try { c.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (x: Exception) {}
        }
        return false
    }

    /** Charge mode: less background load, Do Not Disturb, Battery Saver (if allowed), dim always-on charging screen. */
    fun startCharge(c: Context) {
        Util.dnd(c, true)
        saverDirect(c)
        c.startActivity(Intent(c, ChargeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
