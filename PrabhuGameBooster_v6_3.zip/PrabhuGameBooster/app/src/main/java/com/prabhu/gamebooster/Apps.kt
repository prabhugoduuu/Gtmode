package com.prabhu.gamebooster

import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import java.io.File

/**
 * The list of apps/games the booster works with, the one currently selected ("active"),
 * and each app's custom name + custom logo (stored privately inside this app).
 * Your own logo only changes how the app looks INSIDE Prabhu Game Booster and on a home-screen
 * shortcut made by it - Android does not let one app change another app's real icon.
 */
object Apps {
    const val DEFAULT_PKG = "com.garena.game.ffi"
    const val DEFAULT_NAME = "Free Fire India"
    private const val K_LIST = "apps_list"
    private const val K_ACTIVE = "apps_active"

    class Item(val pkg: String, val label: String)

    fun list(c: Context): List<String> {
        val s = Util.pref(c).getString(K_LIST, null)
        val l = s?.split("\n")?.filter { it.isNotBlank() } ?: emptyList()
        return if (l.isEmpty()) listOf(DEFAULT_PKG) else l
    }

    private fun save(c: Context, l: List<String>) {
        Util.pref(c).edit().putString(K_LIST, l.joinToString("\n")).apply()
    }

    fun active(c: Context): String {
        val a = Util.pref(c).getString(K_ACTIVE, null)
        val l = list(c)
        return if (a != null && a in l) a else l.first()
    }

    fun add(c: Context, pkg: String) {
        val l = list(c)
        if (pkg !in l) save(c, l + pkg)
        load(c)
    }

    fun setActive(c: Context, pkg: String) {
        add(c, pkg)
        Util.pref(c).edit().putString(K_ACTIVE, pkg).apply()
        load(c)
    }

    fun remove(c: Context, pkg: String) {
        save(c, list(c) - pkg)
        clearIcon(c, pkg)
        Util.pref(c).edit().remove("apps_name_$pkg").apply()
        load(c)
    }

    /** Takes an app out of the game list WITHOUT deleting its custom logo / name. */
    fun unlist(c: Context, pkg: String) { save(c, list(c) - pkg); load(c) }

    fun hidden(c: Context): Set<String> = HashSet(Util.pref(c).getStringSet("apps_hidden", emptySet()) ?: emptySet())

    fun setHidden(c: Context, pkg: String, hide: Boolean) {
        val s = HashSet(hidden(c))
        if (hide) s.add(pkg) else s.remove(pkg)
        Util.pref(c).edit().putStringSet("apps_hidden", s).apply()
    }

    /** Copies the saved choice into Util (GAME_PKG / GAME_NAME / GAMES) so the whole app follows it. */
    fun load(c: Context) {
        val a = active(c)
        Util.GAME_PKG = a
        Util.GAME_NAME = label(c, a)
        Util.GAMES = list(c)
    }

    fun installed(c: Context, pkg: String) = c.packageManager.getLaunchIntentForPackage(pkg) != null

    private fun sysLabel(c: Context, pkg: String): String? = try {
        val pm = c.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { null }

    fun label(c: Context, pkg: String): String {
        val custom = Util.pref(c).getString("apps_name_$pkg", null)
        if (!custom.isNullOrBlank()) return custom
        if (pkg == DEFAULT_PKG) return DEFAULT_NAME
        return sysLabel(c, pkg) ?: pkg
    }

    fun setLabel(c: Context, pkg: String, name: String) {
        val e = Util.pref(c).edit()
        if (name.isBlank()) e.remove("apps_name_$pkg") else e.putString("apps_name_$pkg", name.trim())
        e.apply()
    }

    // ---------------- custom logo ----------------
    private fun iconFile(c: Context, pkg: String) = File(File(c.filesDir, "appicons"), "$pkg.png")

    fun hasCustomIcon(c: Context, pkg: String) = iconFile(c, pkg).exists()

    fun clearIcon(c: Context, pkg: String) { try { iconFile(c, pkg).delete() } catch (e: Exception) {} }

    /** Reads the picked image, centre-crops it to a square, shrinks to 256 px and stores it as PNG. */
    fun setIconFromUri(c: Context, pkg: String, uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var s = 1
            while (bounds.outWidth / (s * 2) >= 512 && bounds.outHeight / (s * 2) >= 512) s *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = s }
            val src = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return false
            val side = minOf(src.width, src.height)
            val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            val out = Bitmap.createScaledBitmap(sq, 256, 256, true)
            val f = iconFile(c, pkg)
            f.parentFile?.mkdirs()
            f.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            true
        } catch (e: Throwable) { false }
    }

    private fun initials(c: Context, pkg: String): String {
        val words = label(c, pkg).split(" ").filter { it.isNotBlank() }
        return when {
            words.isEmpty() -> "?"
            words.size == 1 -> words[0].take(2).uppercase()
            else -> (words[0].take(1) + words[1].take(1)).uppercase()
        }
    }

    /** The logo to show: your custom image, else the real app icon, else a coloured tile with initials. */
    fun iconBitmap(c: Context, pkg: String, size: Int = 192): Bitmap {
        try {
            val f = iconFile(c, pkg)
            if (f.exists()) {
                val b = BitmapFactory.decodeFile(f.path)
                if (b != null) return Bitmap.createScaledBitmap(b, size, size, true)
            }
        } catch (e: Throwable) {}
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        try {
            val d = c.packageManager.getApplicationIcon(pkg)
            d.setBounds(0, 0, size, size)
            d.draw(cv)
            return bmp
        } catch (e: Throwable) {}
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Util.ACC
        cv.drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), size * 0.22f, size * 0.22f, p)
        p.color = Util.ON_ACC; p.textSize = size * 0.42f; p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD
        cv.drawText(initials(c, pkg), size / 2f, size / 2f - (p.descent() + p.ascent()) / 2f, p)
        return bmp
    }

    // ---------------- installed apps / shortcut ----------------
    @Suppress("DEPRECATION")
    fun launchables(c: Context): List<Item> {
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { Item(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.pkg != c.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    /** Home-screen shortcut with the chosen logo + name. Tapping it = BOOST & PLAY for that app. Android 8+. */
    fun pinShortcut(c: Context, pkg: String): Boolean {
        if (Build.VERSION.SDK_INT < 26) return false
        return try {
            val sm = c.getSystemService(ShortcutManager::class.java) ?: return false
            if (!sm.isRequestPinShortcutSupported) return false
            val launch = Intent(c, MainActivity::class.java)
                .setAction("com.prabhu.gamebooster.LAUNCH_APP").putExtra("launch_pkg", pkg)
            val name = label(c, pkg)
            val info = ShortcutInfo.Builder(c, "app_$pkg").setShortLabel(name).setLongLabel(name)
                .setIcon(Icon.createWithBitmap(iconBitmap(c, pkg, 192))).setIntent(launch).build()
            sm.requestPinShortcut(info, null)
        } catch (e: Throwable) { false }
    }
}
