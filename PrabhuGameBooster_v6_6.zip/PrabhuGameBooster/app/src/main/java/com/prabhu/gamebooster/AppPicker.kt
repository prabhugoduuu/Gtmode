package com.prabhu.gamebooster

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.ColorDrawable
import android.content.Intent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.Window
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Dialogs: MY APPS (select / edit logo / rename / shortcut / remove) and ADD APP. */
object AppPicker {
    const val REQ_LOGO = 7701
    var pendingPkg: String? = null
    var refresh: (() -> Unit)? = null

    private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun toast(a: Activity, t: String) = Toast.makeText(a, t, Toast.LENGTH_SHORT).show()

    /** Rounded-square logo view. */
    fun iconView(c: Activity, pkg: String, sizeDp: Int, bmp: Bitmap? = null, circle: Boolean = false): ImageView = ImageView(c).apply {
        setImageBitmap(bmp ?: Apps.iconBitmap(c, pkg))
        scaleType = ImageView.ScaleType.CENTER_CROP
        val r = Util.dp(c, sizeDp * 22 / 100).toFloat()
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { if (circle) o.setOval(0, 0, v.width, v.height) else o.setRoundRect(0, 0, v.width, v.height, r) }
        }
        clipToOutline = true
        layoutParams = LinearLayout.LayoutParams(Util.dp(c, sizeDp), Util.dp(c, sizeDp))
    }

    private fun smallBtn(a: Activity, t: String, onClick: () -> Unit) = TextView(a).apply {
        text = t; textSize = 10.5f; typeface = Util.BOLD; gravity = Gravity.CENTER; letterSpacing = 0.05f
        setTextColor(Color.WHITE); setPadding(Util.dp(a, 12), Util.dp(a, 8), Util.dp(a, 12), Util.dp(a, 8))
        background = Util.glass(a, 12)
        setOnClickListener { onClick() }
    }

    private fun makeDialog(a: Activity, title: String, body: View, footer: View): Dialog {
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val pad = Util.dp(a, 14)
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad)
            background = Util.round(a, Util.BG2, 20, Util.alpha(Color.WHITE, 0x33))
        }
        root.addView(TextView(a).apply {
            text = title; textSize = 15f; typeface = Util.HEAD; setTextColor(Color.WHITE); letterSpacing = 0.08f
            setPadding(0, 0, 0, Util.dp(a, 8))
        })
        val sv = ScrollView(a).apply { addView(body, ViewGroup.LayoutParams(MATCH, WRAP)) }
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(footer, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = Util.dp(a, 8) })
        d.setContentView(root)
        val dm = a.resources.displayMetrics
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(minOf(dm.widthPixels - Util.dp(a, 24), Util.dp(a, 520)), (dm.heightPixels * 0.88f).toInt())
        }
        return d
    }

    // ---------------- MY APPS ----------------
    fun manage(a: Activity, onChange: () -> Unit) {
        val list = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        var dlg: Dialog? = null

        fun fill() {
            list.removeAllViews()
            val cur = Apps.active(a)
            for (pkg in Apps.list(a)) {
                val sel = pkg == cur
                val row = LinearLayout(a).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(Util.dp(a, 10), Util.dp(a, 8), Util.dp(a, 10), Util.dp(a, 8))
                    background = if (sel) Util.round(a, Util.alpha(Util.ACC, 0x22), 14, Util.ACC) else Util.glass(a, 14)
                    layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, Util.dp(a, 4), 0, Util.dp(a, 4)) }
                }
                val ic = iconView(a, pkg, 44)
                (ic.layoutParams as LinearLayout.LayoutParams).rightMargin = Util.dp(a, 12)
                row.addView(ic)
                val tx = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
                tx.addView(TextView(a).apply {
                    text = Apps.label(a, pkg); textSize = 13.5f; typeface = Util.BOLD; setTextColor(Color.WHITE); maxLines = 1
                })
                tx.addView(TextView(a).apply {
                    text = (if (sel) "● SELECTED  •  " else "") + (if (Apps.installed(a, pkg)) "installed" else "not installed")
                    textSize = 9.5f; setTextColor(if (sel) Util.GREEN else Util.MUTED)
                })
                row.addView(tx, LinearLayout.LayoutParams(0, WRAP, 1f))
                row.addView(smallBtn(a, "EDIT  ⋮") { options(a, pkg) { fill(); onChange() } })
                row.setOnClickListener { Apps.setActive(a, pkg); fill(); onChange() }
                list.addView(row)
            }
        }
        fill()
        refresh = { fill(); onChange() }

        val footer = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        footer.addView(Util.primary(a, "+  ADD APP") { addApp(a) { fill(); onChange() } }.apply {
            textSize = 12f
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = Util.dp(a, 8) } })
        footer.addView(smallBtn(a, "DONE") { dlg?.dismiss() }.apply {
            textSize = 12f; setPadding(Util.dp(a, 22), Util.dp(a, 14), Util.dp(a, 22), Util.dp(a, 14)) })

        val d = makeDialog(a, "MY APPS  •  tap an app to select it", list, footer)
        dlg = d
        d.setOnDismissListener { refresh = null }
        d.show()
    }

    private fun options(a: Activity, pkg: String, done: () -> Unit) {
        val items = arrayOf("🖼  Change logo (from gallery)", "↺  Reset to original logo", "✏  Rename",
            "🏠  Add to home screen (with this logo)", "🗑  Remove from booster")
        AlertDialog.Builder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(Apps.label(a, pkg))
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        pendingPkg = pkg
                        val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }
                        try { a.startActivityForResult(Intent.createChooser(i, "Choose logo"), REQ_LOGO) }
                        catch (e: Exception) { toast(a, "No gallery / file picker found") }
                    }
                    1 -> { Apps.clearIcon(a, pkg); toast(a, "Original logo restored"); done() }
                    2 -> {
                        val et = EditText(a).apply { setText(Apps.label(a, pkg)); setSingleLine(); setSelectAllOnFocus(true) }
                        AlertDialog.Builder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                            .setTitle("Rename").setView(et)
                            .setPositiveButton("SAVE") { _, _ -> Apps.setLabel(a, pkg, et.text.toString()); Apps.load(a); done() }
                            .setNegativeButton("CANCEL", null).show()
                    }
                    3 -> if (Apps.pinShortcut(a, pkg)) toast(a, "Tap ADD on the pop-up to place it on your home screen")
                         else toast(a, "Home-screen shortcut is not supported here (needs Android 8+ launcher)")
                    4 -> { Apps.remove(a, pkg); done() }
                }
            }.show()
    }

    // ---------------- ADD APP ----------------
    fun addApp(a: Activity, onAdded: () -> Unit) {
        val body = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        body.addView(TextView(a).apply { text = "Loading your apps..."; textSize = 12f; setTextColor(Util.MUTED); setPadding(Util.dp(a, 4), Util.dp(a, 10), 0, 0) })
        var dlg: Dialog? = null
        val footer = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        footer.addView(smallBtn(a, "CLOSE") { dlg?.dismiss() }.apply {
            textSize = 12f; setPadding(Util.dp(a, 22), Util.dp(a, 14), Util.dp(a, 22), Util.dp(a, 14)) })
        val shown = makeDialog(a, "ADD APP  •  pick any installed app", body, footer)
        dlg = shown
        shown.show()

        Thread {
            val have = Apps.list(a).toSet()
            val items = Apps.launchables(a).filter { it.pkg !in have }
            val bitmaps = items.map { Apps.iconBitmap(a, it.pkg, 144) }
            a.runOnUiThread {
                if (shown.isShowing) {
                    body.removeAllViews()
                    if (items.isEmpty()) body.addView(TextView(a).apply { text = "No more apps to add."; textSize = 12f; setTextColor(Util.MUTED) })
                    items.forEachIndexed { k, item ->
                        val row = LinearLayout(a).apply {
                            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                            setPadding(Util.dp(a, 10), Util.dp(a, 7), Util.dp(a, 10), Util.dp(a, 7))
                            background = Util.glass(a, 14)
                            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, Util.dp(a, 3), 0, Util.dp(a, 3)) }
                        }
                        val ic = iconView(a, item.pkg, 40, bitmaps[k])
                        (ic.layoutParams as LinearLayout.LayoutParams).rightMargin = Util.dp(a, 12)
                        row.addView(ic)
                        row.addView(TextView(a).apply { text = item.label; textSize = 13f; typeface = Util.BOLD; setTextColor(Color.WHITE); maxLines = 1 },
                            LinearLayout.LayoutParams(0, WRAP, 1f))
                        row.setOnClickListener {
                            Apps.setActive(a, item.pkg)
                            shown.dismiss()
                            toast(a, "${item.label} added and selected")
                            onAdded()
                        }
                        body.addView(row)
                    }
                }
            }
        }.start()
    }
}
