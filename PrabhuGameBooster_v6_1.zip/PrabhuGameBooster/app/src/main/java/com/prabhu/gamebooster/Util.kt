package com.prabhu.gamebooster

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.NotificationManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.*
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Choreographer
import android.view.Gravity
import android.widget.TextView
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.roundToInt

object Util {
    // ---- Free Fire INDIA only ----
    const val GAME_PKG = "com.garena.game.ffi"
    const val GAME_NAME = "Free Fire India"
    val GAMES = listOf(GAME_PKG)

    // ---- palette (v5 "Neon Glass") ----
    // ORANGE / AMBER are now the fixed WARNING colours; the themed accent is ACC / ACC2.
    val ORANGE = Color.parseColor("#FF8A1F")
    val AMBER = Color.parseColor("#FFB347")
    val GREEN = Color.parseColor("#2DFF9A")
    val RED = Color.parseColor("#FF4D6A")
    val BLUE = Color.parseColor("#3FA9FF")
    val BG = Color.parseColor("#05070D")
    val BG2 = Color.parseColor("#0D1428")
    val CARD = Color.parseColor("#121A2E")
    val CARD2 = Color.parseColor("#1B2540")
    val MUTED = Color.parseColor("#8D97B3")

    class Theme(val name: String, val a: Int, val b: Int)
    val THEMES = listOf(
        Theme("NEON", Color.parseColor("#00E5FF"), Color.parseColor("#6C5CFF")),
        Theme("FIRE", Color.parseColor("#FF6A00"), Color.parseColor("#FFB020")),
        Theme("VIOLET", Color.parseColor("#B14CFF"), Color.parseColor("#FF4FD8")),
        Theme("LIME", Color.parseColor("#B6FF2E"), Color.parseColor("#00E08A")),
        Theme("RED", Color.parseColor("#FF2D3F"), Color.parseColor("#FF7A1A")))
    var themeIdx = 0
    var ACC = THEMES[0].a
    var ACC2 = THEMES[0].b
    var ON_ACC = Color.parseColor("#04121A")   // text colour on top of the accent gradient

    private fun applyTheme(i: Int) {
        themeIdx = i.coerceIn(0, THEMES.size - 1)
        ACC = THEMES[themeIdx].a; ACC2 = THEMES[themeIdx].b
        ON_ACC = if ((0.299 * Color.red(ACC) + 0.587 * Color.green(ACC) + 0.114 * Color.blue(ACC)) / 255.0 > 0.55) Color.parseColor("#04121A") else Color.WHITE
    }
    fun initTheme(c: Context) = applyTheme(pref(c).getInt("theme", 4))
    fun setTheme(c: Context, i: Int) { pref(c).edit().putInt("theme", i).apply(); applyTheme(i) }

    val BOLD: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    val HEAD: Typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()
    fun loadColor(v: Int) = if (v >= 85) RED else if (v >= 60) ORANGE else GREEN
    fun alpha(color: Int, a: Int) = (color and 0x00FFFFFF) or (a shl 24)

    fun round(c: Context, color: Int, r: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(c, r).toFloat()
            if (stroke != 0) setStroke(dp(c, 1), stroke)
        }

    fun grad(c: Context, a: Int, b: Int, r: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(a, b)).apply { cornerRadius = dp(c, r).toFloat() }

    fun accGrad(c: Context, r: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(ACC, ACC2)).apply { cornerRadius = dp(c, r).toFloat() }

    /** frosted-glass card */
    fun glass(c: Context, r: Int, stroke: Int = Color.parseColor("#2AFFFFFF")): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#F01B2540"), Color.parseColor("#F00E1426"))).apply {
            cornerRadius = dp(c, r).toFloat(); setStroke(dp(c, 1), stroke) }

    /** selected / active glass with a soft accent tint */
    fun glassOn(c: Context, r: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(alpha(ACC, 0x55), alpha(ACC2, 0x33))).apply {
            cornerRadius = dp(c, r).toFloat(); setStroke(dp(c, 1), ACC) }

    fun screenBg(): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(BG, BG2, BG))

    fun pill(c: Context, t: String, color: Int, onClick: () -> Unit): TextView = TextView(c).apply {
        text = t; setTextColor(Color.WHITE); textSize = 11.5f; gravity = Gravity.CENTER
        typeface = BOLD; letterSpacing = 0.04f
        setPadding(dp(c, 10), dp(c, 12), dp(c, 10), dp(c, 12))
        background = if (color == CARD2 || color == CARD) glass(c, 16) else round(c, color, 16, alpha(Color.WHITE, 0x22))
        setOnTouchListener { v, e -> v.alpha = if (e.action == android.view.MotionEvent.ACTION_DOWN) 0.65f else 1f; false }
        setOnClickListener { onClick() }
    }

    fun primary(c: Context, t: String, onClick: () -> Unit): TextView = TextView(c).apply {
        text = t; setTextColor(ON_ACC); textSize = 14f; gravity = Gravity.CENTER
        typeface = HEAD; letterSpacing = 0.1f
        setPadding(dp(c, 10), dp(c, 15), dp(c, 10), dp(c, 15))
        background = accGrad(c, 18)
        if (Build.VERSION.SDK_INT >= 28) { elevation = dp(c, 6).toFloat(); outlineSpotShadowColor = ACC; outlineAmbientShadowColor = ACC }
        setOnTouchListener { v, e -> v.alpha = if (e.action == android.view.MotionEvent.ACTION_DOWN) 0.75f else 1f; false }
        setOnClickListener { onClick() }
    }

    /** section title with a glowing accent bar */
    fun sectionHeader(c: Context, t: String): android.widget.LinearLayout = android.widget.LinearLayout(c).apply {
        orientation = android.widget.LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(c, 2), dp(c, 14), 0, dp(c, 4))
        addView(android.view.View(c).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(ACC, ACC2)).apply { cornerRadius = dp(c, 2).toFloat() }
            layoutParams = android.widget.LinearLayout.LayoutParams(dp(c, 3), dp(c, 13)).apply { rightMargin = dp(c, 8) } })
        addView(TextView(c).apply { text = t; textSize = 10.5f; setTextColor(Color.WHITE); typeface = BOLD; letterSpacing = 0.16f })
    }

    /** row of theme colour dots; onPick gets the chosen index */
    fun themeRow(c: Context, onPick: (Int) -> Unit): android.widget.LinearLayout = android.widget.LinearLayout(c).apply {
        orientation = android.widget.LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        THEMES.forEachIndexed { i, th ->
            addView(TextView(c).apply {
                text = th.name; textSize = 9.5f; typeface = BOLD; gravity = Gravity.CENTER; letterSpacing = 0.06f
                setTextColor(if (i == themeIdx) ON_ACC else Color.WHITE)
                setPadding(dp(c, 4), dp(c, 11), dp(c, 4), dp(c, 11))
                background = if (i == themeIdx) GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(th.a, th.b)).apply { cornerRadius = dp(c, 14).toFloat() }
                             else GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(alpha(th.a, 0x44), alpha(th.b, 0x22))).apply { cornerRadius = dp(c, 14).toFloat(); setStroke(dp(c, 1), alpha(th.a, 0x99)) }
                layoutParams = android.widget.LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(c, 3), dp(c, 4), dp(c, 3), dp(c, 4)) }
                setOnClickListener { onPick(i) } })
        }
    }

    fun pref(c: Context): SharedPreferences = c.getSharedPreferences("pgb", Context.MODE_PRIVATE)

    // ---- system stats ----
    fun temp(c: Context): Float {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra("temperature", 0) ?: 0) / 10f
    }

    fun battery(c: Context): Int {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra("level", 0) ?: 0
        val s = i?.getIntExtra("scale", 100) ?: 100
        return if (s > 0) l * 100 / s else 0
    }

    fun ramPercent(c: Context): Int {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        return (100 - mi.availMem * 100 / mi.totalMem).toInt()
    }

    fun totalRam(c: Context): String {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        return "%.1f GB".format(mi.totalMem / 1073741824.0)
    }

    fun displayHz(c: Context): Int {
        val dm = c.getSystemService(Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager
        val d = dm.getDisplay(0)
        return if (d != null) d.refreshRate.roundToInt().coerceAtLeast(60) else 60
    }

    fun ping(cb: (Long) -> Unit) {
        Thread {
            val t = System.currentTimeMillis()
            val r = try {
                Socket().use { it.connect(InetSocketAddress("8.8.8.8", 53), 1500) }
                System.currentTimeMillis() - t
            } catch (e: Exception) { -1L }
            cb(r)
        }.start()
    }

    // ---- RAM clean / boost ----
    fun clean(c: Context) {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val ime = Settings.Secure.getString(c.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)?.substringBefore("/")
        c.packageManager.getInstalledApplications(0)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName != c.packageName &&
                it.packageName != ime && it.packageName !in GAMES }
            .forEach { am.killBackgroundProcesses(it.packageName) }
    }

    // cb runs on main thread: (freedMB, freeRamMB)
    fun boost(c: Context, cb: (Long, Long) -> Unit) {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        val before = mi.availMem
        clean(c)
        Handler(Looper.getMainLooper()).postDelayed({
            val m2 = ActivityManager.MemoryInfo(); am.getMemoryInfo(m2)
            cb(maxOf(0L, (m2.availMem - before) / 1048576), m2.availMem / 1048576)
        }, 900)
    }

    fun dnd(c: Context, on: Boolean): Boolean {
        if (Build.VERSION.SDK_INT < 23) return false
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) return false
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
        return true
    }

    // ---- game ----
    fun gameInstalled(c: Context) = c.packageManager.getLaunchIntentForPackage(GAME_PKG) != null

    fun launchGame(c: Context): Boolean {
        val li = GAMES.firstNotNullOfOrNull { c.packageManager.getLaunchIntentForPackage(it) } ?: return false
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(li); return true
    }

    fun openStore(c: Context) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$GAME_PKG")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { c.startActivity(i) } catch (e: Exception) {
            c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$GAME_PKG"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    // ---- foreground-app detection (needs Usage Access) ----
    @Suppress("DEPRECATION")
    fun hasUsage(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        else ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private var lastFg: String? = null
    private var lastQ = 0L

    @Suppress("DEPRECATION")
    fun foreground(c: Context): String? {
        if (!hasUsage(c)) return null
        return try {
            val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val from = if (lastQ == 0L) now - 3600000L else lastQ - 2000L
            val ev = usm.queryEvents(from, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) lastFg = e.packageName
            }
            lastQ = now
            lastFg
        } catch (e: Exception) { lastFg }
    }

    fun hasMic(c: Context) =
        c.packageManager.checkPermission("android.permission.RECORD_AUDIO", c.packageName) == PackageManager.PERMISSION_GRANTED
}

object Modes {
    const val ESPORTS = 4
    val names = listOf("SMOOTH", "BALANCED", "PRO", "AI", "ESPORTS")
    val desc = listOf(
        "SMOOTH: light RAM clean. Notifications stay on.",
        "BALANCED: RAM clean + Do Not Disturb.",
        "PRO: clean + DND + screen stays awake + auto-clean every 60 s.",
        "AI: everything in PRO + auto-clean every 30 s + overheat alerts.",
        "ESPORTS: game only. Back/Home/Recents locked, overlay buttons, pop-ups and clock hidden. Pull the invisible left edge to open the panel and pick another mode to exit.")
    fun get(c: Context) = Util.pref(c).getInt("mode", 1).coerceIn(0, names.size - 1)
    fun set(c: Context, i: Int) = Util.pref(c).edit().putInt("mode", i).apply()
    fun dnd(i: Int) = i >= 1
    fun awake(i: Int) = i >= 2
    fun autoSec(i: Int) = when (i) { 2 -> 60; 3 -> 30; 4 -> 45; else -> 0 }
}

/** Counts frames via Choreographer. Shows the real screen refresh/frame rate seen by the system. */
class FpsMeter {
    @Volatile var fps = 0
    private var frames = 0
    private var last = 0L
    private var running = false
    private val cb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            if (!running) return
            frames++
            if (last == 0L) last = t
            val dt = t - last
            if (dt >= 1000000000L) { fps = (frames * 1e9 / dt).roundToInt(); frames = 0; last = t }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
    fun start() { if (running) return; running = true; frames = 0; last = 0L; Choreographer.getInstance().postFrameCallback(cb) }
    fun stop() { running = false; fps = 0 }
}
