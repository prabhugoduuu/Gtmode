package com.prabhu.gamebooster

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Centre-screen "<MODE> MODE ENABLED" animation drawn over the game. Never takes touches, so the game stays playable. */
object ModeFx {
    private val ICONS = listOf("🍃", "⚖", "🎮", "🔥", "🏆")
    private val COLORS = intArrayOf(
        Color.parseColor("#2EE6A6"), Color.parseColor("#22D3EE"), Color.parseColor("#FF9F1C"),
        Color.parseColor("#FF4D4D"), Color.parseColor("#B36BFF"))

    private var current: View? = null
    private var currentWm: WindowManager? = null

    private class RingView(c: Context, val col: Int) : View(c) {
        var p = 0f
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(cv: Canvas) {
            val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) / 2f
            val cr = Color.red(col); val cg = Color.green(col); val cb = Color.blue(col)

            // dark disc so the text is readable over any game scene
            fillP.shader = null; fillP.color = Color.parseColor("#D0080A12")
            cv.drawCircle(cx, cy, r * 0.76f, fillP)

            // soft glow
            val glow = kotlin.math.sin(Math.PI * p.coerceIn(0f, 1f)).toFloat()
            fillP.shader = RadialGradient(cx, cy, r * 0.95f, Color.argb((110 * glow).toInt() + 20, cr, cg, cb), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, r * 0.95f, fillP)
            fillP.shader = null

            // expanding pulse rings
            paint.strokeCap = Paint.Cap.BUTT
            for (i in 0..2) {
                val t = p * 1.5f - i * 0.2f
                if (t <= 0f || t >= 1f) continue
                paint.strokeWidth = r * (0.012f + 0.03f * (1f - t))
                paint.color = Color.argb((200 * (1f - t)).toInt(), cr, cg, cb)
                cv.drawCircle(cx, cy, r * (0.4f + 0.6f * t), paint)
            }

            // progress arc that closes into a full ring
            val prog = (p * 1.5f).coerceIn(0f, 1f)
            val rr = r * 0.74f
            paint.strokeWidth = r * 0.045f; paint.strokeCap = Paint.Cap.ROUND; paint.color = col
            cv.drawArc(cx - rr, cy - rr, cx + rr, cy + rr, -90f, 360f * prog, false, paint)
        }
    }

    fun dismiss() {
        current?.let { try { currentWm?.removeView(it) } catch (e: Exception) {} }
        current = null
    }

    fun show(ctx: Context, mode: Int) {
        val c = ctx.applicationContext
        val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val h = Handler(Looper.getMainLooper())
        val i = mode.coerceIn(0, COLORS.size - 1)
        val col = COLORS[i]
        fun dp(v: Int) = Util.dp(c, v)
        dismiss()

        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            alpha = 0f; scaleX = 0.6f; scaleY = 0.6f
        }
        val box = FrameLayout(c)
        val ring = RingView(c, col)
        box.addView(ring, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val icon = TextView(c).apply { text = ICONS[i]; textSize = 30f; gravity = Gravity.CENTER; alpha = 0f; scaleX = 0.2f; scaleY = 0.2f }
        val name = TextView(c).apply {
            text = Modes.names[i]; textSize = 15f; typeface = Util.BOLD; setTextColor(Color.WHITE)
            letterSpacing = 0.08f; gravity = Gravity.CENTER; alpha = 0f
        }
        val state = TextView(c).apply {
            text = "MODE ENABLED"; textSize = 9.5f; typeface = Util.BOLD; setTextColor(col)
            letterSpacing = 0.2f; gravity = Gravity.CENTER; alpha = 0f; setPadding(0, dp(2), 0, 0)
        }
        val txt = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        txt.addView(icon); txt.addView(name); txt.addView(state)
        box.addView(txt, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        root.addView(box, LinearLayout.LayoutParams(dp(190), dp(190)))

        val sub = TextView(c).apply {
            text = Modes.desc[i].substringAfter(": "); textSize = 10.5f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(14), dp(6), dp(14), dp(6)); maxWidth = dp(300)
            background = Util.round(c, Color.parseColor("#D0080A12"), 14, Util.alpha(col, 0x99))
        }
        root.addView(sub, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })

        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.CENTER
        try { wm.addView(root, lp) } catch (e: Exception) { return }
        current = root; currentWm = wm

        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(OvershootInterpolator(1.4f)).start()
        icon.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(150).setDuration(380).setInterpolator(OvershootInterpolator(2.2f)).start()
        name.animate().alpha(1f).setStartDelay(300).setDuration(250).start()
        state.animate().alpha(1f).setStartDelay(520).setDuration(250).start()
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1700
            addUpdateListener { ring.p = it.animatedValue as Float; ring.invalidate() }
            start()
        }

        fun remove() { if (current === root) dismiss() else try { wm.removeView(root) } catch (e: Exception) {} }
        h.postDelayed({
            if (current === root) root.animate().alpha(0f).scaleX(1.15f).scaleY(1.15f).setDuration(350).withEndAction { remove() }.start()
        }, 2400)
        h.postDelayed({ remove() }, 3600)   // safety: never leave it on screen
    }
}
