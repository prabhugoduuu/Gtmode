package com.prabhu.gamebooster

import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.audiofx.Visualizer
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.View
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

/** Simple local music player (songs already on the phone) + audio levels for the animation. */
object Music {
    class Song(val id: Long, val title: String, val artist: String, val uri: Uri, val dur: Long)

    var songs: List<Song> = emptyList(); private set
    var index = -1; private set
    var onChange: (() -> Unit)? = null
    private var mp: MediaPlayer? = null
    private var viz: Visualizer? = null

    val playing: Boolean get() = try { mp?.isPlaying == true } catch (e: Exception) { false }
    val current: Song? get() = songs.getOrNull(index)

    fun perm() = if (Build.VERSION.SDK_INT >= 33) "android.permission.READ_MEDIA_AUDIO" else "android.permission.READ_EXTERNAL_STORAGE"
    fun hasPerm(c: Context) = c.packageManager.checkPermission(perm(), c.packageName) == PackageManager.PERMISSION_GRANTED

    var info = ""; private set

    private fun extras(c: Context): Set<String> = HashSet(Util.pref(c).getStringSet("music_extra", emptySet()) ?: emptySet())

    fun addExtras(c: Context, uris: List<Uri>) {
        val set = HashSet(extras(c)); uris.forEach { set.add(it.toString()) }
        Util.pref(c).edit().putStringSet("music_extra", set).apply()
    }

    fun extraCount(c: Context) = extras(c).size

    fun load(c: Context): List<Song> {
        val out = ArrayList<Song>()
        var err = ""
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        fun query(sel: String?) {
            try {
                val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
                c.contentResolver.query(base, proj, sel, null, null)?.use { cur ->
                    while (cur.moveToNext()) {
                        val id = cur.getLong(0)
                        val artist = cur.getString(2)?.takeIf { it != "<unknown>" } ?: "Unknown artist"
                        out.add(Song(id, cur.getString(1) ?: "Unknown", artist, ContentUris.withAppendedId(base, id), cur.getLong(3)))
                    }
                }
            } catch (e: Exception) { err = e.javaClass.simpleName }
        }
        query("${MediaStore.Audio.Media.DURATION} > 20000 AND ${MediaStore.Audio.Media.IS_RINGTONE} = 0 AND " +
            "${MediaStore.Audio.Media.IS_NOTIFICATION} = 0 AND ${MediaStore.Audio.Media.IS_ALARM} = 0")
        if (out.isEmpty()) query(null)
        val found = out.size
        for (str in extras(c)) {
            val u = Uri.parse(str)
            var name = u.lastPathSegment ?: "Song"
            try { c.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: name } } catch (e: Exception) {}
            out.add(Song(-1, name.substringBeforeLast('.'), "Added by you", u, 0))
        }
        out.sortBy { it.title.lowercase() }
        info = "Phone library: $found" + (if (err.isNotEmpty()) " ($err)" else "") + "  |  added by you: ${out.size - found}"
        val curUri = current?.uri
        songs = out
        if (curUri != null) index = out.indexOfFirst { it.uri == curUri }
        return out
    }

    fun play(c: Context, i: Int) {
        val s = songs.getOrNull(i) ?: return
        val app = c.applicationContext
        release()
        index = i
        try {
            val p = MediaPlayer()
            p.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            p.setDataSource(app, s.uri)
            p.setOnCompletionListener { next(app) }
            p.setOnErrorListener { _, _, _ -> true }
            p.prepare(); p.start(); mp = p
            try {
                val v = Visualizer(p.audioSessionId)
                val r = Visualizer.getCaptureSizeRange()
                v.captureSize = if (256 in r[0]..r[1]) 256 else r[0]
                v.enabled = true; viz = v
            } catch (e: Exception) { viz = null }   // no mic permission -> simulated animation
        } catch (e: Exception) { release() }
        onChange?.invoke()
    }

    fun toggle(c: Context) {
        val p = mp
        if (p == null) { play(c, if (index >= 0) index else 0); return }
        try { if (p.isPlaying) p.pause() else p.start() } catch (e: Exception) {}
        onChange?.invoke()
    }

    fun next(c: Context) { if (songs.isNotEmpty()) play(c, (index + 1) % songs.size) }
    fun prev(c: Context) {
        if (songs.isEmpty()) return
        if (position() > 3000) seekTo(0) else play(c, (if (index <= 0) songs.size else index) - 1)
    }

    fun position(): Int = try { mp?.currentPosition ?: 0 } catch (e: Exception) { 0 }
    fun duration(): Int = try { mp?.duration ?: (current?.dur?.toInt() ?: 0) } catch (e: Exception) { 0 }
    fun seekTo(ms: Int) { try { mp?.seekTo(ms) } catch (e: Exception) {} }

    private fun release() {
        try { viz?.release() } catch (e: Exception) {}
        viz = null
        try { mp?.release() } catch (e: Exception) {}
        mp = null
    }

    fun stop() { release(); onChange = null }

    /** Fills [out] with 0..1 bar heights (real audio when possible, otherwise a lively simulation). */
    fun levels(out: FloatArray) {
        val n = out.size
        java.util.Arrays.fill(out, 0f)
        if (!playing) return
        val v = viz
        if (v != null) {
            try {
                val size = v.captureSize
                val fft = ByteArray(size); v.getFft(fft)
                val bins = size / 2
                var total = 0f
                for (b in 0 until n) {
                    val lo = 1 + ((bins - 2) * (b.toDouble() / n) * (b.toDouble() / n)).toInt()
                    val hi = maxOf(lo + 1, 1 + ((bins - 2) * ((b + 1.0) / n) * ((b + 1.0) / n)).toInt())
                    var m = 0.0
                    for (k in lo until minOf(hi, bins)) m = maxOf(m, hypot(fft[2 * k].toDouble(), fft[2 * k + 1].toDouble()))
                    out[b] = sqrt(m / 140.0).toFloat().coerceIn(0f, 1f)
                    total += out[b]
                }
                if (total > 0.05f) return
            } catch (e: Exception) {}
        }
        val t = System.currentTimeMillis() / 1000.0
        for (b in 0 until n) out[b] = (0.30 + 0.28 * sin(t * 4.1 + b * 0.55) + 0.22 * sin(t * 7.3 + b * 1.3)).toFloat().coerceIn(0.05f, 1f)
    }
}

/** Dancing equalizer bars. Moves with the music while a song plays. */
class EqView(c: Context) : View(c) {
    private val n = 28
    private val lv = FloatArray(n)
    private val bars = FloatArray(n)
    private val peaks = FloatArray(n)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cap = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CCFFFFFF") }
    private val r = RectF()
    private var running = false
    private val step = object : Runnable { override fun run() { if (!running) return; invalidate(); postOnAnimation(this) } }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; postOnAnimation(step) }
    override fun onDetachedFromWindow() { running = false; super.onDetachedFromWindow() }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), Util.dp(context, 86)) }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        p.shader = LinearGradient(0f, h.toFloat(), 0f, 0f, Util.ACC, Color.parseColor("#FFE082"), Shader.TileMode.CLAMP)
    }

    override fun onDraw(cv: Canvas) {
        Music.levels(lv)
        val w = width.toFloat(); val h = height.toFloat()
        val gap = w / n * 0.3f; val bw = (w - gap * (n - 1)) / n
        for (i in 0 until n) {
            bars[i] = if (lv[i] > bars[i]) lv[i] else bars[i] * 0.88f
            peaks[i] = if (bars[i] > peaks[i]) bars[i] else maxOf(0f, peaks[i] - 0.012f)
            val bh = maxOf(bw, bars[i] * (h - bw))
            val x = i * (bw + gap)
            r.set(x, h - bh, x + bw, h); cv.drawRoundRect(r, bw / 2, bw / 2, p)
            if (peaks[i] > 0.08f) { val y = h - peaks[i] * (h - bw) - bw * 1.4f; r.set(x, y, x + bw, y + bw * 0.5f); cv.drawRoundRect(r, bw / 4, bw / 4, cap) }
        }
    }
}
