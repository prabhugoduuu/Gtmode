package com.prabhu.gamebooster

import android.content.Context
import android.graphics.*
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/** Neon ring gauge: glowing sweep-gradient arc over a glass disc. */
class GaugeView(c: Context) : View(c) {
    var label = ""
    var unit = ""
    private var value = -1
    private var txt = "--"
    private var col = Util.ACC
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val mx = Matrix()

    fun set(v: Int, t: String, color: Int) { value = v; txt = t; col = color; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        val s = MeasureSpec.getSize(w); setMeasuredDimension(s, (s * 1.2f).toInt())
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val st = w * 0.085f; val pad = st * 1.6f
        val cx = w / 2; val cy = w / 2
        rect.set(pad, pad, w - pad, w - pad)
        // glass disc
        p.shader = null; p.style = Paint.Style.FILL
        p.color = Color.parseColor("#14FFFFFF"); cv.drawCircle(cx, cy, (w - pad * 2) / 2 - st * 0.9f, p)
        // track
        p.style = Paint.Style.STROKE; p.strokeWidth = st; p.strokeCap = Paint.Cap.ROUND
        p.color = Color.parseColor("#1FFFFFFF"); cv.drawArc(rect, 135f, 270f, false, p)
        if (value >= 0) {
            val sweep = 270f * value.coerceIn(2, 100) / 100f
            // soft glow
            p.strokeWidth = st * 2.0f; p.color = Util.alpha(col, 0x26); cv.drawArc(rect, 135f, sweep, false, p)
            // gradient arc
            p.strokeWidth = st
            val dim = Util.alpha(col, 0x66)
            val sg = SweepGradient(cx, cy, intArrayOf(dim, col, col), floatArrayOf(0f, 0.75f, 1f))
            mx.reset(); mx.setRotate(135f, cx, cy); sg.setLocalMatrix(mx)
            p.shader = sg; cv.drawArc(rect, 135f, sweep, false, p); p.shader = null
        }
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.color = Color.WHITE; p.typeface = Util.HEAD; p.textSize = w * 0.25f
        cv.drawText(txt, cx, w * 0.55f, p)
        p.color = col; p.typeface = Util.BOLD; p.textSize = w * 0.11f
        cv.drawText(unit, cx, w * 0.70f, p)
        p.color = Util.MUTED; p.typeface = Util.BOLD; p.textSize = w * 0.105f; p.letterSpacing = 0.1f
        cv.drawText(label, cx, w * 1.1f, p); p.letterSpacing = 0f
    }
}

/** Horizontal usage bar (CPU / GPU / RAM / TEMP) with a gradient fill. */
class BarView(c: Context, private val label: String) : View(c) {
    private var pct = 0
    private var txt = "--"
    private var col = Util.GREEN
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    fun set(v: Int, t: String, color: Int) { pct = v; txt = t; col = color; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Util.dp(context, 34))
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val d = Util.dp(context, 1).toFloat()
        p.shader = null; p.style = Paint.Style.FILL; p.typeface = Util.BOLD
        p.textSize = d * 10f; p.letterSpacing = 0.12f
        p.textAlign = Paint.Align.LEFT; p.color = Util.MUTED
        cv.drawText(label, 0f, h * 0.44f, p)
        p.letterSpacing = 0f; p.textSize = d * 12f
        p.textAlign = Paint.Align.RIGHT; p.color = Color.WHITE
        cv.drawText(txt, w, h * 0.44f, p)
        val top = h - d * 11f; val bot = h - d * 4f
        p.color = Color.parseColor("#1FFFFFFF"); r.set(0f, top, w, bot); cv.drawRoundRect(r, d * 4, d * 4, p)
        if (pct >= 0) {
            val end = w * pct.coerceIn(3, 100) / 100f
            p.shader = LinearGradient(0f, 0f, end.coerceAtLeast(1f), 0f, Util.alpha(col, 0x80), col, Shader.TileMode.CLAMP)
            r.set(0f, top, end, bot); cv.drawRoundRect(r, d * 4, d * 4, p); p.shader = null
        }
    }
}

/** Slim edge handle (pull tab) in the theme colour. */
class HandleView(c: Context) : View(c) {
    var heat = Util.ACC
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onDraw(cv: Canvas) {
        val d = Util.dp(context, 1).toFloat()
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#EE05070D"); p.setShadowLayer(d * 6f, 0f, 0f, heat)
        r.set(-d * 12f, d * 4f, w - d * 7f, h - d * 4f)
        cv.drawRoundRect(r, d * 12f, d * 12f, p)
        p.clearShadowLayer()
        p.shader = LinearGradient(0f, h * 0.5f - d * 16f, 0f, h * 0.5f + d * 16f, heat, Util.ACC2, Shader.TileMode.CLAMP)
        r.set(w - d * 12f, h * 0.5f - d * 16f, w - d * 9f, h * 0.5f + d * 16f)
        cv.drawRoundRect(r, d * 2f, d * 2f, p); p.shader = null
    }
}

/** Segmented control (Power-saving / Balanced / Pro gamer ...). */
class SegmentView(c: Context, labels: List<String>, private val onPick: (Int) -> Unit) : LinearLayout(c) {
    private val items = ArrayList<TextView>()

    init {
        orientation = HORIZONTAL
        val d = Util.dp(c, 1)
        setPadding(d * 3, d * 3, d * 3, d * 3)
        background = Util.round(c, Color.parseColor("#B0080C18"), 18, Color.parseColor("#22FFFFFF"))
        labels.forEachIndexed { i, l ->
            val t = TextView(c).apply {
                text = l; textSize = if (labels.size > 4) 9f else 10.5f; gravity = Gravity.CENTER; typeface = Util.BOLD; letterSpacing = 0.02f; maxLines = 1
                setTextColor(Util.MUTED); setPadding(d * 2, d * 11, d * 2, d * 11)
                layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { select(i); onPick(i) }
            }
            items.add(t); addView(t)
        }
    }

    fun select(i: Int) {
        items.forEachIndexed { k, t ->
            if (k == i) { t.background = Util.accGrad(context, 15); t.setTextColor(Util.ON_ACC) }
            else { t.background = null; t.setTextColor(Util.MUTED) }
        }
    }
}

/** Icon-over-label action tile. setOn() lights it up with the accent. */
class TileView(c: Context, icon: String, label: String, private val onClick: () -> Unit) : LinearLayout(c) {
    private val ic = TextView(c)
    private val tx = TextView(c)
    private var on = false

    init {
        orientation = VERTICAL; gravity = Gravity.CENTER
        val d = Util.dp(c, 1)
        setPadding(d * 4, d * 14, d * 4, d * 12)
        ic.text = icon; ic.textSize = 22f; ic.gravity = Gravity.CENTER
        tx.text = label; tx.textSize = 9.5f; tx.typeface = Util.BOLD; tx.gravity = Gravity.CENTER
        tx.letterSpacing = 0.05f; tx.maxLines = 2; tx.setPadding(0, d * 4, 0, 0)
        addView(ic, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(tx, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        paint()
        setOnTouchListener { v, e -> v.alpha = if (e.action == MotionEvent.ACTION_DOWN) 0.65f else 1f; false }
        setOnClickListener { onClick() }
    }

    private fun paint() {
        background = if (on) Util.glassOn(context, 18) else Util.glass(context, 18)
        tx.setTextColor(if (on) Util.ACC else Color.WHITE)
    }

    fun setLabel(t: String) { tx.text = t }
    fun setIcon(t: String) { ic.text = t }
    fun setOn(v: Boolean) { on = v; paint() }
}
