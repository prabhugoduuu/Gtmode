package com.prabhu.gamebooster

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.graphics.Typeface
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private val meter = FpsMeter()
    private lateinit var gFps: GaugeView
    private lateinit var gBat: GaugeView
    private lateinit var gNet: GaugeView
    private lateinit var bCpu: BarView
    private lateinit var bGpu: BarView
    private lateinit var bRam: BarView
    private lateinit var bTemp: BarView
    private lateinit var info: TextView
    private lateinit var result: TextView
    private lateinit var modeDesc: TextView
    private lateinit var seg: SegmentView
    private lateinit var gameSub: TextView
    private lateinit var gameTag: TextView
    private lateinit var ovBtn: TileView
    private lateinit var voiceBtn: TileView
    private lateinit var pitchBtn: TileView
    private lateinit var setupBox: LinearLayout
    private val pitches = floatArrayOf(0.75f, 1.0f, 1.3f, 1.6f)
    private val pitchNames = arrayOf("Deep", "Normal", "High", "Chipmunk")
    private var pi = 1
    private var gpuName = "Detecting..."
    @Volatile private var ping = -1L
    private var alive = true

    private fun dp(v: Int) = Util.dp(this, v)
    private fun full() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(2), dp(6), dp(2), dp(6)) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
        background = Util.glass(this@MainActivity, 22)
        layoutParams = full()
    }

    private fun section(t: String) = Util.sectionHeader(this, t)

    private fun gradText(t: TextView) {
        t.post { t.paint.shader = LinearGradient(0f, 0f, t.paint.measureText(t.text.toString()), 0f, Util.ACC, Util.ACC2, Shader.TileMode.CLAMP); t.invalidate() }
    }

    private fun syncOv() { ovBtn.setLabel(if (OverlayService.running) "STOP OVERLAY" else "START OVERLAY"); ovBtn.setOn(OverlayService.running) }

    private fun changeTheme(i: Int) {
        Util.setTheme(this, i)
        OverlayService.refreshTheme?.invoke()
        recreate()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Util.initTheme(this)
        window.statusBarColor = Util.BG; window.navigationBarColor = Util.BG
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(34), dp(14), dp(30)) }

        // ---- top bar ----
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), 0, dp(2), dp(8)) }
        top.addView(TextView(this).apply {
            text = "⚡"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(Util.ON_ACC)
            background = Util.accGrad(this@MainActivity, 15)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(12) } })
        val tt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tt.addView(TextView(this).apply { text = "PRABHU"; textSize = 10.5f; setTextColor(Util.ACC); typeface = Util.BOLD; letterSpacing = 0.45f })
        val gb = TextView(this).apply { text = "GAME BOOSTER"; textSize = 22f; typeface = Util.HEAD; setTextColor(Color.WHITE); letterSpacing = 0.04f }
        gradText(gb); tt.addView(gb)
        top.addView(tt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(TextView(this).apply {
            text = "v5.0  •  NEON"; textSize = 9.5f; typeface = Util.BOLD; setTextColor(Util.MUTED); letterSpacing = 0.06f
            setPadding(dp(10), dp(6), dp(10), dp(6)); background = Util.glass(this@MainActivity, 12) })
        root.addView(top)

        // ---- hero: game + big play button ----
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Util.alpha(Util.ACC, 0x40), Util.alpha(Util.ACC2, 0x1A), Color.parseColor("#F00D1322")))
                .apply { cornerRadius = dp(26).toFloat(); setStroke(dp(1), Util.alpha(Util.ACC, 0xAA)) }
            layoutParams = full()
        }
        val gr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        gr.addView(TextView(this).apply {
            text = "FF"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(Util.ON_ACC); typeface = Util.HEAD; letterSpacing = 0.05f
            background = Util.accGrad(this@MainActivity, 18)
            layoutParams = LinearLayout.LayoutParams(dp(58), dp(58)).apply { rightMargin = dp(14) } })
        val gt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        gt.addView(TextView(this).apply { text = Util.GAME_NAME; textSize = 18f; typeface = Util.HEAD; setTextColor(Color.WHITE) })
        gameSub = TextView(this).apply { textSize = 11.5f; setTextColor(Util.MUTED) }
        gt.addView(gameSub)
        gr.addView(gt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        gameTag = TextView(this).apply { textSize = 10f; typeface = Util.BOLD; letterSpacing = 0.08f; setPadding(dp(12), dp(6), dp(12), dp(6)) }
        gr.addView(gameTag)
        gr.setOnClickListener { if (!Util.gameInstalled(this)) Util.openStore(this) }
        hero.addView(gr)
        hero.addView(Util.primary(this, "BOOST  &  PLAY") { doBoost(true) }.apply {
            textSize = 16f; layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) } })
        root.addView(hero)
        result = TextView(this).apply {
            textSize = 13.5f; setTextColor(Color.WHITE); visibility = View.GONE; setLineSpacing(0f, 1.2f)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = Util.round(this@MainActivity, Color.parseColor("#0F2A22"), 18, Util.GREEN); layoutParams = full() }
        root.addView(result)

        // ---- live stats ----
        root.addView(section("LIVE STATS"))
        val rings = card()
        fun ring(l: String, u: String) = GaugeView(this).apply {
            label = l; unit = u
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), 0, dp(4), 0) } }
        gFps = ring("FRAME RATE", "Hz"); gBat = ring("BATTERY", "%"); gNet = ring("NETWORK", "ms")
        rings.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(gFps); addView(gBat); addView(gNet) })
        root.addView(rings)

        // ---- quick actions (3 x 3 tiles) ----
        root.addView(section("QUICK ACTIONS"))
        ovBtn = TileView(this, "🧩", "START OVERLAY") { toggleOverlay() }
        voiceBtn = TileView(this, "🎙", "VOICE OFF") {
            if (!Util.hasMic(this)) askMic() else {
                val on = VoiceEngine.toggle(); voiceBtn.setLabel(if (on) "VOICE ON" else "VOICE OFF"); voiceBtn.setOn(on)
                if (on) toast("Use earphones to avoid echo") } }
        pitchBtn = TileView(this, "🎚", "PITCH: Normal") {
            pi = (pi + 1) % pitches.size; VoiceEngine.pitch = pitches[pi]; pitchBtn.setLabel("PITCH: ${pitchNames[pi]}") }
        val tiles = listOf(
            TileView(this, "🚀", "BOOST NOW") { doBoost(false) },
            ovBtn,
            TileView(this, "🎮", "OPEN GAME") {
                GtIntro.play(this, { Util.launchGame(this) }) { toast("${Util.GAME_NAME} not installed"); Util.openStore(this) } },
            voiceBtn, pitchBtn,
            TileView(this, "📶", "FIX PING (DNS)") {
                result.visibility = View.VISIBLE
                result.text = "Set Private DNS to:\ndns.google\nor 1dot1dot1dot1.cloudflare-dns.com"
                startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) },
            TileView(this, "🔋", "BATTERY SAVER") {
                if (PowerTools.batterySaver(this)) toast("Battery saver ON") else toast("Switch Battery saver ON here") },
            TileView(this, "🔌", "CHARGE MODE") { PowerTools.startCharge(this) },
            TileView(this, "🎨", "THEME: ${Util.THEMES[Util.themeIdx].name}") { changeTheme((Util.themeIdx + 1) % Util.THEMES.size) })
        tiles.chunked(3).forEach { rowTiles ->
            root.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                rowTiles.forEach { t -> addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }) } })
        }

        // ---- performance mode ----
        root.addView(section("PERFORMANCE MODE"))
        val mc = card()
        seg = SegmentView(this, Modes.names) { Modes.set(this, it); modeDesc.text = Modes.desc[it] }
        seg.select(Modes.get(this))
        mc.addView(seg, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        modeDesc = TextView(this).apply { textSize = 11.5f; setTextColor(Util.MUTED); setPadding(dp(4), dp(8), dp(4), 0); text = Modes.desc[Modes.get(this@MainActivity)] }
        mc.addView(modeDesc)
        root.addView(mc)

        // ---- system ----
        root.addView(section("SYSTEM"))
        val sys = card()
        bCpu = BarView(this, "CPU"); bGpu = BarView(this, "GPU"); bRam = BarView(this, "RAM"); bTemp = BarView(this, "TEMP")
        sys.addView(bCpu); sys.addView(bGpu); sys.addView(bRam); sys.addView(bTemp)
        info = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 10.5f; setTextColor(Color.parseColor("#BFCBE6")); setLineSpacing(0f, 1.25f)
            setPadding(0, dp(10), 0, 0) }
        sys.addView(info)
        root.addView(sys)

        // ---- setup ----
        root.addView(section("SETUP"))
        setupBox = card(); root.addView(setupBox)

        // ---- theme ----
        root.addView(section("THEME"))
        val tc = card()
        tc.addView(Util.themeRow(this) { changeTheme(it) })
        root.addView(tc)

        root.addView(TextView(this).apply {
            text = "Frame rate = the screen's real refresh rate measured live (reading the game's own FPS needs root). Boost cleans background apps, turns on Do Not Disturb and keeps the screen awake per mode. It does not overclock the CPU/GPU. Some phones block CPU/GPU load readings; those show \"--\"."
            textSize = 10.5f; setTextColor(Util.MUTED); setPadding(dp(4), dp(14), dp(4), 0) })

        setContentView(ScrollView(this).apply { addView(root); background = Util.screenBg(); isVerticalScrollBarEnabled = false })

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        if (intent?.getBooleanExtra("ask_music", false) == true) askMusic()
        if (intent?.getBooleanExtra("pick_music", false) == true) pickSongs()
        Thread { val n = SysInfo.gpuName(); h.post { gpuName = n } }.start()
        tick()
    }

    override fun onResume() { super.onResume(); meter.start(); refreshAll() }
    override fun onPause() { meter.stop(); super.onPause() }

    private fun refreshAll() { refreshGame(); refreshSetup(); syncOv() }

    private fun refreshGame() {
        val ok = Util.gameInstalled(this)
        gameSub.text = if (ok) "Installed  •  ready to boost" else "Not installed  •  tap to open Google Play"
        gameTag.text = if (ok) "● READY" else "INSTALL"
        gameTag.setTextColor(if (ok) Util.GREEN else Util.AMBER)
        gameTag.background = Util.round(this, Util.alpha(if (ok) Util.GREEN else Util.AMBER, 0x22), 12, Util.alpha(if (ok) Util.GREEN else Util.AMBER, 0x66))
    }

    private fun setupRow(title: String, sub: String, ok: Boolean, onClick: () -> Unit): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(7), 0, dp(7)) }
        row.addView(View(this).apply {
            background = Util.round(this@MainActivity, if (ok) Util.GREEN else Util.alpha(Util.MUTED, 0x88), 5)
            layoutParams = LinearLayout.LayoutParams(dp(9), dp(9)).apply { rightMargin = dp(12) } })
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tx.addView(TextView(this).apply { text = title; textSize = 13f; typeface = Util.BOLD; setTextColor(Color.WHITE) })
        tx.addView(TextView(this).apply { text = sub; textSize = 10.5f; setTextColor(Util.MUTED) })
        row.addView(tx, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = if (ok) "✓ ON" else "ENABLE"; textSize = 10.5f; typeface = Util.BOLD; gravity = Gravity.CENTER; letterSpacing = 0.06f
            setTextColor(if (ok) Util.GREEN else Util.ON_ACC); setPadding(dp(14), dp(8), dp(14), dp(8))
            background = if (ok) Util.round(this@MainActivity, Util.alpha(Util.GREEN, 0x22), 12, Util.alpha(Util.GREEN, 0x66)) else Util.accGrad(this@MainActivity, 12)
            setOnClickListener { if (!ok) onClick() } })
        return row
    }

    private fun refreshSetup() {
        val ov = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val dn = Build.VERSION.SDK_INT < 23 || nm.isNotificationPolicyAccessGranted
        setupBox.removeAllViews()
        setupBox.addView(setupRow("Display over other apps", "Required for the in-game GT panel", ov) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) })
        setupBox.addView(setupRow("Usage access", "Shows the panel only inside ${Util.GAME_NAME} + auto-boost", Util.hasUsage(this)) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        setupBox.addView(setupRow("Do Not Disturb access", "Silences notifications while gaming", dn) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) })
        setupBox.addView(setupRow("Music files", "Needed for the music player", Music.hasPerm(this)) { askMusic() })
        setupBox.addView(setupRow("Microphone", "Only for the voice changer (optional)", Util.hasMic(this)) { askMic() })
    }

    private fun askMusic() { if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Music.perm()), 3) }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i); setIntent(i)
        if (i?.getBooleanExtra("ask_music", false) == true) askMusic()
        if (i?.getBooleanExtra("pick_music", false) == true) pickSongs()
    }

    private fun pickSongs() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try { startActivityForResult(i, 77) } catch (e: Exception) { toast("No file picker found") }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 77 || res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.clipData?.let { cd -> for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri) }
        data.data?.let { if (uris.isEmpty()) uris.add(it) }
        for (u in uris) try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
        Music.addExtras(this, uris)
        toast("${uris.size} song(s) added. Open the MUSIC tab.")
    }

    private fun askMic() { if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2) }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r); refreshSetup()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun tick() {
        if (!alive) return
        val cpu = SysInfo.cpuLoad(); val gpu = SysInfo.gpuLoad(); val ram = Util.ramPercent(this); val t = Util.temp(this)
        val fps = meter.fps; val bat = Util.battery(this); val maxHz = Util.displayHz(this)
        gFps.set(if (fps <= 0) -1 else (fps * 100 / maxHz).coerceAtMost(100), if (fps <= 0) "--" else "$fps", Util.ACC)
        gBat.set(bat, "$bat", if (bat < 20) Util.RED else Util.GREEN)
        val nc = if (ping < 0) Util.MUTED else if (ping < 60) Util.GREEN else if (ping < 120) Util.ORANGE else Util.RED
        gNet.set(if (ping < 0) -1 else (100 - ping / 2).toInt().coerceIn(5, 100), if (ping < 0) "--" else "$ping", nc)
        bCpu.set(cpu, if (cpu < 0) "--" else "$cpu%", Util.loadColor(cpu))
        bGpu.set(gpu, if (gpu < 0) "--" else "$gpu%", Util.loadColor(gpu))
        bRam.set(ram, "$ram%", Util.loadColor(ram))
        bTemp.set(((t - 25f) / 25f * 100).toInt().coerceIn(0, 100), "%.0f°C".format(t), if (t >= 42) Util.RED else if (t >= 38) Util.ORANGE else Util.GREEN)
        val f = SysInfo.cpuFreq()
        info.text = "DEVICE   ${Build.MANUFACTURER} ${Build.MODEL}  |  Android ${Build.VERSION.RELEASE}\n" +
            "CPU      ${SysInfo.cpuName()}  |  ${SysInfo.cores} cores" + (if (f != null) "  |  ${f[0]}/${f[1]} MHz" else "") + "\n" +
            "GPU      $gpuName\n" +
            "MEMORY   ${Util.totalRam(this)}\n" +
            "STATUS   Thermal ${SysInfo.thermal(this)}"
        Util.ping { ping = it }
        syncOv()
        h.postDelayed({ tick() }, 2000)
    }

    private fun doBoost(play: Boolean) {
        result.visibility = View.VISIBLE; result.text = "Boosting..."
        val mode = Modes.get(this)
        if (play && !OverlayService.running && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) startOverlay(false)
        Util.boost(this) { freed, avail ->
            val dnd = Modes.dnd(mode) && Util.dnd(this, true)
            val t = Util.temp(this)
            result.text = "GAME BOOSTED  |  ${Modes.names[mode]}\n\n" +
                (if (freed > 0) "RAM freed: $freed MB" else "RAM already clean") +
                "\nFree RAM: $avail MB\nTemperature: %.0f°C".format(t) + (if (dnd) "\nDo Not Disturb: ON" else "") +
                (if (t >= 42) "\nPhone is hot. Take a short break." else "")
            result.alpha = 0f; result.scaleX = 0.92f; result.scaleY = 0.92f
            result.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(300).start()
            if (play) GtIntro.play(this, { Util.launchGame(this) }) { result.append("\n${Util.GAME_NAME} not found on this phone."); Util.openStore(this) }
        }
    }

    private fun toggleOverlay() {
        if (OverlayService.running) { stopService(Intent(this, OverlayService::class.java)); ovBtn.setLabel("START OVERLAY"); ovBtn.setOn(false) }
        else startOverlay(true)
    }

    private fun startOverlay(say: Boolean) {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { toast("Enable 'Display over other apps' first"); return }
        val i = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        ovBtn.setLabel("STOP OVERLAY"); ovBtn.setOn(true)
        if (say) toast("Overlay started. Open ${Util.GAME_NAME} and pull the orange edge handle.")
    }

    override fun onDestroy() { alive = false; meter.stop(); h.removeCallbacksAndMessages(null); super.onDestroy() }
}
