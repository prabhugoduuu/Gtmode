package com.prabhu.gamebooster

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Surface
import android.view.TextureView
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout

/**
 * Full-screen launch animation shown just before Free Fire India opens: a fire phoenix (no text), about 6.6 s.
 * Drawn live by PhoenixView. The clip res/raw/intro_phoenix.mp4 (user's phoenix video) is played when present.
 * The game is launched under the white flash at ~5.4 s, then the overlay fades out.
 */
object GtIntro {
    @Volatile private var playing = false
    private const val TOTAL_MS = 6600L
    private const val LAUNCH_AT = 5400L
    private const val FADE_AT = 5900L

    fun play(ctx: Context, launch: () -> Boolean, onFail: () -> Unit) {
        val c = ctx.applicationContext
        if (playing) return
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(c)) { if (!launch()) onFail(); return }
        playing = true
        val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val h = Handler(Looper.getMainLooper())

        val root = FrameLayout(c).apply { setBackgroundColor(Color.parseColor("#FF030100")); alpha = 0f; setOnTouchListener { _, _ -> true } }
        var mp: MediaPlayer? = null
        var phoenix: PhoenixView? = null
        val resId = c.resources.getIdentifier("intro_phoenix", "raw", c.packageName)
        if (resId != 0) {
            val tv = TextureView(c)
            tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, hh: Int) {
                    try {
                        mp = MediaPlayer.create(c, resId)?.apply { setSurface(Surface(st)); isLooping = false; start() }
                        // centre-crop the 16:9 clip so it fills any screen without stretching
                        val m = mp
                        if (m != null && m.videoWidth > 0 && m.videoHeight > 0 && w > 0 && hh > 0) {
                            val vr = m.videoWidth.toFloat() / m.videoHeight; val wr = w.toFloat() / hh
                            val mx = android.graphics.Matrix()
                            if (wr > vr) mx.setScale(1f, wr / vr, w / 2f, hh / 2f) else mx.setScale(vr / wr, 1f, w / 2f, hh / 2f)
                            tv.setTransform(mx)
                        }
                    } catch (e: Exception) {}
                }
                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, hh: Int) {}
                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { try { mp?.release() } catch (e: Exception) {}; mp = null; return true }
                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
            root.addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            phoenix = PhoenixView(c)
            root.addView(phoenix, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }

        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT)
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        try { wm.addView(root, lp) } catch (e: Exception) { playing = false; if (!launch()) onFail(); return }

        var anim: ValueAnimator? = null
        fun remove() {
            anim?.cancel()
            try { mp?.release() } catch (e: Exception) {}; mp = null
            try { wm.removeView(root) } catch (e: Exception) {}
            playing = false
        }

        root.animate().alpha(1f).setDuration(120).start()
        if (phoenix != null) {
            val pv = phoenix
            anim = ValueAnimator.ofFloat(0f, TOTAL_MS / 1000f).apply {
                duration = TOTAL_MS; interpolator = LinearInterpolator()
                addUpdateListener { pv.update(it.animatedValue as Float) }
                start()
            }
        }
        h.postDelayed({ if (!launch()) { onFail(); remove() } }, LAUNCH_AT)
        h.postDelayed({ root.animate().alpha(0f).setDuration(600).withEndAction { remove() }.start() }, FADE_AT)
        h.postDelayed({ remove() }, 9000)   // safety: never leave the screen covered
    }
}
