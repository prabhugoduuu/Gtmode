package com.prabhu.gamebooster

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Surface
import android.view.View
import android.view.TextureView
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout

/**
 * Full-screen launch animation shown just before Free Fire India opens:
 *   0 - 6.7 s  fire phoenix (res/raw/intro_phoenix.mp4 when present, otherwise drawn by PhoenixView)
 *   6.7 - 8.7 s  "GT MODE ACTIVATED" burst (GtModeView)
 * The game is launched under the GT burst at ~7.8 s, then the overlay fades out.
 */
object GtIntro {
    @Volatile private var playing = false
    private const val CLIP_MS = 6700L      // phoenix video / drawn phoenix
    private const val GT_MS = 2000L        // GT MODE animation
    private const val TOTAL_MS = CLIP_MS + GT_MS
    private const val LAUNCH_AT = CLIP_MS + 1100L
    private const val FADE_AT = CLIP_MS + 1600L

    fun play(ctx: Context, launch: () -> Boolean, onFail: () -> Unit) {
        val c = ctx.applicationContext
        if (playing) return
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(c)) { if (!launch()) onFail(); return }
        playing = true
        val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val h = Handler(Looper.getMainLooper())

        val root = FrameLayout(c).apply { setBackgroundColor(Color.parseColor("#FF030100")); alpha = 0f; setOnTouchListener { _, _ -> true } }
        var mp: MediaPlayer? = null
        var phoenix: PhoenixView? = null
        var clipView: View? = null
        val gt = GtModeView(c).apply { visibility = View.GONE }
        val resId = c.resources.getIdentifier("intro_phoenix", "raw", c.packageName)
        if (resId != 0) {
            val tv = TextureView(c)
            tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, hh: Int) {
                    try {
                        mp = MediaPlayer.create(c, resId)?.apply { setSurface(Surface(st)); isLooping = false; start() }
                        // centre-crop the 16:9 clip so it fills any screen without stretching
                        val m = mp
                        if (m != null && m.videoWidth > 0 && m.videoHeight > 0 && w > 0 && hh > 0) {
                            val vr = m.videoWidth.toFloat() / m.videoHeight; val wr = w.toFloat() / hh
                            val mx = android.graphics.Matrix()
                            if (wr > vr) mx.setScale(1f, wr / vr, w / 2f, hh / 2f) else mx.setScale(vr / wr, 1f, w / 2f, hh / 2f)
                            tv.setTransform(mx)
                        }
                    } catch (e: Exception) {}
                }
                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, hh: Int) {}
                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { try { mp?.release() } catch (e: Exception) {}; mp = null; return true }
                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
            root.addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            clipView = tv
        } else {
            phoenix = PhoenixView(c)
            root.addView(phoenix, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            clipView = phoenix
        }
        root.addView(gt, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT)
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        try { wm.addView(root, lp) } catch (e: Exception) { playing = false; if (!launch()) onFail(); return }

        var anim: ValueAnimator? = null
        fun remove() {
            anim?.cancel()
            try { mp?.release() } catch (e: Exception) {}; mp = null
            try { wm.removeView(root) } catch (e: Exception) {}
            playing = false
        }

        root.animate().alpha(1f).setDuration(120).start()
        anim = ValueAnimator.ofFloat(0f, TOTAL_MS / 1000f).apply {
            duration = TOTAL_MS; interpolator = LinearInterpolator()
            addUpdateListener {
                val sec = it.animatedValue as Float
                if (sec < CLIP_MS / 1000f) phoenix?.update(sec)
                else {
                    if (gt.visibility != View.VISIBLE) {
                        gt.visibility = View.VISIBLE
                        clipView?.visibility = View.GONE
                        try { mp?.release() } catch (e: Exception) {}; mp = null
                    }
                    gt.update(sec - CLIP_MS / 1000f)
                }
            }
            start()
        }
        h.postDelayed({ if (!launch()) { onFail(); remove() } }, LAUNCH_AT)
        h.postDelayed({ root.animate().alpha(0f).setDuration(600).withEndAction { remove() }.start() }, FADE_AT)
        h.postDelayed({ remove() }, 11000)   // safety: never leave the screen covered
    }
}
