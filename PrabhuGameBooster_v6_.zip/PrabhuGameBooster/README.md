# Prabhu Game Booster  v4.0 (GT Mode)  -  Free Fire India only

Target game package: `com.garena.game.ffi` (Free Fire India). Global / MAX are not boosted or launched.

## Build (no PC needed)
1. Upload this whole folder to your GitHub repo (keep `.github/workflows/build.yml`).
2. GitHub > Actions > "Build APK" > Run workflow (or just push).
3. Download the artifact `PrabhuGameBooster-GT-FreeFireIndia` -> `app-debug.apk`.
Uninstall the old version first if install says "app not installed" (different debug signature).

## First run
Open app -> grant: Display over other apps, Usage access (panel shows only inside the game + auto-boost), Do Not Disturb access.
Tap BOOST & PLAY. In game, pull the orange edge handle on the left. Long-press the handle = quick boost.

## v4.1
Panel > APPS: WhatsApp / YouTube buttons now open the real phone apps. Floating WhatsApp Web: choose "Link with phone number" to log in.
Floating WhatsApp: keyboard fixed (tap the chat box, or the ⌨ button on the window bar). Launching Free Fire India (BOOST + PLAY / OPEN GAME) now shows the GT intro animation first.
Floating window no longer steals the keyboard: tap outside it (e.g. on the real WhatsApp code box) and the keyboard works there.

## Power tools (Tools tab / main screen)
- BATTERY SAVER: opens the Battery saver screen. To let the app switch it on by itself, run once on a PC: `adb shell pm grant com.prabhu.gamebooster android.permission.WRITE_SECURE_SETTINGS`
- CHARGE MODE: Do Not Disturb + (Battery saver if granted) + dim black charging screen with %, temperature, watts, time to full. It cannot raise the charger's real speed.
- Floating WhatsApp Web now stays loaded when you close the window (pairing code is not reset). Keyboard goes to the window only while a text box inside it is selected.

## Music (panel > MUSIC)
Plays songs stored on the phone. First time: ALLOW MUSIC ACCESS. Equalizer bars dance with the music; allow Microphone in the main app for real beat-sync (otherwise a simulated dance is shown). Music keeps playing when the panel is closed; STOP in the panel stops it.

## v4.2
- GAME LOCK (panel > main tab, chip "GAME LOCK"): while ON and Free Fire India is in front, taps on the 3-button navigation bar (Back / Home / Recents) are blocked, and if you still leave the game (gesture navigation, etc.) it is brought straight back. Turn it OFF in the panel (orange edge handle) to exit. It releases itself if the game keeps closing (you quit on purpose). Needs Usage Access. Real WhatsApp/YouTube buttons open the floating window instead while the lock is ON.
- Floating window: drag the "◢" strip at the bottom to resize to ANY size; the size is remembered. The window always stays on screen, re-fits after rotation, and the web page re-lays-out to the new size. ⤢ still cycles quick sizes.

## v5.0  "Neon Glass" redesign
- Whole new look: dark glass cards, glowing sweep-gradient gauges, gradient usage bars, bold modern fonts, rounded 3x3 quick-action tiles (main screen) and tile grids in the in-game panel.
- 4 colour themes: NEON (cyan/violet, default), FIRE (orange), VIOLET (purple/pink), LIME (green). Change from the THEME tile / THEME section on the main screen, or Panel > TOOLS > THEME. Applies to the edge handle, panel, gauges, intro and music bars instantly.
- Main screen: hero card with BOOST & PLAY, LIVE STATS, QUICK ACTIONS, PERFORMANCE MODE, SYSTEM, SETUP (status dots), THEME.
- In-game panel: glass rail with accent tabs, live temperature chip in the header, cards for each section, switch-style toggles (AUTO BOOST / MINI HUD / GAME LOCK).

## v5.1
- MODE ENABLED animation: when you pick SMOOTH / BALANCED / PRO / AI / ESPORTS in the panel while playing, a centre-screen animation (rings + icon + "BALANCED MODE ENABLED") plays over the game. It ignores touches, so the game stays playable.
- New 5th mode **ESPORTS** (modes renamed: SMOOTH, BALANCED, PRO, AI, ESPORTS). While Free Fire India is in front: Back/Home/Recents locked (same as Game Lock, auto-ON), the orange edge handle becomes invisible, no banners / mini HUD, a thin top-edge strip catches the status-bar pull-down, DND on, screen awake, auto-clean 45 s.
- ESPORTS hides the status-bar clock only if you run once on a PC: `adb shell pm grant com.prabhu.gamebooster android.permission.WRITE_SECURE_SETTINGS` (clock is restored when you leave the game / change mode).
- Exit ESPORTS: pull the (invisible) left edge where the handle was -> panel -> pick another mode.
- Needs Usage Access, like Game Lock.

## v5.2
- Music > LOOP SONG: the current song repeats until you change/stop it.
- Music > TOP BAR IN GAME (ON/OFF): while a song plays over the game in landscape, a bar slides in at the top centre with dancing bars and the scrolling song name. Touch-through. Hidden in ESPORTS mode. Needs Usage Access (to know the game is in front).
- MAX mode is now **AI** mode (same as PRO + auto-clean every 30 s + overheat alerts). AI tips were removed.

## v5.3
- Music > SONG VOLUME slider: the song has its own volume (saved). The game sound still follows your phone volume buttons, so you can lower the song without touching the game.

## v5.4  "RedMagic Landscape" dashboard
- Main screen is now landscape (sensorLandscape) in RedMagic Game Space style: top bar with live BATTERY / TEMP / RAM / PING chips, left rail (game card, CPU ring + slanted bars, performance modes list), centre hub (rotating rings with live FPS + BOOST & PLAY), right rail (GPU ring + 3x3 quick action tiles).
- Bottom tabs: GAME LOBBY (dashboard) and SUPER BASE (setup permissions, theme, system details).
- New default theme RED (existing saved theme is kept; pick RED from THEME). All features are unchanged; only the style changed. In-game panel is unchanged.

## v6.0  GT animations only
- Phoenix removed completely. Two GT animations remain: (1) when the app opens: "WELCOME TO GT" (about 2.6 s, once per app start); (2) when Free Fire India is launched: "GT MODE ACTIVATING..." then "IMPROVING GAME..." with a progress bar (about 2.8 s), the game opens under it.
- You can delete these old files from the GitHub repo (no longer used): app/src/main/java/com/prabhu/gamebooster/FireSnake.kt, Phoenix.kt and the folder app/src/main/res/raw (intro_phoenix.mp4). Deleting them only makes the APK smaller.
