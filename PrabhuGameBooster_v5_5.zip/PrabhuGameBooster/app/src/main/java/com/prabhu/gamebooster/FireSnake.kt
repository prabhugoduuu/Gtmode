package com.prabhu.gamebooster

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.pow
import kotlin.math.sin

private fun lerpCol(a: Int, b: Int, f: Float): Int {
    val t = f.coerceIn(0f, 1f)
    return Color.argb(255,
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt())
}

/** Giant fire cobra that slithers across the screen (drawn live, no images). Driven by update(seconds 0..5). */
class FireSnakeView(c: Context) : View(c) {
    companion object { const val N = 90 }

    private class Ember(var x: Float, var y: Float, val vx: Float, val vy: Float, var life: Float, val size: Float)

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val oval = RectF()
    private val embers = ArrayList<Ember>()
    private val rnd = java.util.Random(11)
    private val xs = FloatArray(N + 1)
    private val ys = FloatArray(N + 1)
    private val rs = FloatArray(N + 1)
    private var t = 0f
    private var dt = 0f

    fun update(sec: Float) { dt = (sec - t).coerceIn(0f, 0.05f); t = sec; invalidate() }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val d = Util.dp(context, 1).toFloat()
        cv.drawColor(Color.parseColor("#050203"))

        // pulsing red glow behind everything
        val pulse = 0.6f + 0.4f * sin(t * 4f)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(w * 0.5f, h * 0.5f, maxOf(w, h) * 0.65f,
            intArrayOf(Color.argb((100 * pulse).toInt(), 255, 60, 0), Color.argb(45, 120, 0, 0), Color.TRANSPARENT),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, p); p.shader = null

        // zoom + shake near the end
        val late = ((t - 3.4f) / 1.6f).coerceIn(0f, 1f)
        cv.save()
        val z = 1f + 0.22f * late * late
        cv.scale(z, z, w * 0.62f, h * 0.5f)
        if (late > 0f) cv.translate((rnd.nextFloat() - 0.5f) * d * 9f * late, (rnd.nextFloat() - 0.5f) * d * 9f * late)

        // ---- body points (tail .. head) ----
        val x01 = (t / 3.4f).coerceIn(0f, 1f)
        val ease = 1f - (1f - x01) * (1f - x01)
        val hp = -0.05f + 0.87f * ease                // head position along the path
        val len = 0.78f
        val amp = h * 0.24f; val rad = h * 0.105f
        var n = 0
        for (i in 0..N) {
            val f = i / N.toFloat()
            val s = hp - len * f
            if (s < -0.1f) break
            xs[i] = w * (-0.08f + 1.16f * s)
            ys[i] = h * 0.5f + amp * sin(2.0 * PI * 1.5 * s - t * 3.5).toFloat()
            rs[i] = rad * (0.28f + 0.72f * (1f - f).pow(0.6f))
            n = i
        }
        if (n >= 2) {
            // pass 1: wide fire glow
            p.style = Paint.Style.FILL; p.color = Color.argb(0x24, 255, 40, 0)
            for (i in n downTo 0) cv.drawCircle(xs[i], ys[i], rs[i] * 1.9f, p)
            // pass 2: orange body
            for (i in n downTo 0) { p.color = lerpCol(Color.parseColor("#FF7A00"), Color.parseColor("#B80C00"), i / N.toFloat() * 1.3f); cv.drawCircle(xs[i], ys[i], rs[i] * 1.12f, p) }
            // pass 3: hot core
            for (i in n downTo 0) { p.color = lerpCol(Color.parseColor("#FFE56A"), Color.parseColor("#FF4A00"), i / N.toFloat() * 1.2f); cv.drawCircle(xs[i], ys[i], rs[i] * 0.7f, p) }
            // pass 4: scale rings
            p.style = Paint.Style.STROKE; p.strokeWidth = d * 1.6f; p.color = Color.argb(0xAA, 120, 20, 0)
            for (i in n downTo 1 step 3) cv.drawCircle(xs[i], ys[i], rs[i] * 0.98f, p)
            p.style = Paint.Style.FILL
            // pass 5: flames licking upward
            for (i in 2..n step 3) {
                val rr = rs[i]
                val flick = 0.5f + 0.5f * sin(t * 18f + i * 1.7f)
                val fh = rr * (1.2f + 1.4f * flick)
                val sway = sin(t * 9f + i).toFloat() * rr * 0.35f
                p.color = Color.argb(0xCC, 255, 90, 0)
                path.reset(); path.moveTo(xs[i] - rr * 0.6f, ys[i] - rr * 0.5f)
                path.quadTo(xs[i] - rr * 0.2f + sway, ys[i] - fh * 0.7f, xs[i] + sway * 1.5f, ys[i] - fh - rr * 0.4f)
                path.quadTo(xs[i] + rr * 0.25f + sway, ys[i] - fh * 0.5f, xs[i] + rr * 0.6f, ys[i] - rr * 0.5f); path.close()
                cv.drawPath(path, p)
                p.color = Color.argb(0xDD, 255, 215, 70)
                path.reset(); path.moveTo(xs[i] - rr * 0.3f, ys[i] - rr * 0.5f)
                path.quadTo(xs[i] + sway * 0.5f, ys[i] - fh * 0.5f, xs[i] + sway, ys[i] - fh * 0.7f - rr * 0.2f)
                path.quadTo(xs[i] + rr * 0.1f + sway * 0.5f, ys[i] - fh * 0.3f, xs[i] + rr * 0.3f, ys[i] - rr * 0.5f); path.close()
                cv.drawPath(path, p)
            }
            // embers
            if (t > 0.2f && embers.size < 260) repeat(5) {
                val k = rnd.nextInt(n + 1)
                embers.add(Ember(xs[k] + (rnd.nextFloat() - 0.5f) * rs[k], ys[k] - rs[k] * 0.5f,
                    (rnd.nextFloat() - 0.5f) * d * 40f, -(40f + rnd.nextFloat() * 110f) * d, 1f, (1.4f + rnd.nextFloat() * 2.6f) * d))
            }
            val it = embers.iterator()
            while (it.hasNext()) {
                val e = it.next()
                e.x += e.vx * dt; e.y += e.vy * dt; e.life -= dt * 0.9f
                if (e.life <= 0f) { it.remove(); continue }
                p.color = Color.argb((255 * e.life).toInt().coerceIn(0, 255), 255, (120 + 100 * e.life).toInt().coerceIn(0, 255), 30)
                cv.drawCircle(e.x, e.y, e.size * (0.4f + e.life * 0.6f), p)
            }
            drawHead(cv, d, xs[0], ys[0], rs[0], Math.toDegrees(atan2((ys[0] - ys[1]).toDouble(), (xs[0] - xs[1]).toDouble())).toFloat())
        }
        cv.restore()

        // white-orange flash at the end -> hands over to GT MODE
        val fl = ((t - 4.55f) / 0.45f).coerceIn(0f, 1f)
        if (fl > 0f) { p.color = Color.argb((255 * fl).toInt(), 255, 200, 110); cv.drawRect(0f, 0f, w, h, p) }
    }

    private fun drawHead(cv: Canvas, d: Float, hx: Float, hy: Float, r: Float, ang: Float) {
        cv.save(); cv.translate(hx, hy); cv.rotate(ang)
        // cobra hood
        p.style = Paint.Style.FILL; p.shader = null; p.color = Color.parseColor("#B01400")
        oval.set(-r * 1.0f, -r * 2.0f, r * 0.55f, r * 2.0f); cv.drawOval(oval, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = d * 3f; p.color = Color.parseColor("#FF8A00"); cv.drawOval(oval, p)
        p.strokeWidth = d * 1.5f; p.color = Color.argb(0xAA, 255, 220, 80)
        oval.set(-r * 0.7f, -r * 1.5f, r * 0.35f, r * 1.5f); cv.drawOval(oval, p)
        // head
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, -r, 0f, r, Color.parseColor("#FFE56A"), Color.parseColor("#FF5A00"), Shader.TileMode.CLAMP)
        oval.set(-r * 0.3f, -r * 0.95f, r * 1.9f, r * 0.95f); cv.drawOval(oval, p); p.shader = null
        // eyes
        for (sg in intArrayOf(-1, 1)) {
            val ex = r * 0.75f; val ey = sg * r * 0.48f
            p.color = Color.argb(0x70, 255, 240, 120); cv.drawCircle(ex, ey, r * 0.38f, p)
            p.color = Color.parseColor("#FFF6B0"); cv.drawCircle(ex, ey, r * 0.2f, p)
            p.color = Color.BLACK; oval.set(ex - r * 0.04f, ey - r * 0.17f, ex + r * 0.04f, ey + r * 0.17f); cv.drawOval(oval, p)
        }
        // nostrils
        p.color = Color.parseColor("#5A0A00")
        cv.drawCircle(r * 1.65f, -r * 0.2f, r * 0.07f, p); cv.drawCircle(r * 1.65f, r * 0.2f, r * 0.07f, p)
        // flickering forked tongue
        val tl = r * (0.8f + 0.5f * abs(sin(t * 14f)))
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = d * 2.6f; p.color = Color.parseColor("#FF2A1A")
        val tx = r * 1.88f
        cv.drawLine(tx, 0f, tx + tl, 0f, p)
        cv.drawLine(tx + tl, 0f, tx + tl + r * 0.4f, -r * 0.3f, p)
        cv.drawLine(tx + tl, 0f, tx + tl + r * 0.4f, r * 0.3f, p)
        p.style = Paint.Style.FILL; p.strokeCap = Paint.Cap.BUTT
        cv.restore()
    }
}

/** "GT MODE ACTIVATED" burst, 2 seconds. Driven by update(seconds 0..2). */
class GtModeView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var u = 0f
    fun update(sec: Float) { u = sec; invalidate() }

    private fun backOut(x: Float): Float { val t = x.coerceIn(0f, 1f) - 1f; val k = 1.9f; return 1f + t * t * ((k + 1f) * t + k) }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f) return
        val d = Util.dp(context, 1).toFloat()
        val cx = w / 2f; val cy = h * 0.46f
        cv.drawColor(Color.parseColor("#07080B"))
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, maxOf(w, h) * 0.6f, intArrayOf(Util.alpha(Util.ACC, 0x55), Util.alpha(Util.ACC2, 0x18), Color.TRANSPARENT),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, p); p.shader = null

        // sweeping slanted slashes
        val sw = ((u - 0.05f) / 0.55f).coerceIn(0f, 1f)
        if (sw > 0f && sw < 1f) {
            p.color = Util.alpha(Util.ACC, (0x66 * (1f - sw)).toInt())
            val x = -w * 0.2f + w * 1.4f * sw
            val path = Path(); path.moveTo(x, 0f); path.lineTo(x + w * 0.09f, 0f); path.lineTo(x - w * 0.06f, h); path.lineTo(x - w * 0.15f, h); path.close()
            cv.drawPath(path, p)
        }
        // shockwave rings
        p.style = Paint.Style.STROKE
        for (i in 0..2) {
            val tt = (u / 1.3f - i * 0.16f)
            if (tt <= 0f || tt >= 1f) continue
            p.strokeWidth = d * (6f - 4f * tt); p.color = Util.alpha(Util.ACC, (200 * (1f - tt)).toInt())
            cv.drawCircle(cx, cy, maxOf(w, h) * 0.55f * tt, p)
        }
        p.style = Paint.Style.FILL
        // GT letters
        val sc = backOut(u / 0.5f)
        p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC); p.letterSpacing = 0.1f
        p.textSize = h * 0.42f * sc.coerceAtLeast(0.01f)
        val base = cy + p.textSize * 0.32f
        p.style = Paint.Style.STROKE; p.strokeWidth = d * 10f; p.color = Util.alpha(Util.ACC, 0x40); cv.drawText("GT", cx, base, p)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(cx - w * 0.15f, 0f, cx + w * 0.15f, 0f, Util.ACC, Util.ACC2, Shader.TileMode.CLAMP)
        cv.drawText("GT", cx, base, p); p.shader = null
        // MODE ACTIVATED
        val a2 = ((u - 0.45f) / 0.25f).coerceIn(0f, 1f)
        if (a2 > 0f) {
            p.typeface = Util.HEAD; p.textSize = h * 0.075f; p.letterSpacing = 0.35f; p.color = Color.argb((255 * a2).toInt(), 255, 255, 255)
            cv.drawText("MODE  ACTIVATED", cx, cy + h * 0.30f, p)
            p.typeface = Util.BOLD; p.textSize = h * 0.035f; p.letterSpacing = 0.25f; p.color = Util.alpha(Util.MUTED, (255 * a2).toInt())
            cv.drawText("PRABHU GAME BOOSTER  •  ${Util.GAME_NAME.uppercase()}", cx, cy + h * 0.38f, p)
        }
        // progress bar
        val bw = w * 0.36f; val by = h * 0.90f
        p.letterSpacing = 0f; p.color = Color.parseColor("#262932"); cv.drawRoundRect(cx - bw / 2, by, cx + bw / 2, by + d * 5f, d * 3f, d * 3f, p)
        p.shader = LinearGradient(cx - bw / 2, 0f, cx + bw / 2, 0f, Util.ACC, Util.ACC2, Shader.TileMode.CLAMP)
        cv.drawRoundRect(cx - bw / 2, by, cx - bw / 2 + bw * (u / 2f).coerceIn(0f, 1f), by + d * 5f, d * 3f, d * 3f, p); p.shader = null
        // opening white-hot flash fading out (continues the snake flash)
        val fl = (1f - u / 0.35f).coerceIn(0f, 1f)
        if (fl > 0f) { p.color = Color.argb((255 * fl).toInt(), 255, 200, 110); cv.drawRect(0f, 0f, w, h, p) }
    }
}
