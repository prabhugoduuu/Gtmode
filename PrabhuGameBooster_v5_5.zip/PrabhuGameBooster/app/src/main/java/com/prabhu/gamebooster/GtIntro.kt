package com.prabhu.gamebooster

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout

/**
 * Full-screen launch animation shown just before Free Fire India opens:
 *   0 - 5 s  giant fire snake slithers across the screen
 *   5 - 7 s  "GT MODE ACTIVATED" burst
 * The game is launched at ~6.3 s (under the overlay), then the overlay fades out.
 */
object GtIntro {
    @Volatile private var playing = false
    private const val SNAKE_MS = 5000L
    private const val GT_MS = 2000L
    private const val LAUNCH_AT = 6300L

    fun play(ctx: Context, launch: () -> Boolean, onFail: () -> Unit) {
        val c = ctx.applicationContext
        if (playing) return
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(c)) { if (!launch()) onFail(); return }
        playing = true
        val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val h = Handler(Looper.getMainLooper())

        val root = FrameLayout(c).apply { setBackgroundColor(Color.parseColor("#FF050203")); alpha = 0f; setOnTouchListener { _, _ -> true } }
        val snake = FireSnakeView(c)
        val gt = GtModeView(c).apply { visibility = View.GONE }
        root.addView(snake, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(gt, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT)
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        try { wm.addView(root, lp) } catch (e: Exception) { playing = false; if (!launch()) onFail(); return }

        var anim: ValueAnimator? = null
        fun remove() { anim?.cancel(); try { wm.removeView(root) } catch (e: Exception) {}; playing = false }

        root.animate().alpha(1f).setDuration(150).start()
        anim = ValueAnimator.ofFloat(0f, (SNAKE_MS + GT_MS) / 1000f).apply {
            duration = SNAKE_MS + GT_MS; interpolator = LinearInterpolator()
            addUpdateListener {
                val sec = it.animatedValue as Float
                if (sec < SNAKE_MS / 1000f) snake.update(sec)
                else {
                    if (snake.visibility != View.GONE) snake.visibility = View.GONE
                    if (gt.visibility != View.VISIBLE) gt.visibility = View.VISIBLE
                    gt.update(sec - SNAKE_MS / 1000f)
                }
            }
            start()
        }
        h.postDelayed({
            if (!launch()) { onFail(); remove(); return@postDelayed }
            h.postDelayed({ root.animate().alpha(0f).setDuration(450).withEndAction { remove() }.start() }, (SNAKE_MS + GT_MS) - LAUNCH_AT + 150)
        }, LAUNCH_AT)
        h.postDelayed({ remove() }, 9500)   // safety: never leave the screen covered
    }
}
