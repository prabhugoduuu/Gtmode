package com.prabhu.gamebooster

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.NotificationManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.*
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Choreographer
import android.view.Gravity
import android.widget.TextView
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.roundToInt

object Util {
    // ---- Free Fire INDIA only ----
    const val GAME_PKG = "com.garena.game.ffi"
    const val GAME_NAME = "Free Fire India"
    val GAMES = listOf(GAME_PKG)

    // ---- GT-mode palette ----
    val ORANGE = Color.parseColor("#FF6A00")
    val AMBER = Color.parseColor("#FF9A3D")
    val GREEN = Color.parseColor("#2ED573")
    val RED = Color.parseColor("#FF3B47")
    val BLUE = Color.parseColor("#2F9BFF")
    val BG = Color.parseColor("#0A0B0F")
    val CARD = Color.parseColor("#16181F")
    val CARD2 = Color.parseColor("#232630")
    val MUTED = Color.parseColor("#8B93A3")

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()
    fun loadColor(v: Int) = if (v >= 85) RED else if (v >= 60) ORANGE else GREEN

    fun round(c: Context, color: Int, r: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(c, r).toFloat()
            if (stroke != 0) setStroke(dp(c, 1), stroke)
        }

    fun grad(c: Context, a: Int, b: Int, r: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(a, b)).apply { cornerRadius = dp(c, r).toFloat() }

    fun pill(c: Context, t: String, color: Int, onClick: () -> Unit): TextView = TextView(c).apply {
        text = t; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(c, 10), dp(c, 12), dp(c, 10), dp(c, 12))
        background = round(c, color, 14)
        setOnClickListener { onClick() }
    }

    fun primary(c: Context, t: String, onClick: () -> Unit): TextView = TextView(c).apply {
        text = t; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.08f
        setPadding(dp(c, 10), dp(c, 14), dp(c, 10), dp(c, 14))
        background = grad(c, ORANGE, AMBER, 16)
        setOnClickListener { onClick() }
    }

    fun pref(c: Context): SharedPreferences = c.getSharedPreferences("pgb", Context.MODE_PRIVATE)

    // ---- system stats ----
    fun temp(c: Context): Float {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra("temperature", 0) ?: 0) / 10f
    }

    fun battery(c: Context): Int {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra("level", 0) ?: 0
        val s = i?.getIntExtra("scale", 100) ?: 100
        return if (s > 0) l * 100 / s else 0
    }

    fun ramPercent(c: Context): Int {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        return (100 - mi.availMem * 100 / mi.totalMem).toInt()
    }

    fun totalRam(c: Context): String {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        return "%.1f GB".format(mi.totalMem / 1073741824.0)
    }

    fun displayHz(c: Context): Int {
        val dm = c.getSystemService(Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager
        val d = dm.getDisplay(0)
        return if (d != null) d.refreshRate.roundToInt().coerceAtLeast(60) else 60
    }

    fun ping(cb: (Long) -> Unit) {
        Thread {
            val t = System.currentTimeMillis()
            val r = try {
                Socket().use { it.connect(InetSocketAddress("8.8.8.8", 53), 1500) }
                System.currentTimeMillis() - t
            } catch (e: Exception) { -1L }
            cb(r)
        }.start()
    }

    // ---- RAM clean / boost ----
    fun clean(c: Context) {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val ime = Settings.Secure.getString(c.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)?.substringBefore("/")
        c.packageManager.getInstalledApplications(0)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName != c.packageName &&
                it.packageName != ime && it.packageName !in GAMES }
            .forEach { am.killBackgroundProcesses(it.packageName) }
    }

    // cb runs on main thread: (freedMB, freeRamMB)
    fun boost(c: Context, cb: (Long, Long) -> Unit) {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        val before = mi.availMem
        clean(c)
        Handler(Looper.getMainLooper()).postDelayed({
            val m2 = ActivityManager.MemoryInfo(); am.getMemoryInfo(m2)
            cb(maxOf(0L, (m2.availMem - before) / 1048576), m2.availMem / 1048576)
        }, 900)
    }

    fun dnd(c: Context, on: Boolean): Boolean {
        if (Build.VERSION.SDK_INT < 23) return false
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) return false
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
        return true
    }

    // ---- game ----
    fun gameInstalled(c: Context) = c.packageManager.getLaunchIntentForPackage(GAME_PKG) != null

    fun launchGame(c: Context): Boolean {
        val li = GAMES.firstNotNullOfOrNull { c.packageManager.getLaunchIntentForPackage(it) } ?: return false
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(li); return true
    }

    fun openStore(c: Context) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$GAME_PKG")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { c.startActivity(i) } catch (e: Exception) {
            c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$GAME_PKG"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    // ---- foreground-app detection (needs Usage Access) ----
    @Suppress("DEPRECATION")
    fun hasUsage(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        else ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private var lastFg: String? = null
    private var lastQ = 0L

    @Suppress("DEPRECATION")
    fun foreground(c: Context): String? {
        if (!hasUsage(c)) return null
        return try {
            val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val from = if (lastQ == 0L) now - 3600000L else lastQ - 2000L
            val ev = usm.queryEvents(from, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) lastFg = e.packageName
            }
            lastQ = now
            lastFg
        } catch (e: Exception) { lastFg }
    }

    fun hasMic(c: Context) =
        c.packageManager.checkPermission("android.permission.RECORD_AUDIO", c.packageName) == PackageManager.PERMISSION_GRANTED
}

object Modes {
    val names = listOf("SMOOTH", "BALANCED", "PRO GAMER", "EXTREME")
    val desc = listOf(
        "SMOOTH: light RAM clean. Notifications stay on.",
        "BALANCED: RAM clean + Do Not Disturb.",
        "PRO GAMER: clean + DND + screen stays awake + auto-clean every 60 s.",
        "EXTREME: everything in PRO + auto-clean every 30 s + overheat alerts.")
    fun get(c: Context) = Util.pref(c).getInt("mode", 1)
    fun set(c: Context, i: Int) = Util.pref(c).edit().putInt("mode", i).apply()
    fun dnd(i: Int) = i >= 1
    fun awake(i: Int) = i >= 2
    fun autoSec(i: Int) = when (i) { 2 -> 60; 3 -> 30; else -> 0 }
}

/** Counts frames via Choreographer. Shows the real screen refresh/frame rate seen by the system. */
class FpsMeter {
    @Volatile var fps = 0
    private var frames = 0
    private var last = 0L
    private var running = false
    private val cb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            if (!running) return
            frames++
            if (last == 0L) last = t
            val dt = t - last
            if (dt >= 1000000000L) { fps = (frames * 1e9 / dt).roundToInt(); frames = 0; last = t }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
    fun start() { if (running) return; running = true; frames = 0; last = 0L; Choreographer.getInstance().postFrameCallback(cb) }
    fun stop() { running = false; fps = 0 }
}

object VoiceEngine {
    @Volatile var on = false
    @Volatile var pitch = 1.0f

    fun toggle(): Boolean {
        if (on) { on = false; return false }
        on = true
        Thread {
            try {
                val sr = 44100
                val ci = AudioFormat.CHANNEL_IN_MONO; val co = AudioFormat.CHANNEL_OUT_MONO
                val enc = AudioFormat.ENCODING_PCM_16BIT
                val rec = AudioRecord(MediaRecorder.AudioSource.MIC, sr, ci, enc, AudioRecord.getMinBufferSize(sr, ci, enc) * 2)
                val trk = AudioTrack(AudioManager.STREAM_MUSIC, sr, co, enc, AudioTrack.getMinBufferSize(sr, co, enc) * 2, AudioTrack.MODE_STREAM)
                try {
                    rec.startRecording(); trk.play()
                    val inp = ShortArray(1024)
                    while (on) {
                        val n = rec.read(inp, 0, inp.size); if (n <= 0) continue
                        val f = pitch; val m = (n / f).toInt(); val out = ShortArray(m)
                        for (i in 0 until m) {
                            val p = i * f
                            val a = p.toInt().coerceAtMost(n - 1); val b = (a + 1).coerceAtMost(n - 1); val fr = p - a
                            out[i] = (inp[a] * (1 - fr) + inp[b] * fr).toInt().toShort()
                        }
                        trk.write(out, 0, m)
                    }
                } finally {
                    try { rec.stop() } catch (e: Exception) {}
                    rec.release()
                    try { trk.stop() } catch (e: Exception) {}
                    trk.release()
                }
            } catch (e: Exception) { on = false }
        }.start()
        return true
    }
}
