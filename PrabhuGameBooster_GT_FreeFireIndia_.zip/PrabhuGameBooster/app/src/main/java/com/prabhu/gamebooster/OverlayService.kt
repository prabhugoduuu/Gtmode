package com.prabhu.gamebooster

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.*
import android.os.*
import android.provider.Settings
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import kotlin.math.abs

class OverlayService : Service() {
    companion object {
        const val ACTION_STOP = "com.prabhu.gamebooster.STOP"
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private val meter = FpsMeter()

    private var handle: HandleView? = null
    private var handleLp: WindowManager.LayoutParams? = null
    private var hud: TextView? = null
    private var panel: LinearLayout? = null
    private var content: FrameLayout? = null
    private var bannerView: View? = null
    private val railBtns = ArrayList<LinearLayout>()
    private var curTab = 0

    private var appWin: LinearLayout? = null
    private var appLp: WindowManager.LayoutParams? = null
    private var appWeb: WebView? = null
    private var sizeIdx = 1
    private val sizes = listOf(0.70f to 0.38f, 0.90f to 0.52f, 0.97f to 0.72f)

    private var gFps: GaugeView? = null
    private var gBat: GaugeView? = null
    private var gNet: GaugeView? = null
    private var bCpu: BarView? = null
    private var bGpu: BarView? = null
    private var bRam: BarView? = null
    private var bTemp: BarView? = null
    private var vStatus: TextView? = null
    private var modeDescV: TextView? = null
    private var modeSeg: SegmentView? = null

    private var alive = true
    private var gameVisible = true
    private var wasInGame = false
    private var lastAuto = 0L
    private var lastHeat = 0L
    private var tickN = 0
    @Volatile private var ping = -1L

    private val sens = IntArray(6)
    private val sensNames = listOf("General", "Red Dot", "2x Scope", "4x Scope", "Sniper", "AWM")
    private val presets = linkedMapOf(
        "Normal" to intArrayOf(75, 70, 65, 60, 50, 45),
        "High" to intArrayOf(88, 84, 80, 75, 65, 60),
        "Pro" to intArrayOf(95, 92, 88, 84, 75, 70),
        "Max" to intArrayOf(100, 100, 98, 95, 88, 85))
    private val desktopUA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int) = Util.dp(this, v)
    private fun type() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun mlp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(3), dp(5), dp(3), dp(5)) }
    private fun wlp() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), dp(5), dp(3), dp(5)) }
    private fun isLand() = resources.displayMetrics.let { it.widthPixels > it.heightPixels }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(NotificationChannel("pgb", "Overlay", NotificationManager.IMPORTANCE_LOW))
        }
        val flag = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val stopPi = PendingIntent.getService(this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), flag)
        val openPi = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), flag)
        val nb = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "pgb") else Notification.Builder(this)
        val n = nb.setContentTitle("Prabhu Game Booster  |  GT Mode")
            .setContentText("Overlay ready for ${Util.GAME_NAME}")
            .setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(openPi)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)

        val sp = getSharedPreferences("sensi", MODE_PRIVATE)
        val d = presets["High"]!!
        for (k in 0..5) sens[k] = sp.getInt("s$k", d[k])
        addHandle(); applyAwake(); syncHud(); tick()
    }

    // ---------------- edge handle ----------------
    private fun addHandle() {
        val v = HandleView(this)
        val lp = WindowManager.LayoutParams(dp(26), dp(84), type(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = 0
        lp.y = Util.pref(this).getInt("hy", dp(150))
        v.alpha = 0.75f
        var sy = 0; var ty = 0f; var moved = false; var longDone = false
        val lpr = Runnable { if (!moved) { longDone = true; doBoost(false) } }
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sy = lp.y; ty = e.rawY; moved = false; longDone = false; h.postDelayed(lpr, 650); true }
                MotionEvent.ACTION_MOVE -> {
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dy) > 12) { moved = true; h.removeCallbacks(lpr) }
                    if (moved) {
                        lp.y = (sy + dy).coerceIn(0, resources.displayMetrics.heightPixels - dp(90))
                        try { wm.updateViewLayout(v, lp) } catch (x: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    h.removeCallbacks(lpr)
                    if (moved) Util.pref(this).edit().putInt("hy", lp.y).apply()
                    else if (!longDone) togglePanel()
                    true
                }
                else -> false
            }
        }
        wm.addView(v, lp); handle = v; handleLp = lp
    }

    private fun applyAwake() {
        val lp = handleLp ?: return; val v = handle ?: return
        val keep = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        lp.flags = if (Modes.awake(Modes.get(this))) lp.flags or keep else lp.flags and keep.inv()
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
    }

    // ---------------- mini HUD ----------------
    private fun hudWanted() = Util.pref(this).getBoolean("hud", false) && gameVisible

    private fun syncHud() {
        if (hudWanted() && hud == null) {
            val t = TextView(this).apply {
                textSize = 11f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(12), dp(5), dp(12), dp(5))
                background = Util.round(this@OverlayService, Color.parseColor("#CC0A0B0F"), 14, Color.parseColor("#44FF6A00"))
                text = "-- Hz   -- ms"
            }
            val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, type(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = dp(4)
            wm.addView(t, lp); hud = t
        } else if (!hudWanted() && hud != null) {
            try { wm.removeView(hud) } catch (e: Exception) {}
            hud = null
        }
        syncFps()
    }

    private fun syncFps() { if (panel != null || hud != null) meter.start() else meter.stop() }

    // ---------------- banner ----------------
    private fun banner(title: String, sub: String, color: Int = Util.GREEN) {
        bannerView?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        val ll = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(24), dp(14), dp(24), dp(14))
            background = Util.round(this@OverlayService, Color.parseColor("#F00A0B0F"), 20, color)
        }
        ll.addView(TextView(this).apply { text = title; setTextColor(color); textSize = 17f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; letterSpacing = 0.05f })
        ll.addView(TextView(this).apply { text = sub; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) })
        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = dp(40)
        ll.alpha = 0f; ll.scaleX = 0.8f; ll.scaleY = 0.8f
        wm.addView(ll, lp); bannerView = ll
        ll.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240).start()
        h.postDelayed({
            if (bannerView === ll) {
                ll.animate().alpha(0f).setDuration(300).withEndAction { try { wm.removeView(ll) } catch (e: Exception) {} }.start()
                bannerView = null
            }
        }, 2800)
    }

    private fun doBoost(play: Boolean) {
        banner("BOOSTING...", "Closing background apps", Util.ORANGE)
        val mode = Modes.get(this)
        Util.boost(this) { freed, avail ->
            val dnd = Modes.dnd(mode) && Util.dnd(this, true)
            val t = Util.temp(this)
            banner("GAME BOOSTED  |  ${Modes.names[mode]}",
                (if (freed > 0) "$freed MB freed" else "RAM already clean") + "  |  $avail MB free\n%.0f°C".format(t) +
                    (if (dnd) "  |  DND ON" else ""))
            if (play) {
                closePanel()
                GtIntro.play(this, { Util.launchGame(this) }) { banner("${Util.GAME_NAME} not found", "Install it from Google Play first", Util.ORANGE) }
            }
            refreshStats()
        }
    }

    // ---------------- GT dashboard panel ----------------
    private fun label(t: String, size: Float = 11f, color: Int = Util.MUTED) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); setPadding(dp(4), dp(6), dp(4), dp(2))
    }

    private fun section(t: String) = label(t, 10.5f, Util.ORANGE).apply { typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.12f }

    private fun scroll(v: View) = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(v) }

    private fun railButton(icon: String, name: String, onClick: () -> Unit): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        setPadding(dp(2), dp(8), dp(2), dp(8))
        addView(TextView(context).apply { text = icon; textSize = 19f; gravity = Gravity.CENTER; tag = "i" })
        addView(TextView(context).apply { text = name; textSize = 9f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD; tag = "n" })
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(3), 0, dp(3)) }
        setOnClickListener { onClick() }
    }

    private fun togglePanel() { if (panel != null) closePanel() else openPanel() }

    private fun openPanel() {
        if (panel != null) return
        val c = this; val dm = resources.displayMetrics; val land = isLand()
        val pw = if (land) minOf((dm.widthPixels * 0.76f).toInt(), dp(640)) else (dm.widthPixels * 0.95f).toInt()
        val ph = if (land) (dm.heightPixels * 0.88f).toInt() else (dm.heightPixels * 0.74f).toInt()

        val root = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Util.round(c, Color.parseColor("#F2101218"), 24, Color.parseColor("#55FF6A00"))
        }
        val rail = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(6), dp(10), dp(6), dp(10))
            background = Util.round(c, Color.parseColor("#CC07080B"), 24)
        }
        rail.addView(TextView(c).apply { text = "⚡"; textSize = 24f; setTextColor(Util.ORANGE); gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(6)) })
        railBtns.clear()
        listOf("🚀" to "PERFORM", "🧰" to "TOOLS", "🎯" to "SENSI", "📺" to "APPS").forEachIndexed { i, (ic, nm) ->
            val b = railButton(ic, nm) { showTab(i) }
            railBtns.add(b); rail.addView(b)
        }
        rail.addView(View(c), LinearLayout.LayoutParams(1, 0, 1f))
        rail.addView(railButton("✕", "CLOSE") { closePanel() }.also { styleRail(it, false) })
        rail.addView(railButton("⏻", "STOP") { stopSelf() }.also { styleRail(it, false) })

        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(8)) }
        val head = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titles = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(TextView(c).apply { text = "HYPERBOOST"; setTextColor(Util.ORANGE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.14f })
        titles.addView(TextView(c).apply { text = "GT MODE  •  PRABHU GAME BOOSTER"; setTextColor(Util.MUTED); textSize = 9f; letterSpacing = 0.08f })
        head.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val ready = Util.gameInstalled(c)
        head.addView(TextView(c).apply {
            text = "●  " + Util.GAME_NAME.uppercase(); textSize = 9.5f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (ready) Util.GREEN else Util.AMBER); setPadding(dp(10), dp(5), dp(10), dp(5))
            background = Util.round(c, Util.CARD, 12)
        })
        val ct = FrameLayout(c); content = ct
        col.addView(head)
        col.addView(ct, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(6) })

        root.addView(rail, LinearLayout.LayoutParams(dp(66), ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        val lp = WindowManager.LayoutParams(pw, ph, type(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.START or Gravity.CENTER_VERTICAL; lp.x = dp(8)
        root.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) { closePanel(); true } else false }
        root.translationX = -pw.toFloat()
        wm.addView(root, lp); panel = root
        root.animate().translationX(0f).setDuration(230).setInterpolator(DecelerateInterpolator()).start()
        syncFps()
        showTab(curTab)
    }

    private fun closePanel(anim: Boolean = true) {
        val p = panel ?: return
        panel = null; content = null
        gFps = null; gBat = null; gNet = null; bCpu = null; bGpu = null; bRam = null; bTemp = null
        vStatus = null; modeDescV = null; modeSeg = null
        if (anim) p.animate().translationX(-p.width.toFloat()).setDuration(180)
            .withEndAction { try { wm.removeView(p) } catch (e: Exception) {} }.start()
        else try { wm.removeView(p) } catch (e: Exception) {}
        syncFps()
    }

    private fun styleRail(b: LinearLayout, sel: Boolean) {
        val col = if (sel) Util.ORANGE else Util.MUTED
        (b.findViewWithTag<TextView>("i"))?.setTextColor(col)
        (b.findViewWithTag<TextView>("n"))?.setTextColor(col)
        b.background = if (sel) Util.round(this, Util.CARD2, 16) else null
    }

    private fun showTab(i: Int) {
        curTab = i
        railBtns.forEachIndexed { k, b -> styleRail(b, k == i) }
        val ct = content ?: return
        ct.removeAllViews()
        gFps = null; gBat = null; gNet = null; bCpu = null; bGpu = null; bRam = null; bTemp = null
        vStatus = null; modeDescV = null; modeSeg = null
        when (i) { 0 -> ct.addView(perfTab()); 1 -> ct.addView(toolsTab()); 2 -> ct.addView(sensiTab()); else -> ct.addView(appsTab()) }
        refreshStats()
    }

    private fun setMode(i: Int) {
        Modes.set(this, i); applyAwake(); lastAuto = 0L
        modeDescV?.text = Modes.desc[i]
        banner("MODE: ${Modes.names[i]}", Modes.desc[i].substringAfter(": "), Util.ORANGE)
    }

    private fun toggleChip(text: String, key: String, def: Boolean, after: () -> Unit = {}): TextView {
        val sp = Util.pref(this)
        val t = Util.pill(this, "", Util.CARD2) {}
        fun paint() {
            val on = sp.getBoolean(key, def)
            t.text = "$text: " + (if (on) "ON" else "OFF")
            t.setTextColor(if (on) Util.GREEN else Util.MUTED)
            t.textSize = 10.5f
        }
        paint()
        t.setOnClickListener { sp.edit().putBoolean(key, !sp.getBoolean(key, def)).apply(); paint(); after() }
        t.layoutParams = wlp()
        return t
    }

    private fun perfTab(): View {
        val c = this; val land = isLand()
        val wrap = LinearLayout(c).apply { orientation = if (land) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL }
        val left = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        val right = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }

        fun ring(l: String, u: String): GaugeView = GaugeView(c).apply {
            label = l; unit = u
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), dp(2), dp(3), 0) }
        }
        val rf = ring("FRAME RATE", "Hz"); val rb = ring("BATTERY", "%"); val rn = ring("NETWORK", "ms")
        gFps = rf; gBat = rb; gNet = rn
        left.addView(LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; addView(rf); addView(rb); addView(rn) })
        left.addView(section("PERFORMANCE MODE"))
        val seg = SegmentView(c, Modes.names) { setMode(it) }
        seg.select(Modes.get(c)); modeSeg = seg
        left.addView(seg, mlp())
        val md = label(Modes.desc[Modes.get(c)]); modeDescV = md; left.addView(md)

        right.addView(section("SYSTEM"))
        val cpu = BarView(c, "CPU"); val gpu = BarView(c, "GPU"); val ram = BarView(c, "RAM"); val tmp = BarView(c, "TEMP")
        bCpu = cpu; bGpu = gpu; bRam = ram; bTemp = tmp
        right.addView(cpu); right.addView(gpu); right.addView(ram); right.addView(tmp)
        val st = TextView(c).apply { textSize = 10.5f; setTextColor(Color.WHITE); setPadding(dp(2), dp(4), dp(2), dp(4)) }
        vStatus = st; right.addView(st)
        right.addView(LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(toggleChip("AUTO BOOST", "auto", true))
            addView(toggleChip("MINI HUD", "hud", false) { syncHud() })
        })
        right.addView(Util.primary(c, "BOOST NOW") { doBoost(false) }.apply { layoutParams = mlp() })
        right.addView(Util.pill(c, "BOOST + PLAY ${Util.GAME_NAME.uppercase()}", Util.CARD2) { doBoost(true) }.apply { layoutParams = mlp() })

        if (land) {
            wrap.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.1f))
            wrap.addView(right, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(12) })
        } else {
            wrap.addView(left, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            wrap.addView(right, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        return scroll(wrap)
    }

    // ---------------- tools ----------------
    private fun toolsTab(): View {
        val c = this
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(section("VOICE CHANGER  (use earphones)"))
        val vp = Util.pill(c, if (VoiceEngine.on) "VOICE: ON" else "VOICE: OFF", Util.CARD2) {}
        vp.layoutParams = mlp()
        vp.setOnClickListener {
            if (!Util.hasMic(this)) banner("Microphone permission needed", "Open the main app and tap Microphone", Util.ORANGE)
            else { val on = VoiceEngine.toggle(); vp.text = if (on) "VOICE: ON" else "VOICE: OFF" }
        }
        col.addView(vp)
        val pr = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("Deep", "Normal", "High", "Chipmunk"); val ps = listOf(0.75f, 1.0f, 1.3f, 1.6f)
        for (k in 0..3) pr.addView(Util.pill(c, names[k], Util.CARD2) { VoiceEngine.pitch = ps[k] }.apply { textSize = 10f; layoutParams = wlp() })
        col.addView(pr)
        col.addView(section("QUICK TOOLS"))
        val r0 = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        r0.addView(Util.pill(c, "CLEAN RAM", Util.CARD2) { doBoost(false) }.apply { layoutParams = wlp() })
        r0.addView(Util.pill(c, "PING TEST", Util.CARD2) {
            Util.ping { r -> h.post { banner("PING", if (r < 0) "No internet" else "$r ms  " + (if (r < 60) "Excellent" else if (r < 120) "Good" else "High")) } } }.apply { layoutParams = wlp() })
        col.addView(r0)
        val r1 = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        r1.addView(Util.pill(c, "DND ON", Util.CARD2) { if (!Util.dnd(this, true)) askDnd() else banner("DND ON", "Notifications silenced") }.apply { layoutParams = wlp() })
        r1.addView(Util.pill(c, "DND OFF", Util.CARD2) { if (!Util.dnd(this, false)) askDnd() else banner("DND OFF", "Notifications restored") }.apply { layoutParams = wlp() })
        col.addView(r1)
        col.addView(section("POWER"))
        val r2 = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        r2.addView(Util.pill(c, "BATTERY SAVER", Util.CARD2) {
            if (PowerTools.batterySaver(this)) banner("BATTERY SAVER ON", "Low power mode enabled", Util.GREEN)
            else { closePanel(); banner("BATTERY SAVER", "Switch it ON on the settings screen", Util.ORANGE) } }.apply { layoutParams = wlp() })
        r2.addView(Util.pill(c, "CHARGE MODE", Util.CARD2) { closePanel(); PowerTools.startCharge(this) }.apply { layoutParams = wlp() })
        col.addView(r2)
        col.addView(Util.pill(c, "FIX PING  (PRIVATE DNS)", Util.CARD2) {
            closePanel()
            startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            banner("PRIVATE DNS", "Set it to dns.google", Util.ORANGE) }.apply { layoutParams = mlp() })
        return scroll(col)
    }

    private fun askDnd() {
        banner("DND access needed", "Enable it for Prabhu Game Booster", Util.ORANGE)
        startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------------- sensitivity ----------------
    private fun sensiTab(): View {
        val c = this
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(section("${Util.GAME_NAME.uppercase()} SENSITIVITY (0-100)"))
        col.addView(label("Tap a preset, then enter the same numbers in the game."))
        val bars = ArrayList<SeekBar>(); val vals = ArrayList<TextView>()
        val pr = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        for ((name, arr) in presets) pr.addView(Util.pill(c, name, Util.CARD2) { for (k in 0..5) bars[k].progress = arr[k] }.apply { layoutParams = wlp() })
        col.addView(pr)
        val sp = getSharedPreferences("sensi", MODE_PRIVATE)
        for (k in 0..5) {
            val line = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), dp(4), dp(4), 0) }
            line.addView(TextView(c).apply { text = sensNames[k]; setTextColor(Color.WHITE); textSize = 12.5f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
            val vt = TextView(c).apply { text = "${sens[k]}"; setTextColor(Util.ORANGE); textSize = 14f; typeface = Typeface.DEFAULT_BOLD }
            vals.add(vt); line.addView(vt)
            val sb = SeekBar(c).apply {
                max = 100; progress = sens[k]
                progressTintList = ColorStateList.valueOf(Util.ORANGE); thumbTintList = ColorStateList.valueOf(Util.AMBER)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { sens[k] = v; vals[k].text = "$v"; sp.edit().putInt("s$k", v).apply() }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            bars.add(sb); col.addView(line); col.addView(sb)
        }
        col.addView(label("Android does not allow apps to change in-game sensitivity. Use these as a starting point in Settings > Sensitivity.", 10f))
        col.addView(Util.primary(c, "OPEN ${Util.GAME_NAME.uppercase()}") {
            closePanel(); GtIntro.play(this, { Util.launchGame(this) }) { banner("${Util.GAME_NAME} not found", "Install it from Google Play first", Util.ORANGE) } }.apply { layoutParams = mlp() })
        return scroll(col)
    }

    // ---------------- floating apps ----------------
    private fun tile(name: String, color: Int, url: String, desktop: Boolean) = TextView(this).apply {
        text = name; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = Util.round(this@OverlayService, color, 16); setPadding(0, dp(24), 0, dp(24))
        layoutParams = wlp(); setOnClickListener { openApp(url, desktop) }
    }

    private fun realTile(name: String, color: Int, pkg: String, fallbackUrl: String, desktop: Boolean) = TextView(this).apply {
        text = name; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = Util.round(this@OverlayService, color, 16); setPadding(0, dp(24), 0, dp(24))
        layoutParams = wlp(); setOnClickListener { launchReal(pkg, name, fallbackUrl, desktop) }
    }

    private fun launchReal(pkg: String, name: String, fallbackUrl: String, desktop: Boolean) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) {
            banner("$name app not installed", "Opening the floating web version", Util.ORANGE)
            openApp(fallbackUrl, desktop); return
        }
        closePanel()
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { banner("Could not open $name", "Open it from your home screen", Util.RED) }
    }

    private fun appsTab(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(section("YOUR PHONE APPS"))
        col.addView(label("Opens the real app installed on your phone (your chats and login are already there). The game goes to the background, so come back from Recent apps."))
        col.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL
            addView(realTile("WhatsApp", Color.parseColor("#2E7D32"), "com.whatsapp", "https://web.whatsapp.com", true))
            addView(realTile("YouTube", Color.parseColor("#C62828"), "com.google.android.youtube", "https://m.youtube.com", false)) })
        col.addView(section("FLOATING WINDOW  (over the game)"))
        col.addView(label("Small window above the game. Drag the top bar to move, ⌨ = keyboard, ⤢ = resize, red X = close."))
        col.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL
            addView(tile("YouTube", Color.parseColor("#C62828"), "https://m.youtube.com", false))
            addView(tile("Google", Util.BLUE, "https://www.google.com", false)) })
        col.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL
            addView(tile("WhatsApp Web", Color.parseColor("#2E7D32"), "https://web.whatsapp.com", true))
            addView(tile("Instagram", Color.parseColor("#AD1457"), "https://www.instagram.com", false)) })
        col.addView(label("WhatsApp Web: on the login screen choose \"Link with phone number\" (you cannot scan a QR on the same phone). Login is remembered. Google sign-in may be blocked in embedded windows.", 10f))
        return scroll(col)
    }

    private fun openApp(url: String, desktop: Boolean) {
        closeApp(); closePanel()
        val c = this
        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(1), dp(1), dp(1), dp(1))
            background = Util.round(c, Color.parseColor("#101018"), 14, Color.parseColor("#66FF6A00")) }
        val bar = FrameLayout(c).apply { setBackgroundColor(Util.CARD) }
        bar.addView(View(c).apply { background = Util.round(c, Color.parseColor("#77FFFFFF"), 3); layoutParams = FrameLayout.LayoutParams(dp(64), dp(6), Gravity.CENTER) })
        bar.addView(TextView(c).apply {
            text = "⌨"; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END).apply { rightMargin = dp(80) }
            setOnClickListener {
                // move the window to the top and open the keyboard
                val wv = appWeb ?: return@setOnClickListener; val l = appLp ?: return@setOnClickListener; val win = appWin ?: return@setOnClickListener
                l.y = dp(4); try { wm.updateViewLayout(win, l) } catch (e: Exception) {}
                setAppFocusable(true); wv.requestFocus()
                wv.postDelayed({ (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(wv, InputMethodManager.SHOW_IMPLICIT) }, 200)
            } })
        bar.addView(TextView(c).apply {
            text = "⤢"; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END).apply { rightMargin = dp(40) }
            setOnClickListener { sizeIdx = (sizeIdx + 1) % sizes.size; applySize() } })
        bar.addView(TextView(c).apply {
            text = "✕"; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER; setBackgroundColor(Color.parseColor("#D32F2F"))
            layoutParams = FrameLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END)
            setOnClickListener { closeApp() } })
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))
        val keep = url.contains("whatsapp")
        appKeep = keep
        // WhatsApp Web stays loaded when you close the window, so your pairing code / chats are not reset
        val w = if (keep) webCache.getOrPut(url) { makeWeb(url, desktop) } else makeWeb(url, desktop)
        (w.parent as? ViewGroup)?.removeView(w)
        root.addView(w, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams((dm.widthPixels * sizes[sizeIdx].first).toInt(), (dm.heightPixels * sizes[sizeIdx].second).toInt(), type(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = dp(12); lp.y = dp(90)
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        bar.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; true }
                MotionEvent.ACTION_MOVE -> { lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt(); wm.updateViewLayout(root, lp); true }
                else -> false
            }
        }
        root.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) { webTyping = false; setAppFocusable(false) }; false }
        wm.addView(root, lp); appWin = root; appLp = lp; appWeb = w
    }

    private val webCache = HashMap<String, WebView>()
    private var appKeep = false
    private var webTyping = false
    private val focusJs = "(function(){if(window.__pgb)return;window.__pgb=1;" +
        "function t(e){if(!e)return false;var n=e.tagName;" +
        "if(n==='INPUT')return !/^(button|checkbox|radio|submit|reset|image|range|file|color)$/.test(e.type);" +
        "return n==='TEXTAREA'||e.isContentEditable===true;}" +
        "document.addEventListener('focusin',function(e){if(t(e.target))PGB.focus(true)},true);" +
        "document.addEventListener('focusout',function(e){if(t(e.target))PGB.focus(false)},true);})();"

    private inner class WebBridge {
        @JavascriptInterface
        fun focus(on: Boolean) {
            h.post {
                webTyping = on
                if (on) {
                    setAppFocusable(true)
                    appWeb?.let { wv ->
                        wv.requestFocus()
                        wv.postDelayed({ (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(wv, InputMethodManager.SHOW_IMPLICIT) }, 150)
                    }
                } else h.postDelayed({ if (!webTyping) setAppFocusable(false) }, 300)
            }
        }
    }

    private fun makeWeb(url: String, desktop: Boolean): WebView = object : WebView(this) {
        // no full-screen keyboard in landscape, so you can see the chat while typing
        override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
            val ic = super.onCreateInputConnection(outAttrs)
            outAttrs.imeOptions = outAttrs.imeOptions or EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_FLAG_NO_FULLSCREEN
            return ic
        }
    }.apply {
        isFocusable = true; isFocusableInTouchMode = true
        settings.javaScriptEnabled = true; settings.domStorageEnabled = true
        settings.databaseEnabled = true; settings.javaScriptCanOpenWindowsAutomatically = true
        settings.setSupportZoom(true); settings.builtInZoomControls = true; settings.displayZoomControls = false
        settings.mediaPlaybackRequiresUserGesture = false
        if (desktop) { settings.userAgentString = desktopUA; settings.useWideViewPort = true; settings.loadWithOverviewMode = true }
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
        addJavascriptInterface(WebBridge(), "PGB")
        webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, u: String?) { view?.evaluateJavascript(focusJs, null) }
        }
        webChromeClient = WebChromeClient()
        loadUrl(url)
    }

    /** The floating window only takes keyboard focus while you use it. Tap outside it and the app underneath (real WhatsApp, game) gets the keyboard back. */
    private fun setAppFocusable(on: Boolean) {
        val lp = appLp ?: return; val v = appWin ?: return
        val nf = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        if (((lp.flags and nf) == 0) == on) return
        lp.flags = if (on) lp.flags and nf.inv() else lp.flags or nf
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
    }

    private fun applySize() {
        val lp = appLp ?: return; val v = appWin ?: return
        val dm = resources.displayMetrics
        lp.width = (dm.widthPixels * sizes[sizeIdx].first).toInt(); lp.height = (dm.heightPixels * sizes[sizeIdx].second).toInt()
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
    }

    private fun closeApp() {
        appWin?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        CookieManager.getInstance().flush()
        if (appKeep) (appWeb?.parent as? ViewGroup)?.removeView(appWeb) else appWeb?.destroy()
        appWeb = null; appWin = null; appLp = null
    }

    // ---------------- live stats ----------------
    private fun refreshStats() {
        val t = Util.temp(this); val ram = Util.ramPercent(this)
        val fps = meter.fps; val bat = Util.battery(this)
        val maxHz = Util.displayHz(this)
        val tc = if (t >= 42) Util.RED else if (t >= 38) Util.ORANGE else Util.GREEN

        gFps?.set(if (fps <= 0) -1 else (fps * 100 / maxHz).coerceAtMost(100), if (fps <= 0) "--" else "$fps", Util.ORANGE)
        gBat?.set(bat, "$bat", if (bat < 20) Util.RED else Util.GREEN)
        val nc = if (ping < 0) Util.MUTED else if (ping < 60) Util.GREEN else if (ping < 120) Util.ORANGE else Util.RED
        gNet?.set(if (ping < 0) -1 else (100 - ping / 2).toInt().coerceIn(5, 100), if (ping < 0) "--" else "$ping", nc)

        if (bCpu != null) {
            val cpu = SysInfo.cpuLoad(); val gpu = SysInfo.gpuLoad()
            bCpu?.set(cpu, if (cpu < 0) "--" else "$cpu%", Util.loadColor(cpu))
            bGpu?.set(gpu, if (gpu < 0) "--" else "$gpu%", Util.loadColor(gpu))
            bRam?.set(ram, "$ram%", Util.loadColor(ram))
            bTemp?.set(((t - 25f) / 25f * 100).toInt().coerceIn(0, 100), "%.0f°C".format(t), tc)
            vStatus?.text = "Thermal ${SysInfo.thermal(this)}" + (if (t >= 42) "   |   Phone is hot, take a short break." else "")
        }
        hud?.text = (if (fps <= 0) "--" else "$fps") + " Hz    " + (if (ping < 0) "--" else "$ping") + " ms    %.0f°C".format(t)
        handle?.let { it.heat = if (t >= 42) Util.RED else Util.ORANGE; it.invalidate() }
    }

    private fun applyVisibility() {
        handle?.visibility = if (gameVisible) View.VISIBLE else View.GONE
        if (!gameVisible) closePanel()
        syncHud()
    }

    private fun tick() {
        if (!alive) return
        tickN++
        if (tickN % 3 == 0) Util.ping { ping = it }

        // show only while Free Fire India (or this app) is in front. Needs Usage Access; otherwise always visible.
        val fg = Util.foreground(this)
        if (fg != null) {
            val vis = fg == Util.GAME_PKG || fg == packageName
            val inGame = fg == Util.GAME_PKG
            if (vis != gameVisible) { gameVisible = vis; applyVisibility() }
            if (inGame && !wasInGame && Util.pref(this).getBoolean("auto", true)) doBoost(false)
            wasInGame = inGame
        } else if (!gameVisible) { gameVisible = true; applyVisibility() }

        refreshStats()
        val mode = Modes.get(this); val now = System.currentTimeMillis(); val sec = Modes.autoSec(mode)
        if (sec > 0 && now - lastAuto > sec * 1000L) { lastAuto = now; Util.clean(this) }
        if (mode == 3 && Util.temp(this) >= 43f && now - lastHeat > 120000L) {
            lastHeat = now; banner("HIGH TEMPERATURE", "Take a short break and remove the phone case", Util.RED)
        }
        h.postDelayed({ tick() }, if (panel != null || hud != null) 1000L else 2500L)
    }

    override fun onDestroy() {
        alive = false; running = false; meter.stop(); h.removeCallbacksAndMessages(null)
        closePanel(false); closeApp(); webCache.values.forEach { it.destroy() }; webCache.clear()
        bannerView?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        hud?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        handle?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        handle = null; hud = null; super.onDestroy()
    }
}
