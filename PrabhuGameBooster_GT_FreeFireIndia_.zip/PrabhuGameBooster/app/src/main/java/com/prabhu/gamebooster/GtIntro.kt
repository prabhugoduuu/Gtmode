package com.prabhu.gamebooster

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Full-screen "GT" launch animation, shown just before Free Fire India opens. */
object GtIntro {
    @Volatile private var playing = false

    /** Plays the animation, calls [launch] near the end (returns false if the game is missing), then fades out over the game. */
    fun play(ctx: Context, launch: () -> Boolean, onFail: () -> Unit) {
        val c = ctx.applicationContext
        if (playing) return
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(c)) { if (!launch()) onFail(); return }
        playing = true
        val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val h = Handler(Looper.getMainLooper())
        fun dp(v: Int) = Util.dp(c, v)

        val root = FrameLayout(c).apply { setBackgroundColor(Color.parseColor("#FF07080B")); alpha = 0f; setOnTouchListener { _, _ -> true } }
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }

        val gt = TextView(c).apply {
            text = "GT"; textSize = 88f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
            setTextColor(Util.ORANGE); letterSpacing = 0.12f; gravity = Gravity.CENTER
            setShadowLayer(30f, 0f, 0f, Util.ORANGE)
            scaleX = 0.3f; scaleY = 0.3f; this.alpha = 0f
        }
        val name = TextView(c).apply {
            text = "PRABHU GAME BOOSTER"; textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE); letterSpacing = 0.3f; gravity = Gravity.CENTER; this.alpha = 0f
        }
        val sub = TextView(c).apply {
            text = "${Util.GAME_NAME.uppercase()}  •  GT MODE"; textSize = 10f
            setTextColor(Util.MUTED); letterSpacing = 0.15f; gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(18)); this.alpha = 0f
        }
        val track = FrameLayout(c).apply { background = Util.round(c, Color.parseColor("#262932"), 3) }
        val fill = View(c).apply { background = Util.grad(c, Util.ORANGE, Util.AMBER, 3); pivotX = 0f; scaleX = 0f }
        track.addView(fill, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val status = TextView(c).apply {
            text = "BOOSTING..."; textSize = 10.5f; setTextColor(Util.AMBER); letterSpacing = 0.2f
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0)
        }
        col.addView(gt); col.addView(name); col.addView(sub)
        col.addView(track, LinearLayout.LayoutParams(dp(200), dp(5)))
        col.addView(status)
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT)
        try { wm.addView(root, lp) } catch (e: Exception) { playing = false; if (!launch()) onFail(); return }

        fun remove() { try { wm.removeView(root) } catch (e: Exception) {}; playing = false }

        root.animate().alpha(1f).setDuration(150).start()
        gt.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(520).setStartDelay(100).setInterpolator(OvershootInterpolator(1.6f)).start()
        name.animate().alpha(1f).setDuration(300).setStartDelay(500).start()
        sub.animate().alpha(1f).setDuration(300).setStartDelay(600).start()
        // glow pulse
        ValueAnimator.ofFloat(20f, 70f).apply {
            duration = 650; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            addUpdateListener { gt.setShadowLayer(it.animatedValue as Float, 0f, 0f, Util.ORANGE) }
            start(); h.postDelayed({ cancel() }, 3000)
        }
        // progress
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1500; startDelay = 300; interpolator = DecelerateInterpolator(1.2f)
            addUpdateListener {
                val v = it.animatedValue as Float
                fill.scaleX = v
                status.text = if (v < 0.4f) "BOOSTING..." else if (v < 0.8f) "OPTIMIZING..." else "LAUNCHING..."
            }
            start()
        }
        h.postDelayed({
            if (!launch()) { onFail(); remove(); return@postDelayed }
            h.postDelayed({ root.animate().alpha(0f).setDuration(450).withEndAction { remove() }.start() }, 900)
        }, 1900)
        h.postDelayed({ remove() }, 4500)   // safety: never leave the screen covered
    }
}
