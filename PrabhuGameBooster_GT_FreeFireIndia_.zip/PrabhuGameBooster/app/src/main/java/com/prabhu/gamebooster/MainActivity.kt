package com.prabhu.gamebooster

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private val meter = FpsMeter()
    private lateinit var gFps: GaugeView
    private lateinit var gBat: GaugeView
    private lateinit var gNet: GaugeView
    private lateinit var bCpu: BarView
    private lateinit var bGpu: BarView
    private lateinit var bRam: BarView
    private lateinit var bTemp: BarView
    private lateinit var info: TextView
    private lateinit var result: TextView
    private lateinit var modeDesc: TextView
    private lateinit var seg: SegmentView
    private lateinit var gameSub: TextView
    private lateinit var gameTag: TextView
    private lateinit var ovBtn: TextView
    private lateinit var voiceBtn: TextView
    private lateinit var pitchBtn: TextView
    private lateinit var setupBox: LinearLayout
    private val pitches = floatArrayOf(0.75f, 1.0f, 1.3f, 1.6f)
    private val pitchNames = arrayOf("Deep", "Normal", "High", "Chipmunk")
    private var pi = 1
    private var gpuName = "Detecting..."
    @Volatile private var ping = -1L
    private var alive = true

    private fun dp(v: Int) = Util.dp(this, v)
    private fun wl() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }
    private fun full() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(2), dp(8), dp(2), dp(4)) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
        background = Util.round(this@MainActivity, Util.CARD, 20, Color.parseColor("#1FFFFFFF"))
        layoutParams = full()
    }

    private fun section(t: String) = TextView(this).apply {
        text = t; textSize = 10.5f; setTextColor(Util.ORANGE); typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(4), dp(16), 0, dp(2)); letterSpacing = 0.14f
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(34), dp(14), dp(28)); setBackgroundColor(Util.BG) }

        // header
        root.addView(TextView(this).apply { text = "PRABHU"; textSize = 12f; setTextColor(Util.ORANGE); typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.4f })
        root.addView(TextView(this).apply { text = "GAME BOOSTER"; textSize = 26f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); letterSpacing = 0.06f })
        root.addView(TextView(this).apply { text = "GT MODE  •  ${Util.GAME_NAME.uppercase()} EDITION  •  v4.0"; textSize = 10f; setTextColor(Util.MUTED); setPadding(0, dp(2), 0, dp(10)); letterSpacing = 0.08f })

        // game card
        val gc = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        gc.addView(TextView(this).apply {
            text = "⚡"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = Util.grad(this@MainActivity, Util.ORANGE, Util.AMBER, 16)
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(54)).apply { rightMargin = dp(12) } })
        val gt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        gt.addView(TextView(this).apply { text = Util.GAME_NAME; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) })
        gameSub = TextView(this).apply { textSize = 11.5f; setTextColor(Util.MUTED) }
        gt.addView(gameSub)
        gc.addView(gt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        gameTag = TextView(this).apply { textSize = 10f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(10), dp(5), dp(10), dp(5)) }
        gc.addView(gameTag)
        gc.setOnClickListener { if (!Util.gameInstalled(this)) Util.openStore(this) }
        root.addView(gc)

        // hero rings
        val hero = card()
        fun ring(l: String, u: String) = GaugeView(this).apply {
            label = l; unit = u
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), 0, dp(4), 0) } }
        gFps = ring("FRAME RATE", "Hz"); gBat = ring("BATTERY", "%"); gNet = ring("NETWORK", "ms")
        hero.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(gFps); addView(gBat); addView(gNet) })
        root.addView(hero)

        // mode
        root.addView(section("PERFORMANCE MODE"))
        seg = SegmentView(this, Modes.names) { Modes.set(this, it); modeDesc.text = Modes.desc[it] }
        seg.select(Modes.get(this)); seg.layoutParams = full()
        root.addView(seg)
        modeDesc = TextView(this).apply { textSize = 11.5f; setTextColor(Util.MUTED); setPadding(dp(4), dp(2), dp(4), dp(4)); text = Modes.desc[Modes.get(this@MainActivity)] }
        root.addView(modeDesc)

        // actions
        val play = Util.primary(this, "BOOST & PLAY ${Util.GAME_NAME.uppercase()}") { doBoost(true) }.apply { textSize = 16f; layoutParams = full() }
        root.addView(play)
        result = TextView(this).apply {
            textSize = 13.5f; setTextColor(Color.WHITE); visibility = View.GONE; setLineSpacing(0f, 1.2f)
            setPadding(dp(16), dp(14), dp(16), dp(14)); background = Util.round(this@MainActivity, Color.parseColor("#102A1E"), 16, Util.GREEN); layoutParams = full() }
        root.addView(result)

        fun pair(a: View, c: View) {
            a.layoutParams = wl(); c.layoutParams = wl()
            root.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(a); addView(c) })
        }
        ovBtn = Util.pill(this, "START OVERLAY", Util.CARD2) { toggleOverlay() }
        pair(Util.pill(this, "BOOST NOW", Util.CARD2) { doBoost(false) }, ovBtn)
        voiceBtn = Util.pill(this, "VOICE CHANGER: OFF", Util.CARD2) {
            if (!Util.hasMic(this)) askMic() else {
                val on = VoiceEngine.toggle(); voiceBtn.text = if (on) "VOICE CHANGER: ON" else "VOICE CHANGER: OFF"
                if (on) toast("Use earphones to avoid echo") } }
        pitchBtn = Util.pill(this, "VOICE: Normal", Util.CARD2) {
            pi = (pi + 1) % pitches.size; VoiceEngine.pitch = pitches[pi]; pitchBtn.text = "VOICE: ${pitchNames[pi]}" }
        pair(voiceBtn, pitchBtn)
        pair(Util.pill(this, "FIX PING (DNS)", Util.CARD2) {
                result.visibility = View.VISIBLE
                result.text = "Set Private DNS to:\ndns.google\nor 1dot1dot1dot1.cloudflare-dns.com"
                startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) },
            Util.pill(this, "OPEN GAME", Util.CARD2) {
                GtIntro.play(this, { Util.launchGame(this) }) { toast("${Util.GAME_NAME} not installed"); Util.openStore(this) } })

        pair(Util.pill(this, "BATTERY SAVER", Util.CARD2) {
                if (PowerTools.batterySaver(this)) toast("Battery saver ON") else toast("Switch Battery saver ON here") },
            Util.pill(this, "CHARGE MODE", Util.CARD2) { PowerTools.startCharge(this) })

        // system card
        root.addView(section("SYSTEM"))
        val sys = card()
        bCpu = BarView(this, "CPU"); bGpu = BarView(this, "GPU"); bRam = BarView(this, "RAM"); bTemp = BarView(this, "TEMP")
        sys.addView(bCpu); sys.addView(bGpu); sys.addView(bRam); sys.addView(bTemp)
        info = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 10.5f; setTextColor(Color.parseColor("#C5D1E3")); setLineSpacing(0f, 1.25f)
            setPadding(0, dp(10), 0, 0) }
        sys.addView(info)
        root.addView(sys)

        // setup
        root.addView(section("SETUP"))
        setupBox = card(); root.addView(setupBox)

        root.addView(TextView(this).apply {
            text = "Frame rate = the screen's real refresh rate measured live (reading the game's own FPS needs root). Boost cleans background apps, turns on Do Not Disturb and keeps the screen awake per mode. It does not overclock the CPU/GPU. Some phones block CPU/GPU load readings; those show \"--\"."
            textSize = 10.5f; setTextColor(Util.MUTED); setPadding(dp(4), dp(14), dp(4), 0) })

        setContentView(ScrollView(this).apply { addView(root); setBackgroundColor(Util.BG); isVerticalScrollBarEnabled = false })

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        Thread { val n = SysInfo.gpuName(); h.post { gpuName = n } }.start()
        tick()
    }

    override fun onResume() { super.onResume(); meter.start(); refreshAll() }
    override fun onPause() { meter.stop(); super.onPause() }

    private fun refreshAll() { refreshGame(); refreshSetup(); ovBtn.text = if (OverlayService.running) "STOP OVERLAY" else "START OVERLAY" }

    private fun refreshGame() {
        val ok = Util.gameInstalled(this)
        gameSub.text = if (ok) "Installed  •  ready to boost" else "Not installed  •  tap to open Google Play"
        gameTag.text = if (ok) "READY" else "INSTALL"
        gameTag.setTextColor(if (ok) Util.GREEN else Util.AMBER)
        gameTag.background = Util.round(this, Util.CARD2, 12)
    }

    private fun setupRow(title: String, sub: String, ok: Boolean, onClick: () -> Unit): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tx.addView(TextView(this).apply { text = title; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) })
        tx.addView(TextView(this).apply { text = sub; textSize = 10.5f; setTextColor(Util.MUTED) })
        row.addView(tx, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = if (ok) "✓ ON" else "ENABLE"; textSize = 11f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(if (ok) Util.GREEN else Color.WHITE); setPadding(dp(14), dp(8), dp(14), dp(8))
            background = if (ok) Util.round(this@MainActivity, Color.parseColor("#143D26"), 12) else Util.grad(this@MainActivity, Util.ORANGE, Util.AMBER, 12)
            setOnClickListener { if (!ok) onClick() } })
        return row
    }

    private fun refreshSetup() {
        val ov = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val dn = Build.VERSION.SDK_INT < 23 || nm.isNotificationPolicyAccessGranted
        setupBox.removeAllViews()
        setupBox.addView(setupRow("Display over other apps", "Required for the in-game GT panel", ov) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) })
        setupBox.addView(setupRow("Usage access", "Shows the panel only inside ${Util.GAME_NAME} + auto-boost", Util.hasUsage(this)) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        setupBox.addView(setupRow("Do Not Disturb access", "Silences notifications while gaming", dn) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) })
        setupBox.addView(setupRow("Microphone", "Only for the voice changer (optional)", Util.hasMic(this)) { askMic() })
    }

    private fun askMic() { if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2) }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r); refreshSetup()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun tick() {
        if (!alive) return
        val cpu = SysInfo.cpuLoad(); val gpu = SysInfo.gpuLoad(); val ram = Util.ramPercent(this); val t = Util.temp(this)
        val fps = meter.fps; val bat = Util.battery(this); val maxHz = Util.displayHz(this)
        gFps.set(if (fps <= 0) -1 else (fps * 100 / maxHz).coerceAtMost(100), if (fps <= 0) "--" else "$fps", Util.ORANGE)
        gBat.set(bat, "$bat", if (bat < 20) Util.RED else Util.GREEN)
        val nc = if (ping < 0) Util.MUTED else if (ping < 60) Util.GREEN else if (ping < 120) Util.ORANGE else Util.RED
        gNet.set(if (ping < 0) -1 else (100 - ping / 2).toInt().coerceIn(5, 100), if (ping < 0) "--" else "$ping", nc)
        bCpu.set(cpu, if (cpu < 0) "--" else "$cpu%", Util.loadColor(cpu))
        bGpu.set(gpu, if (gpu < 0) "--" else "$gpu%", Util.loadColor(gpu))
        bRam.set(ram, "$ram%", Util.loadColor(ram))
        bTemp.set(((t - 25f) / 25f * 100).toInt().coerceIn(0, 100), "%.0f°C".format(t), if (t >= 42) Util.RED else if (t >= 38) Util.ORANGE else Util.GREEN)
        val f = SysInfo.cpuFreq()
        info.text = "DEVICE   ${Build.MANUFACTURER} ${Build.MODEL}  |  Android ${Build.VERSION.RELEASE}\n" +
            "CPU      ${SysInfo.cpuName()}  |  ${SysInfo.cores} cores" + (if (f != null) "  |  ${f[0]}/${f[1]} MHz" else "") + "\n" +
            "GPU      $gpuName\n" +
            "MEMORY   ${Util.totalRam(this)}\n" +
            "STATUS   Thermal ${SysInfo.thermal(this)}"
        Util.ping { ping = it }
        ovBtn.text = if (OverlayService.running) "STOP OVERLAY" else "START OVERLAY"
        h.postDelayed({ tick() }, 2000)
    }

    private fun doBoost(play: Boolean) {
        result.visibility = View.VISIBLE; result.text = "Boosting..."
        val mode = Modes.get(this)
        if (play && !OverlayService.running && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) startOverlay(false)
        Util.boost(this) { freed, avail ->
            val dnd = Modes.dnd(mode) && Util.dnd(this, true)
            val t = Util.temp(this)
            result.text = "GAME BOOSTED  |  ${Modes.names[mode]}\n\n" +
                (if (freed > 0) "RAM freed: $freed MB" else "RAM already clean") +
                "\nFree RAM: $avail MB\nTemperature: %.0f°C".format(t) + (if (dnd) "\nDo Not Disturb: ON" else "") +
                (if (t >= 42) "\nPhone is hot. Take a short break." else "")
            result.alpha = 0f; result.scaleX = 0.92f; result.scaleY = 0.92f
            result.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(300).start()
            if (play) GtIntro.play(this, { Util.launchGame(this) }) { result.append("\n${Util.GAME_NAME} not found on this phone."); Util.openStore(this) }
        }
    }

    private fun toggleOverlay() {
        if (OverlayService.running) { stopService(Intent(this, OverlayService::class.java)); ovBtn.text = "START OVERLAY" }
        else startOverlay(true)
    }

    private fun startOverlay(say: Boolean) {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { toast("Enable 'Display over other apps' first"); return }
        val i = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        ovBtn.text = "STOP OVERLAY"
        if (say) toast("Overlay started. Open ${Util.GAME_NAME} and pull the orange edge handle.")
    }

    override fun onDestroy() { alive = false; meter.stop(); h.removeCallbacksAndMessages(null); super.onDestroy() }
}
