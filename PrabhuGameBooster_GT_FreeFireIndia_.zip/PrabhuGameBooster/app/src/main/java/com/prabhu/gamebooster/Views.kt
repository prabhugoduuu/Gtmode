package com.prabhu.gamebooster

import android.content.Context
import android.graphics.*
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** GT-style neon ring gauge. */
class GaugeView(c: Context) : View(c) {
    var label = ""
    var unit = ""
    private var value = -1
    private var txt = "--"
    private var col = Util.ORANGE
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    fun set(v: Int, t: String, color: Int) { value = v; txt = t; col = color; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        val s = MeasureSpec.getSize(w); setMeasuredDimension(s, (s * 1.2f).toInt())
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val st = w * 0.085f; val pad = st * 1.4f
        rect.set(pad, pad, w - pad, w - pad)
        p.style = Paint.Style.STROKE; p.strokeWidth = st; p.strokeCap = Paint.Cap.ROUND
        p.clearShadowLayer()
        p.color = Color.parseColor("#2AFFFFFF"); cv.drawArc(rect, 135f, 270f, false, p)
        if (value >= 0) {
            p.color = col; p.setShadowLayer(st * 0.9f, 0f, 0f, col)
            cv.drawArc(rect, 135f, 270f * value.coerceIn(2, 100) / 100f, false, p)
            p.clearShadowLayer()
        }
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.color = Color.WHITE; p.typeface = Typeface.DEFAULT_BOLD; p.textSize = w * 0.25f
        cv.drawText(txt, w / 2, w * 0.55f, p)
        p.color = col; p.typeface = Typeface.DEFAULT; p.textSize = w * 0.12f
        cv.drawText(unit, w / 2, w * 0.70f, p)
        p.color = Util.MUTED; p.typeface = Typeface.DEFAULT_BOLD; p.textSize = w * 0.115f
        cv.drawText(label, w / 2, w * 1.12f, p)
    }
}

/** Horizontal usage bar (CPU / GPU / RAM / TEMP). */
class BarView(c: Context, private val label: String) : View(c) {
    private var pct = 0
    private var txt = "--"
    private var col = Util.GREEN
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    fun set(v: Int, t: String, color: Int) { pct = v; txt = t; col = color; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Util.dp(context, 32))
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val d = Util.dp(context, 1).toFloat()
        p.textSize = d * 11f
        p.style = Paint.Style.FILL; p.typeface = Typeface.DEFAULT_BOLD
        p.textAlign = Paint.Align.LEFT; p.color = Util.MUTED
        cv.drawText(label, 0f, h * 0.48f, p)
        p.textAlign = Paint.Align.RIGHT; p.color = Color.WHITE
        cv.drawText(txt, w, h * 0.48f, p)
        val top = h - d * 9f; val bot = h - d * 4f
        p.color = Color.parseColor("#2AFFFFFF"); r.set(0f, top, w, bot); cv.drawRoundRect(r, d * 3, d * 3, p)
        if (pct >= 0) {
            p.color = col; r.set(0f, top, w * pct.coerceIn(2, 100) / 100f, bot); cv.drawRoundRect(r, d * 3, d * 3, p)
        }
    }
}

/** Slim edge handle (like the GT-mode side pull tab). */
class HandleView(c: Context) : View(c) {
    var heat = Util.ORANGE
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onDraw(cv: Canvas) {
        val d = Util.dp(context, 1).toFloat()
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#E60A0B0F"); p.setShadowLayer(d * 5f, 0f, 0f, heat)
        r.set(-d * 12f, d * 4f, w - d * 7f, h - d * 4f)
        cv.drawRoundRect(r, d * 10f, d * 10f, p)
        p.clearShadowLayer()
        p.color = heat
        r.set(w - d * 12f, h * 0.5f - d * 14f, w - d * 9f, h * 0.5f + d * 14f)
        cv.drawRoundRect(r, d * 2f, d * 2f, p)
    }
}

/** Segmented control (Power-saving / Balanced / Pro gamer style). */
class SegmentView(c: Context, labels: List<String>, private val onPick: (Int) -> Unit) : LinearLayout(c) {
    private val items = ArrayList<TextView>()

    init {
        orientation = HORIZONTAL
        val d = Util.dp(c, 1)
        setPadding(d * 3, d * 3, d * 3, d * 3)
        background = Util.round(c, Util.CARD, 16)
        labels.forEachIndexed { i, l ->
            val t = TextView(c).apply {
                text = l; textSize = 10.5f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Util.MUTED); setPadding(d * 2, d * 10, d * 2, d * 10)
                layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { select(i); onPick(i) }
            }
            items.add(t); addView(t)
        }
    }

    fun select(i: Int) {
        items.forEachIndexed { k, t ->
            if (k == i) { t.background = Util.grad(context, Util.ORANGE, Util.AMBER, 13); t.setTextColor(Color.WHITE) }
            else { t.background = null; t.setTextColor(Util.MUTED) }
        }
    }
}
