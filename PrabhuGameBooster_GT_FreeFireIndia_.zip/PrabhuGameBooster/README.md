# Prabhu Game Booster  v4.0 (GT Mode)  -  Free Fire India only

Target game package: `com.garena.game.ffi` (Free Fire India). Global / MAX are not boosted or launched.

## Build (no PC needed)
1. Upload this whole folder to your GitHub repo (keep `.github/workflows/build.yml`).
2. GitHub > Actions > "Build APK" > Run workflow (or just push).
3. Download the artifact `PrabhuGameBooster-GT-FreeFireIndia` -> `app-debug.apk`.
Uninstall the old version first if install says "app not installed" (different debug signature).

## First run
Open app -> grant: Display over other apps, Usage access (panel shows only inside the game + auto-boost), Do Not Disturb access.
Tap BOOST & PLAY. In game, pull the orange edge handle on the left. Long-press the handle = quick boost.

## v4.1
Panel > APPS: WhatsApp / YouTube buttons now open the real phone apps. Floating WhatsApp Web: choose "Link with phone number" to log in.
