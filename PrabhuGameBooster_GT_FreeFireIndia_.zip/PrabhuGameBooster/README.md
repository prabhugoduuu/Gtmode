# Prabhu Game Booster  v4.0 (GT Mode)  -  Free Fire India only

Target game package: `com.garena.game.ffi` (Free Fire India). Global / MAX are not boosted or launched.

## Build (no PC needed)
1. Upload this whole folder to your GitHub repo (keep `.github/workflows/build.yml`).
2. GitHub > Actions > "Build APK" > Run workflow (or just push).
3. Download the artifact `PrabhuGameBooster-GT-FreeFireIndia` -> `app-debug.apk`.
Uninstall the old version first if install says "app not installed" (different debug signature).

## First run
Open app -> grant: Display over other apps, Usage access (panel shows only inside the game + auto-boost), Do Not Disturb access.
Tap BOOST & PLAY. In game, pull the orange edge handle on the left. Long-press the handle = quick boost.

## v4.1
Panel > APPS: WhatsApp / YouTube buttons now open the real phone apps. Floating WhatsApp Web: choose "Link with phone number" to log in.
Floating WhatsApp: keyboard fixed (tap the chat box, or the ⌨ button on the window bar). Launching Free Fire India (BOOST + PLAY / OPEN GAME) now shows the GT intro animation first.
Floating window no longer steals the keyboard: tap outside it (e.g. on the real WhatsApp code box) and the keyboard works there.

## Power tools (Tools tab / main screen)
- BATTERY SAVER: opens the Battery saver screen. To let the app switch it on by itself, run once on a PC: `adb shell pm grant com.prabhu.gamebooster android.permission.WRITE_SECURE_SETTINGS`
- CHARGE MODE: Do Not Disturb + (Battery saver if granted) + dim black charging screen with %, temperature, watts, time to full. It cannot raise the charger's real speed.
- Floating WhatsApp Web now stays loaded when you close the window (pairing code is not reset). Keyboard goes to the window only while a text box inside it is selected.
