package com.prabhu.gamebooster

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.text.TextUtils
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import kotlin.math.abs

class OverlayService : Service() {
    companion object {
        const val ACTION_STOP = "com.prabhu.gamebooster.STOP"
        const val ACTION_SHOW = "com.prabhu.gamebooster.SHOW_RAIL"
        @Volatile var running = false
        @Volatile var refreshTheme: (() -> Unit)? = null
    }

    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private val meter = FpsMeter()

    private var handle: HandleView? = null
    private var handleLp: WindowManager.LayoutParams? = null
    private var hud: TextView? = null
    private var panel: LinearLayout? = null
    private var content: FrameLayout? = null
    private var bannerView: View? = null
    private val railBtns = ArrayList<LinearLayout>()
    private var curTab = 0

    private var appWin: LinearLayout? = null
    private var appLp: WindowManager.LayoutParams? = null
    private var appWeb: WebView? = null
    private var sizeIdx = 1
    private var winW = 0.90f
    private var winH = 0.52f
    private val lockViews = ArrayList<View>()
    private var lockArmed = false
    private var inGameNow = false
    private var inGameSince = 0L
    private var lastBounce = 0L
    private var bounceCount = 0
    private var lastGamePkg: String? = null
    private val lockOkPkgs = setOf("com.android.systemui", "com.google.android.dialer", "com.android.dialer",
        "com.android.incallui", "com.samsung.android.incallui", "com.google.android.permissioncontroller", "com.android.permissioncontroller")
    private val sizes = listOf(0.70f to 0.38f, 0.90f to 0.52f, 0.97f to 0.72f)

    private var gFps: GaugeView? = null
    private var gBat: GaugeView? = null
    private var gNet: GaugeView? = null
    private var bCpu: BarView? = null
    private var bGpu: BarView? = null
    private var bRam: BarView? = null
    private var bTemp: BarView? = null
    private var vStatus: TextView? = null
    private var vHeadTemp: TextView? = null
    private var modeDescV: TextView? = null
    private var modeSeg: SegmentView? = null

    private var alive = true
    private var gameVisible = true
    private var wasInGame = false
    private var lastAuto = 0L
    private var lastHeat = 0L
    private var tickN = 0
    @Volatile private var ping = -1L

    private val sens = IntArray(6)
    private val sensNames = listOf("General", "Red Dot", "2x Scope", "4x Scope", "Sniper", "AWM")
    private val presets = linkedMapOf(
        "Normal" to intArrayOf(75, 70, 65, 60, 50, 45),
        "High" to intArrayOf(88, 84, 80, 75, 65, 60),
        "Pro" to intArrayOf(95, 92, 88, 84, 75, 70),
        "Max" to intArrayOf(100, 100, 98, 95, 88, 85))
    private val desktopUA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int) = Util.dp(this, v)
    private fun type() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun mlp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(3), dp(5), dp(3), dp(5)) }
    private fun wlp() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), dp(5), dp(3), dp(5)) }
    private fun isLand() = resources.displayMetrics.let { it.widthPixels > it.heightPixels }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (i?.action == ACTION_SHOW) { h.post { gameVisible = true; showRail() } }
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    override fun onCreate() {
        super.onCreate()
        running = true
        Apps.load(this)
        Util.initTheme(this)
        refreshTheme = { h.post {
            handle?.let { it.heat = Util.ACC; it.invalidate() }
            if (panel != null) { closePanel(false); openPanel() }
        } }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(NotificationChannel("pgb", "Overlay", NotificationManager.IMPORTANCE_LOW))
        }
        val flag = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val stopPi = PendingIntent.getService(this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), flag)
        val openPi = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), flag)
        val showPi = PendingIntent.getService(this, 3, Intent(this, OverlayService::class.java).setAction(ACTION_SHOW), flag)
        val nb = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "pgb") else Notification.Builder(this)
        val n = nb.setContentTitle("Prabhu Game Booster  |  GT Mode")
            .setContentText("Overlay ready for ${Util.GAME_NAME}")
            .setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(openPi)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_view, "Side options", showPi).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)

        val sp = getSharedPreferences("sensi", MODE_PRIVATE)
        val d = presets["High"]!!
        for (k in 0..5) sens[k] = sp.getInt("s$k", d[k])
        winW = Util.pref(this).getFloat("ww", 0.90f).coerceIn(0.2f, 1f)
        winH = Util.pref(this).getFloat("wh", 0.52f).coerceIn(0.2f, 1f)
        Music.onChange = { h.post { musicRefresh(); syncTop() } }
        hideClock(false)
        addHandle(); applyAwake(); syncHud(); tick()
    }

    // ---------------- edge handle ----------------
    private fun addHandle() {
        // invisible strip on the left edge. 3 taps OR 3 swipes-in (within 3 s) bring the side options back.
        // (Phones with gesture navigation use the very edge for Back, so TAPS are the reliable way there.)
        val v = HandleView(this)
        val lp = WindowManager.LayoutParams(dp(30), dp(220), type(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.START or Gravity.CENTER_VERTICAL; lp.x = 0
        v.alpha = 0.02f
        var downX = 0f; var downY = 0f; var counted = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; counted = false }
                MotionEvent.ACTION_MOVE -> if (!counted && e.rawX - downX > dp(36)) { counted = true; onEdgeSwipe() }
                MotionEvent.ACTION_UP -> if (!counted && abs(e.rawX - downX) < dp(14) && abs(e.rawY - downY) < dp(14)) onEdgeSwipe()
            }
            true
        }
        wm.addView(v, lp); handle = v; handleLp = lp
        h.postDelayed({ showRail() }, 700)   // show the options once right after the overlay starts, so you can see them
    }

    private val swipeTimes = ArrayList<Long>()
    private fun onEdgeSwipe() {
        val now = System.currentTimeMillis()
        swipeTimes.add(now)
        swipeTimes.removeAll { now - it > 3000L }
        if (swipeTimes.size >= 3) { swipeTimes.clear(); showRail() }
    }

    // ---------------- side options (bubbles) - hide by themselves after 5 s ----------------
    private var rail: LinearLayout? = null
    private val hideRailR = Runnable { hideRail(true) }
    /** 0 = side options always stay; otherwise they hide after this many seconds (set from the booster: SIDE OPTIONS tile). */
    private fun railSec() = Util.pref(this).getInt("rail_sec", 5)
    private fun scheduleRailHide() { h.removeCallbacks(hideRailR); val s = railSec(); if (s > 0) h.postDelayed(hideRailR, s * 1000L) }
    private var fgKnown = false
    /** Always-on mode: keep the options on screen while the game is in front (and hide them for the full panel). */
    private fun syncRail() {
        if (railSec() != 0) return
        val want = (inGameNow || !fgKnown) && gameVisible && panel == null
        if (want) showRail() else if (rail != null) hideRail(true)
    }

    private fun openTabFromRail(i: Int) { curTab = i; hideRail(true); openPanel() }

    private fun railBubble(ic: String, name: String, size: Int, run: () -> Unit): TextView = TextView(this).apply {
        text = ic; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#E6101828")); setStroke(dp(1), Util.alpha(Util.ACC, 0xAA)) }
        layoutParams = LinearLayout.LayoutParams(size, size).apply { topMargin = dp(3); bottomMargin = dp(3) }
        setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_DOWN) scheduleRailHide(); false }
        setOnClickListener { run() }
        setOnLongClickListener { android.widget.Toast.makeText(this@OverlayService, name, android.widget.Toast.LENGTH_SHORT).show(); true }
    }

    private fun showRail() {
        if (rail != null) { scheduleRailHide(); return }
        if (panel != null || !gameVisible) return
        val size = minOf(dp(42), (resources.displayMetrics.heightPixels - dp(30)) / 6 - dp(6))
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(5), dp(8), dp(5), dp(8))
            background = Util.round(this@OverlayService, Color.parseColor("#B3060912"), 22, Util.alpha(Util.ACC, 0x55))
        }
        val opts = listOf<Triple<String, String, () -> Unit>>(
            Triple("⚡", "Boost now") { doBoost(false) },
            Triple("🚀", "Perform") { openTabFromRail(0) },
            Triple("🧰", "Tools") { openTabFromRail(1) },
            Triple("🎯", "Sensitivity") { openTabFromRail(2) },
            Triple("🎵", "Music") { openTabFromRail(3) },
            Triple("📺", "Apps") { openTabFromRail(4) })
        for (o in opts) box.addView(railBubble(o.first, o.second, size, o.third))
        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.START or Gravity.CENTER_VERTICAL; lp.x = dp(2)
        box.alpha = 0f; box.translationX = -dp(60).toFloat()
        try { wm.addView(box, lp) } catch (e: Exception) { return }
        rail = box
        box.animate().alpha(1f).translationX(0f).setDuration(200).start()
        scheduleRailHide()
    }

    private fun hideRail(anim: Boolean) {
        h.removeCallbacks(hideRailR)
        val r = rail ?: return
        rail = null
        if (anim) r.animate().alpha(0f).translationX(-dp(60).toFloat()).setDuration(220)
            .withEndAction { try { wm.removeView(r) } catch (e: Exception) {} }.start()
        else try { wm.removeView(r) } catch (e: Exception) {}
    }

    private fun applyAwake() {
        val lp = handleLp ?: return; val v = handle ?: return
        val keep = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        lp.flags = if (Modes.awake(Modes.get(this))) lp.flags or keep else lp.flags and keep.inv()
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
    }

    // ---------------- mini HUD ----------------
    private fun hudWanted() = Util.pref(this).getBoolean("hud", false) && gameVisible && !esportsActive()

    private fun syncHud() {
        if (hudWanted() && hud == null) {
            val t = TextView(this).apply {
                textSize = 11f; setTextColor(Color.WHITE); typeface = Util.BOLD
                setPadding(dp(12), dp(5), dp(12), dp(5))
                background = Util.round(this@OverlayService, Color.parseColor("#CC0A0B0F"), 14, Util.alpha(Util.ACC, 0x66))
                text = "-- Hz   -- ms"
            }
            val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, type(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = dp(4)
            wm.addView(t, lp); hud = t
        } else if (!hudWanted() && hud != null) {
            try { wm.removeView(hud) } catch (e: Exception) {}
            hud = null
        }
        syncFps()
    }

    private fun syncFps() { if (panel != null || hud != null) meter.start() else meter.stop() }

    // ---------------- top of the game: now-playing bar ----------------
    private var topStack: LinearLayout? = null
    private var topLp: WindowManager.LayoutParams? = null
    private var musicRow: LinearLayout? = null
    private var musicBarTitle: TextView? = null
    private var barSong = -2

    private fun removeTop() {
        topStack?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        topStack = null; topLp = null; musicRow = null; musicBarTitle = null; barSong = -2
    }

    /** Landscape top bar with dancing bars + song name (switch: Music tab > TOP BAR IN GAME) Never takes touches. */
    private fun syncTop() {
        val quiet = esportsActive()
        val wantMusic = !quiet && inGameNow && isLand() && Util.pref(this).getBoolean("musicbar", true) && Music.playing
        if (!wantMusic) { removeTop(); return }
        val c = this
        if (topStack == null) {
            val stack = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            val mr = LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(5), dp(14), dp(5))
                background = Util.round(c, Color.parseColor("#CC0A0B0F"), 16, Util.alpha(Util.ACC, 0x88))
            }
            mr.addView(MiniEq(c), LinearLayout.LayoutParams(dp(26), dp(16)))
            val mt = TextView(c).apply {
                textSize = 11f; setTextColor(Color.WHITE); typeface = Util.BOLD
                setSingleLine(true); ellipsize = TextUtils.TruncateAt.MARQUEE; marqueeRepeatLimit = -1
                isSelected = true; maxWidth = dp(230)
            }
            mr.addView(mt, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
            stack.addView(mr)
            val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, type(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = dp(4)
            try { wm.addView(stack, lp) } catch (e: Exception) { return }
            topStack = stack; topLp = lp; musicRow = mr; musicBarTitle = mt; barSong = -2
        }
        val y = if (hud != null) dp(30) else dp(4)
        val tl = topLp; val ts = topStack
        if (tl != null && ts != null && tl.y != y) { tl.y = y; try { wm.updateViewLayout(ts, tl) } catch (e: Exception) {} }

        val mr = musicRow; val mt = musicBarTitle
        if (mr != null && mt != null) {
            if (wantMusic) {
                mr.visibility = View.VISIBLE
                if (Music.index != barSong) {
                    barSong = Music.index
                    mt.text = "♪  " + (Music.current?.title ?: "")
                    mr.translationY = -dp(40).toFloat(); mr.alpha = 0f
                    mr.animate().translationY(0f).alpha(1f).setDuration(380).setInterpolator(android.view.animation.OvershootInterpolator(1.3f)).start()
                }
            } else { mr.visibility = View.GONE; barSong = -2 }
        }
    }

    // ---------------- ESPORTS mode ----------------
    private var esApplied = false

    /** ESPORTS is active only while the game itself is in front. */
    private fun esportsActive() = inGameNow && Modes.get(this) == Modes.ESPORTS

    private fun lockOn() = Util.pref(this).getBoolean("glock", false) || Modes.get(this) == Modes.ESPORTS

    private fun applyEsports() {
        val on = esportsActive()
        handle?.alpha = 0.02f   // edge strip is always invisible; swipe in 3 times to show the side options
        if (on != esApplied) { esApplied = on; syncHud(); hideClock(on); syncTop() }
    }

    /** Hides the status-bar clock while ESPORTS is active. Needs: adb shell pm grant com.prabhu.gamebooster android.permission.WRITE_SECURE_SETTINGS */
    private fun hideClock(on: Boolean) {
        val sp = Util.pref(this)
        try {
            if (on) {
                if (sp.getBoolean("clockHidden", false)) return
                val cur = Settings.Secure.getString(contentResolver, "icon_blacklist") ?: ""
                sp.edit().putString("clockOrig", cur).putBoolean("clockHidden", true).apply()
                if (!cur.split(",").contains("clock"))
                    Settings.Secure.putString(contentResolver, "icon_blacklist", if (cur.isEmpty()) "clock" else "$cur,clock")
            } else {
                if (!sp.getBoolean("clockHidden", false)) return
                Settings.Secure.putString(contentResolver, "icon_blacklist", sp.getString("clockOrig", "") ?: "")
                sp.edit().putBoolean("clockHidden", false).apply()
            }
        } catch (e: Exception) { if (on) sp.edit().putBoolean("clockHidden", false).apply() }
    }

    // ---------------- banner ----------------
    private fun banner(title: String, sub: String, color: Int = Util.GREEN) {
        if (esportsActive() && panel == null) return   // ESPORTS: nothing but the game on screen
        bannerView?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        val ll = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(24), dp(14), dp(24), dp(14))
            background = Util.round(this@OverlayService, Color.parseColor("#F2101626"), 22, color)
        }
        ll.addView(TextView(this).apply { text = title; setTextColor(color); textSize = 17f; typeface = Util.BOLD; gravity = Gravity.CENTER; letterSpacing = 0.05f })
        ll.addView(TextView(this).apply { text = sub; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) })
        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = dp(40)
        ll.alpha = 0f; ll.scaleX = 0.8f; ll.scaleY = 0.8f
        wm.addView(ll, lp); bannerView = ll
        ll.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240).start()
        h.postDelayed({
            if (bannerView === ll) {
                ll.animate().alpha(0f).setDuration(300).withEndAction { try { wm.removeView(ll) } catch (e: Exception) {} }.start()
                bannerView = null
            }
        }, 2800)
    }

    private fun doBoost(play: Boolean) {
        banner("BOOSTING...", "Closing background apps", Util.ORANGE)
        val mode = Modes.get(this)
        Util.boost(this) { freed, avail ->
            val dnd = Modes.dnd(mode) && Util.dnd(this, true)
            val t = Util.temp(this)
            banner("GAME BOOSTED  |  ${Modes.names[mode]}",
                (if (freed > 0) "$freed MB freed" else "RAM already clean") + "  |  $avail MB free\n%.0f°C".format(t) +
                    (if (dnd) "  |  DND ON" else ""))
            if (play) {
                closePanel()
                GtIntro.play(this, { Util.launchGame(this) }) { banner("${Util.GAME_NAME} not found", "Install it from Google Play first", Util.ORANGE) }
            }
            refreshStats()
        }
    }

    // ---------------- GT dashboard panel ----------------
    private fun label(t: String, size: Float = 11f, color: Int = Util.MUTED) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); setPadding(dp(4), dp(6), dp(4), dp(2))
    }

    private fun section(t: String) = Util.sectionHeader(this, t)

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(10))
        background = Util.glass(this@OverlayService, 20)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(2), dp(4), dp(2), dp(4)) }
    }

    private fun grid(tiles: List<TileView>, cols: Int = 3): LinearLayout {
        val g = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tiles.chunked(cols).forEach { rowT ->
            g.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                rowT.forEach { addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }) }
                repeat(cols - rowT.size) { addView(View(context), LinearLayout.LayoutParams(0, 1, 1f)) }
            })
        }
        return g
    }

    private fun scroll(v: View) = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(v) }

    private fun railButton(icon: String, name: String, onClick: () -> Unit): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        setPadding(dp(2), dp(9), dp(2), dp(8))
        addView(TextView(context).apply { text = icon; textSize = 18f; gravity = Gravity.CENTER; tag = "i" })
        addView(TextView(context).apply { text = name; textSize = 9f; gravity = Gravity.CENTER; typeface = Util.BOLD; tag = "n" })
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(3), 0, dp(3)) }
        setOnClickListener { onClick() }
    }

    private fun togglePanel() { if (panel != null) closePanel() else openPanel() }

    private fun openPanel() {
        if (panel != null) return
        val c = this; val dm = resources.displayMetrics; val land = isLand()
        val pw = if (land) minOf((dm.widthPixels * 0.76f).toInt(), dp(640)) else (dm.widthPixels * 0.95f).toInt()
        val ph = if (land) (dm.heightPixels * 0.88f).toInt() else (dm.heightPixels * 0.74f).toInt()

        val root = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#F5121A30"), Color.parseColor("#F506090F"))).apply { cornerRadius = dp(28).toFloat(); setStroke(dp(1), Util.alpha(Util.ACC, 0x88)) }
        }
        val rail = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(6), dp(10), dp(6), dp(10))
            background = Util.round(c, Color.parseColor("#D9060912"), 24, Color.parseColor("#1AFFFFFF"))
        }
        rail.addView(TextView(c).apply { text = "⚡"; textSize = 18f; setTextColor(Util.ON_ACC); gravity = Gravity.CENTER; background = Util.accGrad(c, 14)
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { bottomMargin = dp(8) } })
        railBtns.clear()
        val tabsCol = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        listOf("🚀" to "PERFORM", "🧰" to "TOOLS", "🎯" to "SENSI", "🎵" to "MUSIC", "📺" to "APPS").forEachIndexed { i, (ic, nm) ->
            val b = railButton(ic, nm) { showTab(i) }
            railBtns.add(b); tabsCol.addView(b)
        }
        rail.addView(scroll(tabsCol), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        rail.addView(railButton("✕", "CLOSE") { closePanel() }.also { styleRail(it, false) })
        rail.addView(railButton("⏻", "STOP") { stopSelf() }.also { styleRail(it, false) })

        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(8)) }
        val head = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titles = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        val ht = TextView(c).apply { text = "HYPERBOOST"; setTextColor(Util.ACC); textSize = 16f; typeface = Util.HEAD; letterSpacing = 0.14f }
        ht.post { ht.paint.shader = LinearGradient(0f, 0f, ht.paint.measureText(ht.text.toString()), 0f, Util.ACC, Util.ACC2, Shader.TileMode.CLAMP); ht.invalidate() }
        titles.addView(ht)
        titles.addView(TextView(c).apply { text = "GT MODE  •  PRABHU GAME BOOSTER"; setTextColor(Util.MUTED); textSize = 8.5f; letterSpacing = 0.1f })
        head.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val tchip = TextView(c).apply {
            text = "--°C"; textSize = 9.5f; typeface = Util.BOLD; setTextColor(Util.GREEN); setPadding(dp(10), dp(5), dp(10), dp(5))
            background = Util.glass(c, 12) }
        vHeadTemp = tchip
        head.addView(tchip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) })
        val ready = Util.gameInstalled(c)
        head.addView(TextView(c).apply {
            text = "●  " + Util.GAME_NAME.uppercase(); textSize = 9f; typeface = Util.BOLD; letterSpacing = 0.04f
            setTextColor(if (ready) Util.GREEN else Util.AMBER); setPadding(dp(10), dp(5), dp(10), dp(5))
            background = Util.glass(c, 12)
        })
        val ct = FrameLayout(c); content = ct
        col.addView(head)
        col.addView(ct, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(6) })

        root.addView(rail, LinearLayout.LayoutParams(dp(66), ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        val lp = WindowManager.LayoutParams(pw, ph, type(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.START or Gravity.CENTER_VERTICAL; lp.x = dp(8)
        root.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) { closePanel(); true } else false }
        root.translationX = -pw.toFloat()
        wm.addView(root, lp); panel = root
        root.animate().translationX(0f).setDuration(230).setInterpolator(DecelerateInterpolator()).start()
        syncFps()
        showTab(curTab)
        applyEsports()
    }

    private fun closePanel(anim: Boolean = true) {
        val p = panel ?: return
        panel = null; content = null
        gFps = null; gBat = null; gNet = null; bCpu = null; bGpu = null; bRam = null; bTemp = null
        vStatus = null; vHeadTemp = null; modeDescV = null; modeSeg = null; musicTitle = null; musicSeek = null; musicList = null
        if (anim) p.animate().translationX(-p.width.toFloat()).setDuration(180)
            .withEndAction { try { wm.removeView(p) } catch (e: Exception) {} }.start()
        else try { wm.removeView(p) } catch (e: Exception) {}
        syncFps(); applyEsports()
        if (railSec() == 0) h.postDelayed({ syncRail() }, 300)
    }

    private fun styleRail(b: LinearLayout, sel: Boolean) {
        val col = if (sel) Util.ACC else Util.MUTED
        (b.findViewWithTag<TextView>("i"))?.setTextColor(col)
        (b.findViewWithTag<TextView>("n"))?.setTextColor(col)
        b.background = if (sel) Util.glassOn(this, 16) else null
    }

    private fun showTab(i: Int) {
        curTab = i
        railBtns.forEachIndexed { k, b -> styleRail(b, k == i) }
        val ct = content ?: return
        ct.removeAllViews()
        gFps = null; gBat = null; gNet = null; bCpu = null; bGpu = null; bRam = null; bTemp = null
        vStatus = null; modeDescV = null; modeSeg = null; musicTitle = null; musicSeek = null; musicList = null
        when (i) { 0 -> ct.addView(perfTab()); 1 -> ct.addView(toolsTab()); 2 -> ct.addView(sensiTab()); 3 -> ct.addView(musicTab()); else -> ct.addView(appsTab()) }
        refreshStats()
    }

    private fun setMode(i: Int) {
        Modes.set(this, i); applyAwake(); lastAuto = 0L
        modeDescV?.text = Modes.desc[i]
        if (Modes.dnd(i)) Util.dnd(this, true)
        clearLock(); syncLock(); applyEsports()
        ModeFx.show(this, i)
    }

    private fun toggleChip(text: String, key: String, def: Boolean, after: () -> Unit = {}): TextView {
        val sp = Util.pref(this)
        val t = Util.pill(this, "", Util.CARD2) {}
        fun paint() {
            val on = sp.getBoolean(key, def)
            t.text = (if (on) "●  " else "○  ") + text
            t.setTextColor(if (on) Util.ON_ACC else Util.MUTED)
            t.background = if (on) Util.accGrad(this, 16) else Util.glass(this, 16)
            t.textSize = 10.5f
        }
        paint()
        t.setOnClickListener { sp.edit().putBoolean(key, !sp.getBoolean(key, def)).apply(); paint(); after() }
        t.layoutParams = wlp()
        return t
    }

    private fun perfTab(): View {
        val c = this; val land = isLand()
        val wrap = LinearLayout(c).apply { orientation = if (land) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL }
        val left = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        val right = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }

        fun ring(l: String, u: String): GaugeView = GaugeView(c).apply {
            label = l; unit = u
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), dp(2), dp(3), 0) }
        }
        val rf = ring("FRAME RATE", "Hz"); val rb = ring("BATTERY", "%"); val rn = ring("NETWORK", "ms")
        gFps = rf; gBat = rb; gNet = rn
        val gc = card()
        gc.addView(LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; addView(rf); addView(rb); addView(rn) })
        left.addView(gc)
        left.addView(section("PERFORMANCE MODE"))
        val mc = card()
        val seg = SegmentView(c, Modes.names) { setMode(it) }
        seg.select(Modes.get(c)); modeSeg = seg
        mc.addView(seg, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val md = label(Modes.desc[Modes.get(c)]); modeDescV = md; mc.addView(md)
        left.addView(mc)

        right.addView(section("SYSTEM"))
        val sc = card()
        val cpu = BarView(c, "CPU"); val gpu = BarView(c, "GPU"); val ram = BarView(c, "RAM"); val tmp = BarView(c, "TEMP")
        bCpu = cpu; bGpu = gpu; bRam = ram; bTemp = tmp
        sc.addView(cpu); sc.addView(gpu); sc.addView(ram); sc.addView(tmp)
        val st = TextView(c).apply { textSize = 10.5f; setTextColor(Color.WHITE); setPadding(dp(2), dp(6), dp(2), dp(2)) }
        vStatus = st; sc.addView(st)
        right.addView(sc)
        right.addView(section("SWITCHES"))
        right.addView(LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(toggleChip("AUTO BOOST", "auto", true))
            addView(toggleChip("MINI HUD", "hud", false) { syncHud() })
        })
        right.addView(LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(toggleChip("GAME LOCK", "glock", false) { onLockToggled() })
        })
        right.addView(label("Game Lock: while ON, Back / Home / Recents cannot take you out of the game (nav-bar area is blocked and, if you still leave, the game is brought straight back). Turn it OFF here to exit. Needs Usage Access.", 9.5f))
        right.addView(Util.primary(c, "BOOST NOW") { doBoost(false) }.apply { layoutParams = mlp() })
        right.addView(Util.pill(c, "BOOST + PLAY ${Util.GAME_NAME.uppercase()}", Util.CARD2) { doBoost(true) }.apply { layoutParams = mlp() })

        if (land) {
            wrap.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.1f))
            wrap.addView(right, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(12) })
        } else {
            wrap.addView(left, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            wrap.addView(right, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        return scroll(wrap)
    }

    // ---------------- tools ----------------
    private fun toolsTab(): View {
        val c = this
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(section("QUICK TOOLS"))
        col.addView(grid(listOf(
            TileView(c, "🧹", "CLEAN RAM") { doBoost(false) },
            TileView(c, "📡", "PING TEST") {
                Util.ping { r -> h.post { banner("PING", if (r < 0) "No internet" else "$r ms  " + (if (r < 60) "Excellent" else if (r < 120) "Good" else "High")) } } },
            TileView(c, "🔕", "DND ON") { if (!Util.dnd(this, true)) askDnd() else banner("DND ON", "Notifications silenced") },
            TileView(c, "🔔", "DND OFF") { if (!Util.dnd(this, false)) askDnd() else banner("DND OFF", "Notifications restored") },
            TileView(c, "🔋", "BATTERY SAVER") {
                if (PowerTools.batterySaver(this)) banner("BATTERY SAVER ON", "Low power mode enabled", Util.GREEN)
                else { closePanel(); banner("BATTERY SAVER", "Switch it ON on the settings screen", Util.ORANGE) } },
            TileView(c, "⚡", "CHARGE MODE") { closePanel(); PowerTools.startCharge(this) },
            TileView(c, "📶", "FIX PING (DNS)") {
                closePanel()
                startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                banner("PRIVATE DNS", "Set it to dns.google", Util.ORANGE) })))

        col.addView(section("THEME"))
        val tc = card()
        tc.addView(Util.themeRow(c) { i -> Util.setTheme(this, i); refreshTheme?.invoke() })
        col.addView(tc)
        return scroll(col)
    }

    private fun askDnd() {
        banner("DND access needed", "Enable it for Prabhu Game Booster", Util.ORANGE)
        startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------------- sensitivity ----------------
    private fun sensiTab(): View {
        val c = this
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(section("${Util.GAME_NAME.uppercase()} SENSITIVITY (0-100)"))
        col.addView(label("Tap a preset, then enter the same numbers in the game."))
        val bars = ArrayList<SeekBar>(); val vals = ArrayList<TextView>()
        val pr = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        for ((name, arr) in presets) pr.addView(Util.pill(c, name, Util.CARD2) { for (k in 0..5) bars[k].progress = arr[k] }.apply { layoutParams = wlp() })
        col.addView(pr)
        val sp = getSharedPreferences("sensi", MODE_PRIVATE)
        for (k in 0..5) {
            val line = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), dp(4), dp(4), 0) }
            line.addView(TextView(c).apply { text = sensNames[k]; setTextColor(Color.WHITE); textSize = 12.5f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
            val vt = TextView(c).apply { text = "${sens[k]}"; setTextColor(Util.ACC); textSize = 14f; typeface = Util.BOLD }
            vals.add(vt); line.addView(vt)
            val sb = SeekBar(c).apply {
                max = 100; progress = sens[k]
                progressTintList = ColorStateList.valueOf(Util.ACC); thumbTintList = ColorStateList.valueOf(Util.ACC2)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { sens[k] = v; vals[k].text = "$v"; sp.edit().putInt("s$k", v).apply() }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            bars.add(sb); col.addView(line); col.addView(sb)
        }
        col.addView(label("Android does not allow apps to change in-game sensitivity. Use these as a starting point in Settings > Sensitivity.", 10f))
        col.addView(Util.primary(c, "OPEN ${Util.GAME_NAME.uppercase()}") {
            closePanel(); GtIntro.play(this, { Util.launchGame(this) }) { banner("${Util.GAME_NAME} not found", "Install it from Google Play first", Util.ORANGE) } }.apply { layoutParams = mlp() })
        return scroll(col)
    }

    // ---------------- music ----------------
    private var musicTitle: TextView? = null
    private var musicArtist: TextView? = null
    private var musicSeek: SeekBar? = null
    private var musicTime: TextView? = null
    private var musicPlay: TextView? = null
    private var musicList: ListView? = null
    private var musicAdapter: BaseAdapter? = null
    private var musicSeeking = false
    private var musicGen = 0

    private fun fmt(ms: Int): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

    private fun musicRefresh() {
        val cur = Music.current
        musicTitle?.text = cur?.title ?: "Pick a song"
        musicArtist?.text = cur?.artist ?: "${Music.songs.size} songs on your phone"
        musicPlay?.text = if (Music.playing) "⏸" else "▶"
        musicAdapter?.notifyDataSetChanged()
        if (cur != null) musicList?.smoothScrollToPosition(Music.index)
    }

    private fun musicTick(g: Int) {
        if (g != musicGen) return
        val sb = musicSeek ?: return
        if (panel == null) return
        val d = Music.duration(); val p = Music.position()
        if (!musicSeeking) { sb.max = maxOf(d, 1); sb.progress = p }
        musicTime?.text = fmt(p) + " / " + fmt(d)
        musicPlay?.text = if (Music.playing) "⏸" else "▶"
        h.postDelayed({ musicTick(g) }, 500)
    }

    private fun musicTab(): View {
        val c = this; val land = isLand()
        fun openPick() {
            closePanel()
            startActivity(Intent(this, MainActivity::class.java).putExtra("pick_music", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
        if (!Music.hasPerm(c) && Music.extraCount(c) == 0) {
            val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
            col.addView(section("MUSIC PLAYER"))
            col.addView(label("Allow access to the songs on your phone (one time). The app will open, tap Allow."))
            col.addView(Util.primary(c, "ALLOW MUSIC ACCESS") {
                closePanel()
                startActivity(Intent(this, MainActivity::class.java).putExtra("ask_music", true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            }.apply { layoutParams = mlp() })
            col.addView(Util.pill(c, "OR PICK SONGS MANUALLY", Util.CARD2) { openPick() }.apply { layoutParams = mlp() })
            col.addView(label("Tip: also allow Microphone in the app so the bars follow the real beat. Without it the bars still dance.", 10f))
            return scroll(col)
        }
        Music.load(c)
        if (Music.songs.isEmpty()) {
            val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
            col.addView(section("MUSIC PLAYER")); col.addView(label("No songs found.  " + Music.info, 10.5f))
            col.addView(Util.pill(c, "PICK SONGS MANUALLY", Util.CARD2) { openPick() }.apply { layoutParams = mlp() })
            col.addView(label("Pick the songs from your Files / Downloads / Music folder. They are remembered.", 10f))
            return scroll(col)
        }

        val top = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        top.addView(section("NOW PLAYING"))
        top.addView(EqView(c), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(4), 0, dp(4)) })
        val title = TextView(c).apply { setTextColor(Color.WHITE); textSize = 13.5f; typeface = Util.BOLD
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(dp(4), 0, dp(4), 0) }
        val artist = TextView(c).apply { setTextColor(Util.MUTED); textSize = 10.5f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(dp(4), 0, dp(4), 0) }
        top.addView(title); top.addView(artist)
        val sb = SeekBar(c).apply {
            progressTintList = ColorStateList.valueOf(Util.ACC); thumbTintList = ColorStateList.valueOf(Util.ACC2)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { if (u) musicTime?.text = fmt(v) + " / " + fmt(Music.duration()) }
                override fun onStartTrackingTouch(s: SeekBar?) { musicSeeking = true }
                override fun onStopTrackingTouch(s: SeekBar?) { Music.seekTo(s?.progress ?: 0); musicSeeking = false }
            })
        }
        val tm = TextView(c).apply { setTextColor(Util.MUTED); textSize = 10f; gravity = Gravity.END; setPadding(dp(4), 0, dp(4), 0); text = "0:00 / 0:00" }
        top.addView(sb); top.addView(tm)
        val play = Util.pill(c, "▶", Util.CARD2) { Music.toggle(c); musicRefresh() }.apply { textSize = 16f; layoutParams = wlp() }
        val ctr = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        ctr.addView(Util.pill(c, "⏮", Util.CARD2) { Music.prev(c) }.apply { textSize = 16f; layoutParams = wlp() })
        ctr.addView(play)
        ctr.addView(Util.pill(c, "⏭", Util.CARD2) { Music.next(c) }.apply { textSize = 16f; layoutParams = wlp() })
        top.addView(ctr)
        top.addView(LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(toggleChip("LOOP SONG", "loop1", false) { Music.applyLoop(c) })
            addView(toggleChip("TOP BAR IN GAME", "musicbar", true) { syncTop() })
        })
        val volLabel = TextView(c).apply { setTextColor(Util.MUTED); textSize = 10.5f; setPadding(dp(4), dp(6), dp(4), 0); text = "SONG VOLUME  " + Music.volumePct(c) + "%" }
        val volBar = SeekBar(c).apply {
            max = 100; progress = Music.volumePct(c)
            progressTintList = ColorStateList.valueOf(Util.ACC); thumbTintList = ColorStateList.valueOf(Util.ACC2)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { Music.setVolumePct(c, v); volLabel.text = "SONG VOLUME  $v%" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        top.addView(volLabel); top.addView(volBar)
        top.addView(Util.pill(c, "+ ADD MORE SONGS", Util.CARD2) { openPick() }.apply { textSize = 10.5f; layoutParams = mlp() })

        val adapter = object : BaseAdapter() {
            override fun getCount() = Music.songs.size
            override fun getItem(position: Int): Any = Music.songs[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, cv: View?, parent: ViewGroup?): View {
                val row = (cv as? LinearLayout) ?: LinearLayout(c).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(7), dp(10), dp(7))
                    addView(TextView(c).apply { textSize = 12.5f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; tag = "t" })
                    addView(TextView(c).apply { textSize = 10f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setTextColor(Util.MUTED); tag = "a" })
                }
                val s = Music.songs[position]; val on = position == Music.index
                row.findViewWithTag<TextView>("t").apply { text = s.title; setTextColor(if (on) Util.ACC else Color.WHITE); typeface = if (on) Util.BOLD else Typeface.DEFAULT }
                row.findViewWithTag<TextView>("a").text = s.artist
                row.background = if (on) Util.round(c, Util.CARD2, 10) else null
                return row
            }
        }
        val lv = ListView(c).apply {
            divider = null; isVerticalScrollBarEnabled = false; cacheColorHint = Color.TRANSPARENT
            this.adapter = adapter
            setOnItemClickListener { _, _, pos, _ -> Music.play(c, pos) }
        }
        musicTitle = title; musicArtist = artist; musicSeek = sb; musicTime = tm; musicPlay = play; musicList = lv; musicAdapter = adapter
        musicRefresh()
        musicGen++; val g = musicGen
        h.postDelayed({ musicTick(g) }, 100)

        return if (land) {
            LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(scroll(top), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
                addView(lv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { leftMargin = dp(10) })
            }
        } else {
            LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                addView(lv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(6) })
            }
        }
    }

    // ---------------- floating apps ----------------
    private fun iconFor(n: String) = when { n.contains("WhatsApp") -> "💬"; n.contains("YouTube") -> "▶"; n.contains("Insta") -> "📷"; else -> "🔎" }

    private fun tile(name: String, color: Int, url: String, desktop: Boolean) = TextView(this).apply {
        text = iconFor(name) + "  " + name; textSize = 15f; typeface = Util.BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = Util.round(this@OverlayService, color, 18, Util.alpha(Color.WHITE, 0x33)); setPadding(0, dp(22), 0, dp(22))
        layoutParams = wlp(); setOnClickListener { openApp(url, desktop) }
    }

    private fun realTile(name: String, color: Int, pkg: String, fallbackUrl: String, desktop: Boolean) = TextView(this).apply {
        text = iconFor(name) + "  " + name; textSize = 15f; typeface = Util.BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = Util.round(this@OverlayService, color, 18, Util.alpha(Color.WHITE, 0x33)); setPadding(0, dp(22), 0, dp(22))
        layoutParams = wlp(); setOnClickListener { launchReal(pkg, name, fallbackUrl, desktop) }
    }

    private fun launchReal(pkg: String, name: String, fallbackUrl: String, desktop: Boolean) {
        if (Util.pref(this).getBoolean("glock", false)) {
            banner("GAME LOCK is ON", "Opening $name in the floating window instead", Util.ORANGE)
            openApp(fallbackUrl, desktop); return
        }
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) {
            banner("$name app not installed", "Opening the floating web version", Util.ORANGE)
            openApp(fallbackUrl, desktop); return
        }
        closePanel()
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { banner("Could not open $name", "Open it from your home screen", Util.RED) }
    }

    private fun appsTab(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(section("YOUR PHONE APPS"))
        col.addView(label("Opens the real app installed on your phone (your chats and login are already there). The game goes to the background, so come back from Recent apps."))
        col.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL
            addView(realTile("WhatsApp", Color.parseColor("#2E7D32"), "com.whatsapp", "https://web.whatsapp.com", true))
            addView(realTile("YouTube", Color.parseColor("#C62828"), "com.google.android.youtube", "https://m.youtube.com", false)) })
        col.addView(section("FLOATING WINDOW  (over the game)"))
        col.addView(label("Window above the game. Drag the top bar to move, DRAG the ◢ strip at the bottom to resize it to ANY size you like (size is remembered), ⤢ = quick sizes, ⌨ = keyboard, red X = close."))
        col.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL
            addView(tile("YouTube", Color.parseColor("#C62828"), "https://m.youtube.com", false))
            addView(tile("Google", Util.BLUE, "https://www.google.com", false)) })
        col.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL
            addView(tile("WhatsApp Web", Color.parseColor("#2E7D32"), "https://web.whatsapp.com", true))
            addView(tile("Instagram", Color.parseColor("#AD1457"), "https://www.instagram.com", false)) })
        col.addView(label("WhatsApp Web: on the login screen choose \"Link with phone number\" (you cannot scan a QR on the same phone). Login is remembered. Google sign-in may be blocked in embedded windows.", 10f))
        return scroll(col)
    }

    private fun openApp(url: String, desktop: Boolean) {
        closeApp(); closePanel()
        val c = this
        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(1), dp(1), dp(1), dp(1))
            background = Util.round(c, Color.parseColor("#101018"), 14, Util.alpha(Util.ACC, 0x99)) }
        val bar = FrameLayout(c).apply { setBackgroundColor(Util.CARD) }
        bar.addView(View(c).apply { background = Util.round(c, Color.parseColor("#77FFFFFF"), 3); layoutParams = FrameLayout.LayoutParams(dp(64), dp(6), Gravity.CENTER) })
        bar.addView(TextView(c).apply {
            text = "⌨"; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END).apply { rightMargin = dp(80) }
            setOnClickListener {
                // move the window to the top and open the keyboard
                val wv = appWeb ?: return@setOnClickListener; val l = appLp ?: return@setOnClickListener; val win = appWin ?: return@setOnClickListener
                l.y = dp(4); try { wm.updateViewLayout(win, l) } catch (e: Exception) {}
                setAppFocusable(true); wv.requestFocus()
                wv.postDelayed({ (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(wv, InputMethodManager.SHOW_IMPLICIT) }, 200)
            } })
        bar.addView(TextView(c).apply {
            text = "⤢"; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END).apply { rightMargin = dp(40) }
            setOnClickListener { sizeIdx = (sizeIdx + 1) % sizes.size; winW = sizes[sizeIdx].first; winH = sizes[sizeIdx].second; saveWin(); applySize() } })
        bar.addView(TextView(c).apply {
            text = "✕"; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER; setBackgroundColor(Color.parseColor("#D32F2F"))
            layoutParams = FrameLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END)
            setOnClickListener { closeApp() } })
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))
        val keep = url.contains("whatsapp")
        appKeep = keep
        // WhatsApp Web stays loaded when you close the window, so your pairing code / chats are not reset
        val w = if (keep) webCache.getOrPut(url) { makeWeb(url, desktop) } else makeWeb(url, desktop)
        (w.parent as? ViewGroup)?.removeView(w)
        root.addView(w, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val grip = FrameLayout(c).apply { setBackgroundColor(Util.CARD) }
        grip.addView(TextView(c).apply {
            text = "drag here to resize   ◢"; setTextColor(Util.ACC); textSize = 11f; gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setPadding(0, 0, dp(12), 0)
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT) })
        root.addView(grip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(30)))
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams((dm.widthPixels * winW).toInt().coerceIn(dp(180), dm.widthPixels), (dm.heightPixels * winH).toInt().coerceIn(dp(160), dm.heightPixels), type(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = dp(12); lp.y = dp(90)
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        bar.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; true }
                MotionEvent.ACTION_MOVE -> { lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt(); clampPos(lp); wm.updateViewLayout(root, lp); true }
                else -> false
            }
        }
        var rw = 0; var rh = 0; var rx = 0f; var ry = 0f
        grip.setOnTouchListener { _, e ->
            val d = resources.displayMetrics
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { rw = lp.width; rh = lp.height; rx = e.rawX; ry = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    lp.width = (rw + (e.rawX - rx).toInt()).coerceIn(dp(180), d.widthPixels)
                    lp.height = (rh + (e.rawY - ry).toInt()).coerceIn(dp(160), d.heightPixels)
                    clampPos(lp)
                    winW = lp.width.toFloat() / d.widthPixels; winH = lp.height.toFloat() / d.heightPixels
                    try { wm.updateViewLayout(root, lp) } catch (x: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> { saveWin(); appWeb?.evaluateJavascript("window.dispatchEvent(new Event('resize'))", null); true }
                else -> false
            }
        }
        root.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) { webTyping = false; setAppFocusable(false) }; false }
        wm.addView(root, lp); appWin = root; appLp = lp; appWeb = w
    }

    private val webCache = HashMap<String, WebView>()
    private var appKeep = false
    private var webTyping = false
    private val focusJs = "(function(){if(window.__pgb)return;window.__pgb=1;" +
        "function t(e){if(!e)return false;var n=e.tagName;" +
        "if(n==='INPUT')return !/^(button|checkbox|radio|submit|reset|image|range|file|color)$/.test(e.type);" +
        "return n==='TEXTAREA'||e.isContentEditable===true;}" +
        "document.addEventListener('focusin',function(e){if(t(e.target))PGB.focus(true)},true);" +
        "document.addEventListener('focusout',function(e){if(t(e.target))PGB.focus(false)},true);})();"

    private inner class WebBridge {
        @JavascriptInterface
        fun focus(on: Boolean) {
            h.post {
                webTyping = on
                if (on) {
                    setAppFocusable(true)
                    appWeb?.let { wv ->
                        wv.requestFocus()
                        wv.postDelayed({ (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(wv, InputMethodManager.SHOW_IMPLICIT) }, 150)
                    }
                } else h.postDelayed({ if (!webTyping) setAppFocusable(false) }, 300)
            }
        }
    }

    private fun makeWeb(url: String, desktop: Boolean): WebView = object : WebView(this) {
        // no full-screen keyboard in landscape, so you can see the chat while typing
        override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
            val ic = super.onCreateInputConnection(outAttrs)
            outAttrs.imeOptions = outAttrs.imeOptions or EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_FLAG_NO_FULLSCREEN
            return ic
        }
    }.apply {
        isFocusable = true; isFocusableInTouchMode = true
        settings.javaScriptEnabled = true; settings.domStorageEnabled = true
        settings.databaseEnabled = true; settings.javaScriptCanOpenWindowsAutomatically = true
        settings.setSupportZoom(true); settings.builtInZoomControls = true; settings.displayZoomControls = false
        settings.mediaPlaybackRequiresUserGesture = false
        if (desktop) { settings.userAgentString = desktopUA; settings.useWideViewPort = true; settings.loadWithOverviewMode = true }
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
        addJavascriptInterface(WebBridge(), "PGB")
        webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, u: String?) { view?.evaluateJavascript(focusJs, null) }
        }
        webChromeClient = WebChromeClient()
        loadUrl(url)
    }

    /** The floating window only takes keyboard focus while you use it. Tap outside it and the app underneath (real WhatsApp, game) gets the keyboard back. */
    private fun setAppFocusable(on: Boolean) {
        val lp = appLp ?: return; val v = appWin ?: return
        val nf = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        if (((lp.flags and nf) == 0) == on) return
        lp.flags = if (on) lp.flags and nf.inv() else lp.flags or nf
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
    }

    private fun saveWin() { Util.pref(this).edit().putFloat("ww", winW).putFloat("wh", winH).apply() }

    /** keep the floating window fully reachable on screen (also after rotation) */
    private fun clampPos(lp: WindowManager.LayoutParams) {
        val dm = resources.displayMetrics
        lp.x = lp.x.coerceIn(0, (dm.widthPixels - lp.width).coerceAtLeast(0))
        lp.y = lp.y.coerceIn(0, (dm.heightPixels - lp.height).coerceAtLeast(0))
    }

    private fun applySize() {
        val lp = appLp ?: return; val v = appWin ?: return
        val dm = resources.displayMetrics
        lp.width = (dm.widthPixels * winW).toInt().coerceIn(dp(180), dm.widthPixels)
        lp.height = (dm.heightPixels * winH).toInt().coerceIn(dp(160), dm.heightPixels)
        clampPos(lp)
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
        appWeb?.evaluateJavascript("window.dispatchEvent(new Event('resize'))", null)
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        h.postDelayed({ applySize(); clearLock(); syncLock() }, 300)
    }

    // ---------------- game lock ----------------
    private fun onLockToggled() {
        val on = Util.pref(this).getBoolean("glock", false)
        if (on) {
            bounceCount = 0
            lockArmed = inGameNow
            if (!Util.hasUsage(this)) banner("GAME LOCK needs Usage Access", "Grant it in the main app, then lock works fully", Util.ORANGE)
            else banner("GAME LOCK ON", "Back / Home / Recents are locked", Util.GREEN)
            syncLock()
        } else { lockArmed = lockOn() && inGameNow; if (!lockOn()) clearLock(); banner("GAME LOCK OFF", "Phone buttons work normally", Util.ORANGE) }
    }

    private fun clearLock() {
        lockViews.forEach { try { wm.removeView(it) } catch (e: Exception) {} }
        lockViews.clear()
    }

    private fun navInsets(): IntArray {
        if (Build.VERSION.SDK_INT >= 30) {
            val i = wm.currentWindowMetrics.windowInsets.getInsetsIgnoringVisibility(WindowInsets.Type.navigationBars())
            return intArrayOf(i.left, i.right, i.bottom)
        }
        val id = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return intArrayOf(0, 0, if (id > 0) resources.getDimensionPixelSize(id) else dp(48))
    }

    private fun gestureNav() = try { Settings.Secure.getInt(contentResolver, "navigation_mode", 0) == 2 } catch (e: Exception) { false }

    /** Blocks touches on the 3-button navigation bar area while the game is in front and Game Lock is ON. */
    private fun syncLock() {
        val want = lockOn() && inGameNow
        if (!want) { clearLock(); return }
        if (lockViews.isNotEmpty()) return
        fun strip(w: Int, hh: Int, g: Int) {
            if (w == 0 || hh == 0) return
            val v = View(this).apply { setOnTouchListener { _, _ -> true } }
            val lp = WindowManager.LayoutParams(w, hh, type(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSPARENT)
            lp.gravity = g
            try { wm.addView(v, lp); lockViews.add(v) } catch (e: Exception) {}
        }
        if (!gestureNav()) {
            val n = navInsets()
            strip(ViewGroup.LayoutParams.MATCH_PARENT, n[2], Gravity.BOTTOM)
            strip(n[0], ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START)
            strip(n[1], ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END)
        }
        // ESPORTS: thin strip on the top edge so a pull-down for the status bar / clock is caught
        if (esportsActive()) strip(ViewGroup.LayoutParams.MATCH_PARENT, dp(10), Gravity.TOP)
    }

    /** If the person still leaves the game (gesture navigation, call, etc.) bring it straight back. */
    private fun lockWatch(fg: String?) {
        if (!lockOn()) { lockArmed = false; return }
        val now = System.currentTimeMillis()
        if (Util.isGame(fg)) {
            lastGamePkg = fg
            lockArmed = true
            if (inGameSince == 0L) inGameSince = now
            if (now - inGameSince > 10000L) bounceCount = 0
            return
        }
        inGameSince = 0L
        if (!lockArmed || fg == null || fg == packageName || fg in lockOkPkgs || now - lastBounce < 1200L) return
        lastBounce = now; bounceCount++
        if (bounceCount > 3) {
            // the game keeps closing right away (you quit it on purpose) -> release the lock
            Util.pref(this).edit().putBoolean("glock", false).apply(); lockArmed = false; bounceCount = 0; clearLock()
            if (Modes.get(this) == Modes.ESPORTS) Modes.set(this, 1)
            banner("GAME LOCK OFF", "Game was closed, lock released", Util.ORANGE); return
        }
        Util.launchGame(this, lastGamePkg)
    }

    private fun closeApp() {
        appWin?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        CookieManager.getInstance().flush()
        if (appKeep) (appWeb?.parent as? ViewGroup)?.removeView(appWeb) else appWeb?.destroy()
        appWeb = null; appWin = null; appLp = null
    }

    // ---------------- live stats ----------------
    private fun refreshStats() {
        val t = Util.temp(this); val ram = Util.ramPercent(this)
        val fps = meter.fps; val bat = Util.battery(this)
        val maxHz = Util.displayHz(this)
        val tc = if (t >= 42) Util.RED else if (t >= 38) Util.ORANGE else Util.GREEN

        gFps?.set(if (fps <= 0) -1 else (fps * 100 / maxHz).coerceAtMost(100), if (fps <= 0) "--" else "$fps", Util.ACC)
        gBat?.set(bat, "$bat", if (bat < 20) Util.RED else Util.GREEN)
        val nc = if (ping < 0) Util.MUTED else if (ping < 60) Util.GREEN else if (ping < 120) Util.ORANGE else Util.RED
        gNet?.set(if (ping < 0) -1 else (100 - ping / 2).toInt().coerceIn(5, 100), if (ping < 0) "--" else "$ping", nc)

        if (bCpu != null) {
            val cpu = SysInfo.cpuLoad(); val gpu = SysInfo.gpuLoad()
            bCpu?.set(cpu, if (cpu < 0) "--" else "$cpu%", Util.loadColor(cpu))
            bGpu?.set(gpu, if (gpu < 0) "--" else "$gpu%", Util.loadColor(gpu))
            bRam?.set(ram, "$ram%", Util.loadColor(ram))
            bTemp?.set(((t - 25f) / 25f * 100).toInt().coerceIn(0, 100), "%.0f°C".format(t), tc)
            vStatus?.text = "Thermal ${SysInfo.thermal(this)}" + (if (t >= 42) "   |   Phone is hot, take a short break." else "")
        }
        vHeadTemp?.let { it.text = "%.0f°C".format(t); it.setTextColor(tc) }
        hud?.text = (if (fps <= 0) "--" else "$fps") + " Hz    " + (if (ping < 0) "--" else "$ping") + " ms    %.0f°C".format(t)
        handle?.let { it.heat = if (t >= 42) Util.RED else Util.ACC; it.invalidate() }
    }

    private fun applyVisibility() {
        handle?.visibility = if (gameVisible) View.VISIBLE else View.GONE
        if (!gameVisible) { closePanel(); hideRail(false) }
        syncHud()
    }

    private fun tick() {
        if (!alive) return
        tickN++
        if (tickN % 3 == 0) Util.ping { ping = it }

        // show only while one of your added apps (or this app) is in front. Needs Usage Access; otherwise always visible.
        val fg = Util.foreground(this)
        fgKnown = fg != null
        if (fg != null) {
            val vis = Util.isGame(fg) || fg == packageName
            val inGame = Util.isGame(fg)
            inGameNow = inGame
            if (vis != gameVisible) { gameVisible = vis; applyVisibility() }
            if (inGame && !wasInGame && Util.pref(this).getBoolean("auto", true)) doBoost(false)
            if (inGame && !wasInGame && lockOn()) banner("GAME LOCK ON", "Back / Home / Recents are locked", Util.GREEN)
            if (inGame && !wasInGame) showRail()   // show the side options for 5 s when the game opens
            wasInGame = inGame; inGameNow = inGame
            lockWatch(fg); syncLock(); applyEsports()
        } else if (!gameVisible) { gameVisible = true; applyVisibility() }

        syncRail()
        refreshStats()
        syncTop()
        val mode = Modes.get(this); val now = System.currentTimeMillis(); val sec = Modes.autoSec(mode)
        if (sec > 0 && now - lastAuto > sec * 1000L) { lastAuto = now; Util.clean(this) }
        if (mode >= 3 && Util.temp(this) >= 43f && now - lastHeat > 120000L) {
            lastHeat = now; banner("HIGH TEMPERATURE", "Take a short break and remove the phone case", Util.RED)
        }
        h.postDelayed({ tick() }, if (lockArmed) 700L else if (panel != null || hud != null) 1000L else 2500L)
    }

    override fun onDestroy() {
        alive = false; running = false; refreshTheme = null; meter.stop(); h.removeCallbacksAndMessages(null)
        Music.stop(); musicGen++
        hideRail(false); ModeFx.dismiss(); removeTop(); hideClock(false); clearLock(); closePanel(false); closeApp(); webCache.values.forEach { it.destroy() }; webCache.clear()
        bannerView?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        hud?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        handle?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        handle = null; hud = null; super.onDestroy()
    }
}
