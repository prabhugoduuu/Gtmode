package com.prabhu.gamebooster

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin

/**
 * Live-drawn fire phoenix intro (about 6.6 s), no image/video files:
 *  0-1.5 s  phoenix with huge wings spread, flapping, tail feathers hanging
 *  1.2-3.6  banks away, shrinks, spiral spark ring orbits it
 *  2.8-4.7  fire clouds rush in from both sides
 *  4.1-5.4  particle explosion from the centre
 *  4.7-6.6  white flash, small golden phoenix, then the overlay fades out
 */
class PhoenixView(c: Context) : View(c) {
    companion object { const val DUR = 6.6f }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val add = PorterDuffXfermode(PorterDuff.Mode.ADD)
    private val gYel = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gRed = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f

    private val rnd = java.util.Random(5)
    private val NB = 480
    private val bA = FloatArray(NB) { rnd.nextFloat() * 6.2832f }
    private val bS = FloatArray(NB) { 0.25f + rnd.nextFloat() * 1.1f }
    private val bZ = FloatArray(NB) { 1f + rnd.nextFloat() * 4f }
    private val bD = FloatArray(NB) { rnd.nextFloat() * 0.35f }
    private val NA = 150
    private val aX = FloatArray(NA) { rnd.nextFloat() }
    private val aY = FloatArray(NA) { rnd.nextFloat() }
    private val aV = FloatArray(NA) { 0.03f + rnd.nextFloat() * 0.09f }
    private val aP = FloatArray(NA) { rnd.nextFloat() * 6.28f }
    private val aZ = FloatArray(NA) { 0.8f + rnd.nextFloat() * 2.2f }
    private val NF = 44
    private val fY = FloatArray(NF) { rnd.nextFloat() * 2f - 1f }
    private val fR = FloatArray(NF) { 0.5f + rnd.nextFloat() * 0.8f }
    private val fP = FloatArray(NF) { rnd.nextFloat() * 6.28f }

    init {
        gYel.shader = RadialGradient(0f, 0f, 1f, intArrayOf(Color.parseColor("#FFFFEDA8"), Color.parseColor("#90FFA010"), Color.parseColor("#00FF4000")),
            floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP)
        gRed.shader = RadialGradient(0f, 0f, 1f, intArrayOf(Color.parseColor("#FFFF8A20"), Color.parseColor("#80D02000"), Color.parseColor("#00600000")),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        gYel.xfermode = add; gRed.xfermode = add
    }

    fun update(sec: Float) { t = sec; invalidate() }

    private fun ss(a: Float, b: Float, x: Float): Float { val k = ((x - a) / (b - a)).coerceIn(0f, 1f); return k * k * (3f - 2f * k) }
    private fun lerp(a: Float, b: Float, k: Float) = a + (b - a) * k

    private fun blob(cv: Canvas, g: Paint, x: Float, y: Float, r: Float, a: Float) {
        if (a <= 0f || r <= 0f) return
        g.alpha = (a * 255f).toInt().coerceIn(0, 255)
        cv.save(); cv.translate(x, y); cv.scale(r, r); cv.drawCircle(0f, 0f, 1f, g); cv.restore()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val d = Util.dp(context, 1).toFloat()
        val m = maxOf(w, h)
        cv.drawColor(Color.parseColor("#030100"))

        // ---- phoenix pose ----
        val shrink = ss(0.9f, 3.4f, t)
        val span = w * (0.50f - 0.39f * shrink)
        val cx = w * 0.5f + sin(t * 1.7f) * w * 0.02f * shrink
        val cy = lerp(h * 0.58f, h * 0.5f, shrink)
        val bank = -55f * ss(1.2f, 2.6f, t) + 6f * sin(t * 2.4f)
        val xs = 1f - 0.28f * ss(1.2f, 2.2f, t) * (0.5f + 0.5f * cos(t * 2.6f))
        val flap = sin(t * 6.2f) * (0.95f - 0.45f * ss(2f, 4f, t))

        // soft glow behind
        val bg = ss(0f, 0.6f, t) * (1f - ss(3.8f, 4.6f, t))
        blob(cv, gRed, cx, cy, m * (0.55f - 0.3f * shrink), 0.55f * bg)

        // ambient sparks
        for (i in 0 until NA) {
            val x = aX[i] * w + sin(t * 1.3f + aP[i]) * d * 12f
            var y = (aY[i] - t * aV[i]) % 1f; if (y < 0f) y += 1f
            val tw = 0.5f + 0.5f * sin(t * 6f + aP[i])
            blob(cv, gYel, x, y * h, aZ[i] * d * 2.2f, 0.75f * tw)
        }

        // phoenix (front) - gets dimmer as the fire swallows it
        val pa = 1f - 0.7f * ss(3.4f, 4.4f, t)
        if (t < 5.0f) drawPhoenix(cv, cx, cy, span, bank, xs, flap, pa, false)

        // spiral spark ring (3 comets)
        val ra = ss(1.0f, 1.6f, t) * (1f - ss(3.7f, 4.3f, t))
        if (ra > 0f) {
            val a = w * (0.46f - 0.33f * ss(1.1f, 3.2f, t)); val b = a * 0.42f
            cv.save(); cv.translate(cx, cy); cv.rotate(-14f)
            p.style = Paint.Style.STROKE; p.strokeWidth = d * 1.2f; p.shader = null; p.xfermode = add
            p.color = Color.argb((90 * ra).toInt(), 255, 170, 40)
            cv.drawOval(RectF(-a, -b, a, b), p)
            p.xfermode = null; p.style = Paint.Style.FILL
            for (k in 0..2) {
                val head = t * 5.2f + k * 2.094f
                for (j in 0 until 46) {
                    val ang = head - j * 0.05f
                    val f = 1f - j / 46f
                    blob(cv, gYel, a * cos(ang), b * sin(ang), (2f + 5f * f) * d * (1f + 0.4f * sin(j * 0.9f + t * 12f)), ra * f)
                }
            }
            cv.restore()
        }

        // fire clouds from both sides
        val fa = ss(2.8f, 3.4f, t) * (1f - ss(4.4f, 5.0f, t))
        if (fa > 0f) {
            for (i in 0 until NF) {
                val side = if (i % 2 == 0) -1f else 1f
                val prog = ss(2.8f + (i % 7) * 0.035f, 4.2f, t)
                val x = w * 0.5f + side * w * 0.62f * (1f - prog * 0.8f)
                val y = h * 0.5f + fY[i] * h * 0.42f + sin(t * 3f + fP[i]) * h * 0.02f
                val r = h * (0.16f + 0.17f * fR[i]) * (0.6f + 0.4f * prog)
                blob(cv, gRed, x, y, r, 0.85f * fa)
                blob(cv, gYel, x + side * -r * 0.15f, y, r * 0.55f, 0.7f * fa)
            }
        }

        // explosion particles + core
        val tau = t - 4.2f
        if (tau > 0f) {
            for (i in 0 until NB) {
                val ti = tau - bD[i]
                if (ti <= 0f) continue
                val dist = m * bS[i] * 0.6f * (1f - exp(-2.4f * ti))
                val al = 1f - ss(0.6f, 1.4f, ti)
                if (al <= 0f) continue
                blob(cv, gYel, cx + cos(bA[i]) * dist, cy + sin(bA[i]) * dist * 0.8f, bZ[i] * d * 2.2f, al)
            }
            blob(cv, gYel, cx, cy, m * (0.08f + 0.6f * ss(4.2f, 5.1f, t)), 0.95f * ss(4.2f, 4.7f, t))
        }

        // white flash
        val wa = ss(4.7f, 5.4f, t)
        if (wa > 0f) { p.style = Paint.Style.FILL; p.shader = null; p.xfermode = null; p.color = Color.argb((255 * wa).toInt(), 255, 251, 240); cv.drawRect(0f, 0f, w, h, p) }

        // small golden phoenix on white
        val fa2 = ss(5.0f, 5.6f, t)
        if (fa2 > 0f) drawPhoenix(cv, w * 0.5f, h * 0.5f, w * 0.085f, 0f, 1f, sin(t * 5f) * 0.5f, fa2, true)
    }

    // ------------------------------------------------------------------ phoenix model (unit = wing half-span)

    private fun feather(cv: Canvas, rx: Float, ry: Float, ang: Float, len: Float, wid: Float, curve: Float, a: Float, c0: Int, c1: Int, c2: Int) {
        val dx = cos(ang); val dy = -sin(ang)
        val nx = -dy; val ny = dx
        val tx = rx + dx * len + nx * curve * len * 0.35f; val ty = ry + dy * len + ny * curve * len * 0.35f
        val mx = rx + dx * len * 0.5f + nx * curve * len * 0.12f; val my = ry + dy * len * 0.5f + ny * curve * len * 0.12f
        path.reset(); path.moveTo(rx, ry)
        path.quadTo(mx + nx * wid, my + ny * wid, tx, ty)
        path.quadTo(mx - nx * wid, my - ny * wid, rx, ry); path.close()
        // glow outline
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = 0.05f; p.color = Color.argb((0x40 * a).toInt(), 255, 150, 20)
        cv.drawPath(path, p)
        // body
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(rx, ry, tx, ty, intArrayOf(c0, c1, c2), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        p.alpha = (255 * a).toInt().coerceIn(0, 255)
        cv.drawPath(path, p)
        // bright vein
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = 0.008f; p.color = Color.argb((0xB0 * a).toInt(), 255, 250, 200)
        cv.drawLine(rx, ry, mx, my, p)
        p.style = Paint.Style.FILL
    }

    private fun wing(cv: Canvas, flap: Float, a: Float, deep: Boolean) {
        val sx = 0.07f; val sy = -0.02f
        val lead = Math.toRadians((30.0 + 38.0 * flap)).toFloat()
        val trail = Math.toRadians((-62.0 + 28.0 * flap)).toFloat()
        val hi = if (deep) Color.parseColor("#FFD84A") else Color.parseColor("#FFF6B8")
        val mid = if (deep) Color.parseColor("#FFA800") else Color.parseColor("#FFC21A")
        val tip = if (deep) Color.parseColor("#FF6A00") else Color.parseColor("#FF5410")
        // back row (shorter, darker)
        for (k in 0 until 10) {
            val u = k / 9f
            feather(cv, sx, sy, lerp(lead - 0.05f, trail + 0.1f, u.pow(0.9f)), 0.62f * (1f - 0.4f * u.pow(1.4f)) + 0.05f, 0.07f,
                lerp(-0.2f, 0.3f, u), a * 0.9f, Color.parseColor("#FFB020"), Color.parseColor("#F07000"), Color.parseColor("#B02800"))
        }
        // primary feathers
        for (k in 11 downTo 0) {
            val u = k / 11f
            var len = 1.0f - 0.45f * u.pow(1.5f); if (k == 0) len = 0.9f
            feather(cv, sx, sy, lerp(lead, trail, u.pow(0.9f)), len, 0.085f * (1f - 0.3f * u), lerp(-0.25f, 0.35f, u), a, hi, mid, tip)
        }
    }

    private fun drawPhoenix(cv: Canvas, cx: Float, cy: Float, span: Float, rot: Float, xs: Float, flap: Float, a: Float, deep: Boolean) {
        if (a <= 0f || span <= 0f) return
        val hi = if (deep) Color.parseColor("#FFD84A") else Color.parseColor("#FFF6B8")
        val mid = if (deep) Color.parseColor("#FFA800") else Color.parseColor("#FFC21A")
        val tip = if (deep) Color.parseColor("#FF6A00") else Color.parseColor("#FF5410")
        cv.save(); cv.translate(cx, cy); cv.rotate(rot); cv.scale(xs * span, span)
        p.xfermode = null
        // tail feathers (hang down)
        for (k in 0..6) {
            val ang = Math.toRadians(-90.0 + (k - 3) * 13.0 + sin(t * 3f + k) * 3.0).toFloat()
            feather(cv, 0f, 0.26f, ang, 1.02f * (1f - 0.12f * abs(k - 3)), 0.075f, (k - 3) * 0.08f, a, hi, mid, tip)
        }
        // wings
        wing(cv, flap, a, deep)
        cv.save(); cv.scale(-1f, 1f); wing(cv, flap, a, deep); cv.restore()
        // body
        p.shader = LinearGradient(0f, -0.2f, 0f, 0.4f, hi, mid, Shader.TileMode.CLAMP); p.style = Paint.Style.FILL; p.alpha = (255 * a).toInt().coerceIn(0, 255)
        cv.drawOval(RectF(-0.085f, -0.12f, 0.085f, 0.38f), p)
        // crest plumes
        for (k in -1..1) feather(cv, 0f, -0.2f, Math.toRadians(90.0 + k * 24.0).toFloat(), 0.24f, 0.028f, k * 0.3f, a, hi, mid, tip)
        // head, beak, eyes
        p.shader = LinearGradient(0f, -0.25f, 0f, -0.08f, hi, mid, Shader.TileMode.CLAMP); p.alpha = (255 * a).toInt().coerceIn(0, 255)
        cv.drawCircle(0f, -0.15f, 0.058f, p)
        p.shader = null; p.color = Color.argb((255 * a).toInt(), 255, 110, 20)
        path.reset(); path.moveTo(-0.024f, -0.11f); path.lineTo(0.024f, -0.11f); path.lineTo(0f, -0.045f); path.close(); cv.drawPath(path, p)
        p.color = Color.argb((255 * a).toInt(), 255, 255, 255)
        cv.drawCircle(-0.026f, -0.165f, 0.011f, p); cv.drawCircle(0.026f, -0.165f, 0.011f, p)
        cv.restore()
        p.shader = null
    }
}
