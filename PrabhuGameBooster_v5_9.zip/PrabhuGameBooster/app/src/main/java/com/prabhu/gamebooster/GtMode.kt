package com.prabhu.gamebooster

import android.content.Context
import android.graphics.*
import android.view.View

/** "GT MODE ACTIVATED" burst, 2 seconds. Starts from a white flash (end of the phoenix clip). Driven by update(seconds 0..2). */
class GtModeBurst(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var u = 0f
    fun update(sec: Float) { u = sec; invalidate() }

    private fun backOut(x: Float): Float { val t = x.coerceIn(0f, 1f) - 1f; val k = 1.9f; return 1f + t * t * ((k + 1f) * t + k) }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f) return
        val d = Util.dp(context, 1).toFloat()
        val cx = w / 2f; val cy = h * 0.46f
        cv.drawColor(Color.parseColor("#07080B"))
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, maxOf(w, h) * 0.6f, intArrayOf(Util.alpha(Util.ACC, 0x55), Util.alpha(Util.ACC2, 0x18), Color.TRANSPARENT),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, p); p.shader = null

        // sweeping slanted slash
        val sw = ((u - 0.05f) / 0.55f).coerceIn(0f, 1f)
        if (sw > 0f && sw < 1f) {
            p.color = Util.alpha(Util.ACC, (0x66 * (1f - sw)).toInt())
            val x = -w * 0.2f + w * 1.4f * sw
            path.reset(); path.moveTo(x, 0f); path.lineTo(x + w * 0.09f, 0f); path.lineTo(x - w * 0.06f, h); path.lineTo(x - w * 0.15f, h); path.close()
            cv.drawPath(path, p)
        }
        // shockwave rings
        p.style = Paint.Style.STROKE
        for (i in 0..2) {
            val tt = (u / 1.3f - i * 0.16f)
            if (tt <= 0f || tt >= 1f) continue
            p.strokeWidth = d * (6f - 4f * tt); p.color = Util.alpha(Util.ACC, (200 * (1f - tt)).toInt())
            cv.drawCircle(cx, cy, maxOf(w, h) * 0.55f * tt, p)
        }
        p.style = Paint.Style.FILL
        // GT letters
        val sc = backOut(u / 0.5f)
        p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC); p.letterSpacing = 0.1f
        p.textSize = h * 0.42f * sc.coerceAtLeast(0.01f)
        val base = cy + p.textSize * 0.32f
        p.style = Paint.Style.STROKE; p.strokeWidth = d * 10f; p.color = Util.alpha(Util.ACC, 0x40); cv.drawText("GT", cx, base, p)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(cx - w * 0.15f, 0f, cx + w * 0.15f, 0f, Util.ACC, Util.ACC2, Shader.TileMode.CLAMP)
        cv.drawText("GT", cx, base, p); p.shader = null
        // MODE ACTIVATED
        val a2 = ((u - 0.45f) / 0.25f).coerceIn(0f, 1f)
        if (a2 > 0f) {
            p.typeface = Util.HEAD; p.textSize = h * 0.075f; p.letterSpacing = 0.35f; p.color = Color.argb((255 * a2).toInt(), 255, 255, 255)
            cv.drawText("MODE  ACTIVATED", cx, cy + h * 0.30f, p)
            p.typeface = Util.BOLD; p.textSize = h * 0.035f; p.letterSpacing = 0.25f; p.color = Util.alpha(Util.MUTED, (255 * a2).toInt())
            cv.drawText("PRABHU GAME BOOSTER  •  ${Util.GAME_NAME.uppercase()}", cx, cy + h * 0.38f, p)
        }
        // progress bar
        val bw = w * 0.36f; val by = h * 0.90f
        p.letterSpacing = 0f; p.color = Color.parseColor("#262932"); cv.drawRoundRect(cx - bw / 2, by, cx + bw / 2, by + d * 5f, d * 3f, d * 3f, p)
        p.shader = LinearGradient(cx - bw / 2, 0f, cx + bw / 2, 0f, Util.ACC, Util.ACC2, Shader.TileMode.CLAMP)
        cv.drawRoundRect(cx - bw / 2, by, cx - bw / 2 + bw * (u / 2f).coerceIn(0f, 1f), by + d * 5f, d * 3f, d * 3f, p); p.shader = null
        // start: white flash (continues the phoenix clip's white ending) fading into the dark GT scene
        val fl = (1f - u / 0.4f).coerceIn(0f, 1f)
        if (fl > 0f) { p.color = Color.argb((255 * fl).toInt(), 255, 251, 240); cv.drawRect(0f, 0f, w, h, p) }
    }
}
