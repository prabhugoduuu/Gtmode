# Prabhu Game Booster  (GT Mode)  -  Free Fire India + any apps you add

Default app: `com.garena.game.ffi` (Free Fire India). You can add any other installed app/game (see v6.2).

## Build (no PC needed)
1. Upload this whole folder to your GitHub repo (keep `.github/workflows/build.yml`).
2. GitHub > Actions > "Build APK" > Run workflow (or just push).
3. Download the artifact `PrabhuGameBooster-GT` -> `app-debug.apk`.
Uninstall the old version first if install says "app not installed" (different debug signature).

## First run
Open app -> grant: Display over other apps, Usage access (panel shows only inside the game + auto-boost), Do Not Disturb access.
Tap BOOST & PLAY. In game, pull the orange edge handle on the left. Long-press the handle = quick boost.

## v4.1
Panel > APPS: WhatsApp / YouTube buttons now open the real phone apps. Floating WhatsApp Web: choose "Link with phone number" to log in.
Floating WhatsApp: keyboard fixed (tap the chat box, or the ⌨ button on the window bar). Launching Free Fire India (BOOST + PLAY / OPEN GAME) now shows the GT intro animation first.
Floating window no longer steals the keyboard: tap outside it (e.g. on the real WhatsApp code box) and the keyboard works there.

## Power tools (Tools tab / main screen)
- BATTERY SAVER: opens the Battery saver screen. To let the app switch it on by itself, run once on a PC: `adb shell pm grant com.prabhu.gamebooster android.permission.WRITE_SECURE_SETTINGS`
- CHARGE MODE: Do Not Disturb + (Battery saver if granted) + dim black charging screen with %, temperature, watts, time to full. It cannot raise the charger's real speed.
- Floating WhatsApp Web now stays loaded when you close the window (pairing code is not reset). Keyboard goes to the window only while a text box inside it is selected.

## Music (panel > MUSIC)
Plays songs stored on the phone. First time: ALLOW MUSIC ACCESS. Equalizer bars dance with the music; allow Microphone in the main app for real beat-sync (otherwise a simulated dance is shown). Music keeps playing when the panel is closed; STOP in the panel stops it.

## v4.2
- GAME LOCK (panel > main tab, chip "GAME LOCK"): while ON and Free Fire India is in front, taps on the 3-button navigation bar (Back / Home / Recents) are blocked, and if you still leave the game (gesture navigation, etc.) it is brought straight back. Turn it OFF in the panel (orange edge handle) to exit. It releases itself if the game keeps closing (you quit on purpose). Needs Usage Access. Real WhatsApp/YouTube buttons open the floating window instead while the lock is ON.
- Floating window: drag the "◢" strip at the bottom to resize to ANY size; the size is remembered. The window always stays on screen, re-fits after rotation, and the web page re-lays-out to the new size. ⤢ still cycles quick sizes.

## v5.0  "Neon Glass" redesign
- Whole new look: dark glass cards, glowing sweep-gradient gauges, gradient usage bars, bold modern fonts, rounded 3x3 quick-action tiles (main screen) and tile grids in the in-game panel.
- 4 colour themes: NEON (cyan/violet, default), FIRE (orange), VIOLET (purple/pink), LIME (green). Change from the THEME tile / THEME section on the main screen, or Panel > TOOLS > THEME. Applies to the edge handle, panel, gauges, intro and music bars instantly.
- Main screen: hero card with BOOST & PLAY, LIVE STATS, QUICK ACTIONS, PERFORMANCE MODE, SYSTEM, SETUP (status dots), THEME.
- In-game panel: glass rail with accent tabs, live temperature chip in the header, cards for each section, switch-style toggles (AUTO BOOST / MINI HUD / GAME LOCK).

## v5.1
- MODE ENABLED animation: when you pick SMOOTH / BALANCED / PRO / AI / ESPORTS in the panel while playing, a centre-screen animation (rings + icon + "BALANCED MODE ENABLED") plays over the game. It ignores touches, so the game stays playable.
- New 5th mode **ESPORTS** (modes renamed: SMOOTH, BALANCED, PRO, AI, ESPORTS). While Free Fire India is in front: Back/Home/Recents locked (same as Game Lock, auto-ON), the orange edge handle becomes invisible, no banners / mini HUD, a thin top-edge strip catches the status-bar pull-down, DND on, screen awake, auto-clean 45 s.
- ESPORTS hides the status-bar clock only if you run once on a PC: `adb shell pm grant com.prabhu.gamebooster android.permission.WRITE_SECURE_SETTINGS` (clock is restored when you leave the game / change mode).
- Exit ESPORTS: pull the (invisible) left edge where the handle was -> panel -> pick another mode.
- Needs Usage Access, like Game Lock.

## v5.2
- Music > LOOP SONG: the current song repeats until you change/stop it.
- Music > TOP BAR IN GAME (ON/OFF): while a song plays over the game in landscape, a bar slides in at the top centre with dancing bars and the scrolling song name. Touch-through. Hidden in ESPORTS mode. Needs Usage Access (to know the game is in front).
- MAX mode is now **AI** mode (same as PRO + auto-clean every 30 s + overheat alerts). AI tips were removed.

## v5.3
- Music > SONG VOLUME slider: the song has its own volume (saved). The game sound still follows your phone volume buttons, so you can lower the song without touching the game.

## v5.4  "RedMagic Landscape" dashboard
- Main screen is now landscape (sensorLandscape) in RedMagic Game Space style: top bar with live BATTERY / TEMP / RAM / PING chips, left rail (game card, CPU ring + slanted bars, performance modes list), centre hub (rotating rings with live FPS + BOOST & PLAY), right rail (GPU ring + 3x3 quick action tiles).
- Bottom tabs: GAME LOBBY (dashboard) and SUPER BASE (setup permissions, theme, system details).
- New default theme RED (existing saved theme is kept; pick RED from THEME). All features are unchanged; only the style changed. In-game panel is unchanged.

## v6.0  GT animations only
- Phoenix removed completely. Two GT animations remain: (1) when the app opens: "WELCOME TO GT" (about 2.6 s, once per app start); (2) when Free Fire India is launched: "GT MODE ACTIVATING..." then "IMPROVING GAME..." with a progress bar (about 2.8 s), the game opens under it.
- You can delete these old files from the GitHub repo (no longer used): app/src/main/java/com/prabhu/gamebooster/FireSnake.kt, Phoenix.kt and the folder app/src/main/res/raw (intro_phoenix.mp4). Deleting them only makes the APK smaller.

## v6.1
- Voice changer removed (main screen tiles, panel TOOLS section, engine). Everything else unchanged. Microphone permission is kept only for real beat-sync in MUSIC.

## v6.2  Multi-app + custom logos
- GAME LOBBY > top-left app card (icon + name): tap it to open **MY APPS**.
  - Tap an app = select it. BOOST & PLAY, OPEN GAME, auto-boost, in-game panel, Game Lock and ESPORTS then work for that app.
  - **+ ADD APP**: pick any installed app/game from the list (it is selected right away).
  - **EDIT ⋮** on an app: change logo (pick any image from gallery, auto-cropped square), reset to original logo, rename, add to home screen, remove.
- **Add to home screen**: puts a shortcut with your logo + name on the launcher (Android 8+). Tapping it opens the booster and does BOOST & PLAY for that app.
- Limit: Android does not allow an app to change ANOTHER app's real icon. Your logo is shown inside the booster and on the shortcuts the booster creates. Keep the original app icon on the home screen if you don't need the shortcut.
- The orange edge handle / panel now appears inside every added app. Added apps are never killed by RAM clean.

## v6.3  GT Launcher (change ANY app's icon + name)
- New home screen: **GT Launcher** (Lobby tile "GT LAUNCHER" opens it). Shows all your apps in a grid with search.
- **Long-press an app**: change logo (gallery image), reset logo, rename, hide / unhide, add to booster (game) list, app info, uninstall.
- Make it your real home screen: Super Base > SETUP > "Use as home launcher" (or Settings > Apps > Default apps > Home app). Then the new logos/names show on your home screen. Press the ⚡ button in the launcher for the booster dashboard.
- Tapping an app that is in your booster list = RAM clean + GT intro + open. Other apps open normally.
- Not included (yet): multiple home pages, widgets, dock, folders. To go back to your old launcher: Settings > Default apps > Home app.

## v6.4  Home pages + App drawer
- GT Launcher now has two modes: **HOME** (as many pages as you want, swipe left/right, dots at the bottom, dock with 4 apps) and **DRAWER** (all apps + search).
- Open the drawer: swipe UP on the home screen or tap the ▦ button in the dock. Close: ⌄ button, Back, or Home.
- Put important apps on home: open the drawer > long-press an app > **Add to home screen** (goes to the page you are on; a new page is created automatically when full).
- Long-press an app on home: change logo, rename, remove from home, move to previous / next page, add to dock, hide, info, uninstall.
- Long-press empty space on home (or ⋮): add new page, delete this page, wallpaper, booster dashboard.
- First time: page 1 is filled with your booster apps + Game Booster. Change it any way you like.

## v6.5  Bubble launcher + auto-hiding side options
- **GT Launcher bubble layout** (default): round icons with a glowing ring in a honeycomb pattern (every second row shifted half a cell), on the home pages, the dock and the drawer. Switch back any time: ⋮ menu > "Switch to normal grid layout" / "Switch to bubble layout".
- **In-game side options (replaces the always-visible edge handle)**: when your game opens, a column of round option bubbles appears on the left edge: ⚡ Boost now, 🚀 Perform, 🧰 Tools, 🎯 Sensitivity, 🎵 Music, 📺 Apps. Tap one = full panel on that tab. Long-press a bubble = its name.
- After **5 seconds** without touching them the bubbles fade away (touching one restarts the 5 s).
- To bring them back: **swipe in from the left edge 3 times within 3 seconds** (invisible strip, 18 dp wide, centre of the left edge).
- Old behaviours removed: tap on the handle, long-press-to-boost on the handle, dragging the handle.

## v6.6  Shake = flashlight
- Lobby tile **SHAKE TORCH**: tap = ON/OFF. While ON a small silent notification stays (Android needs it to keep listening). It restarts after a phone reboot.
- Shake the phone **twice, hard, within about 1 second** = flashlight toggles (short vibration). Uses the accelerometer + the normal torch, no camera permission.
- It never fires while one of your booster games is in front (so game shaking cannot switch the torch).
- Long-press the tile: sensitivity (Low / Medium / High) and **works with screen off** (keeps the CPU awake, uses more battery). Many phones stop sensors when the screen is off, so turn this ON if you want pocket use.
- Needs Android 6+. Phones with aggressive battery managers (Xiaomi, Oppo, Vivo, Realme...) may kill the service: set Battery > Prabhu Game Booster > "No restrictions" / allow autostart.

## v6.7  Side options: easier to open
- Bring the side options back in any of 3 ways: **tap the left edge 3 times (within 3 s)**, **swipe in from the left edge 3 times**, or pull down the notification and press **Side options**.
- Tap is the reliable one on phones with gesture navigation (they use the very edge of the screen for Back). The invisible strip is now 30 dp wide, 220 dp tall, centred on the left edge.
- The options also show for 5 s right after you start the overlay.
- The notification must be visible: allow notifications for the app. The booster must be started (START OVERLAY tile) and "Display over other apps" must be ON. For the options to show automatically when the game opens, Usage Access must be ON too.

## v6.8  Launcher styles + side options mode
- **Launcher style** (launcher ⋮ menu > "Launcher style", or the lobby tile LAUNCHER STYLE). Tap an option to go to its next choice:
  - Layout: Grid, Honeycomb bubbles, List, Compact (no names), Large icons. Applies to home pages and the drawer.
  - Icon shape: Rounded square, Circle, Squircle, Square, Hexagon.
  - Ring around icons ON/OFF, app names ON/OFF, icon size Small / Medium / Large.
- **SIDE OPTIONS tile** in the lobby: tap to cycle  HIDE IN 5s  ->  HIDE IN 10s  ->  ALWAYS ON.
  - ALWAYS ON: the bubbles stay on the left while your game is in front (they hide while the full panel is open and return after you close it).
  - HIDE IN Ns: they fade out after N seconds; bring them back with 3 taps / 3 swipes on the left edge, or notification > Side options.
  - Changes apply immediately, even while the overlay is running.

## v6.9  Side panel back to the original single tab
- The round option bubbles (v6.5 - v6.8) are **removed**. The overlay is again ONE tab on the left edge: tap it = the full panel with all features (PERFORM, TOOLS, SENSI, MUSIC, APPS). Drag it up/down to move it, long-press = quick boost.
- You choose how the tab behaves: lobby tile **SIDE PANEL**: tap to cycle  HIDES IN 5s -> HIDES IN 10s -> ALWAYS ON.
  - HIDES IN Ns: the tab turns invisible after N seconds without touching it (not while the panel is open). Bring it back: **tap the left edge 3 times** (or swipe in 3 times) within 3 s, or notification button **Show side tab**. It also reappears when your game opens.
  - ALWAYS ON: the tab stays visible.
  - ESPORTS mode keeps its old behaviour (tab invisible, a single tap still opens the panel).
