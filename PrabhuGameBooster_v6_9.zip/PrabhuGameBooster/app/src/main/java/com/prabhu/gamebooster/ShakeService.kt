package com.prabhu.gamebooster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import kotlin.math.sqrt

/**
 * Shake the phone twice = flashlight ON / OFF (like Motorola's chop-chop).
 * Runs as a small foreground service (a notification stays while it is ON). Does nothing while a booster game is in front.
 */
class ShakeService : Service(), SensorEventListener {
    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.prabhu.gamebooster.SHAKE_STOP"
        fun start(c: Context) {
            if (Build.VERSION.SDK_INT < 23) return
            val i = Intent(c, ShakeService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }
        fun stop(c: Context) { c.stopService(Intent(c, ShakeService::class.java)) }
    }

    private var sm: SensorManager? = null
    private var cm: CameraManager? = null
    private var torchId: String? = null
    private var torchOn = false
    private var wl: PowerManager.WakeLock? = null
    private var thresh = 2.7f
    private var lastSpike = 0L
    private var lastToggle = 0L
    private var spikes = 0

    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) { if (cameraId == torchId) torchOn = enabled }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == ACTION_STOP) { Util.pref(this).edit().putBoolean("shake_on", false).apply(); stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT < 23) { stopSelf(); return }
        running = true
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(NotificationChannel("pgb_shake", "Shake flashlight", NotificationManager.IMPORTANCE_MIN))
        }
        val flag = PendingIntent.FLAG_IMMUTABLE
        val stopPi = PendingIntent.getService(this, 11, Intent(this, ShakeService::class.java).setAction(ACTION_STOP), flag)
        val openPi = PendingIntent.getActivity(this, 12, Intent(this, MainActivity::class.java), flag)
        val nb = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "pgb_shake") else Notification.Builder(this)
        val n = nb.setContentTitle("Shake flashlight is ON")
            .setContentText("Shake the phone twice to switch the flashlight")
            .setSmallIcon(android.R.drawable.ic_menu_compass).setContentIntent(openPi)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Turn off", stopPi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(2, n)

        thresh = when (Util.pref(this).getInt("shake_lvl", 1)) { 0 -> 3.4f; 2 -> 2.1f; else -> 2.7f }

        // flashlight
        val m = getSystemService(CAMERA_SERVICE) as CameraManager
        cm = m
        try {
            val ids = m.cameraIdList.filter { m.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            torchId = ids.firstOrNull { m.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK } ?: ids.firstOrNull()
            m.registerTorchCallback(torchCb, null)
        } catch (e: Exception) {}

        // optional: keep the CPU awake so shaking also works with the screen off (uses more battery)
        if (Util.pref(this).getBoolean("shake_wl", false)) {
            try {
                wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "pgb:shake").also { it.acquire() }
            } catch (e: Exception) {}
        }

        val s = getSystemService(SENSOR_SERVICE) as SensorManager
        sm = s
        s.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let { s.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onSensorChanged(e: SensorEvent?) {
        val v = e?.values ?: return
        val g = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]) / SensorManager.GRAVITY_EARTH
        if (g < thresh) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastSpike < 150) return                 // same shake, still one spike
        spikes = if (now - lastSpike < 900) spikes + 1 else 1
        lastSpike = now
        if (spikes >= 2 && now - lastToggle > 1500) {     // two hard shakes within 0.9 s
            spikes = 0; lastToggle = now
            if (!Util.isGame(Util.foreground(this))) toggleTorch()   // never while you are playing
        }
    }

    private fun toggleTorch() {
        val id = torchId ?: return
        try {
            cm?.setTorchMode(id, !torchOn)
            torchOn = !torchOn
            buzz()
        } catch (ex: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        try {
            val vb = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) vb.vibrate(VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE)) else vb.vibrate(70L)
        } catch (ex: Exception) {}
    }

    override fun onDestroy() {
        running = false
        try { sm?.unregisterListener(this) } catch (ex: Exception) {}
        try { if (Build.VERSION.SDK_INT >= 23) cm?.unregisterTorchCallback(torchCb) } catch (ex: Exception) {}
        try { wl?.let { if (it.isHeld) it.release() } } catch (ex: Exception) {}
        super.onDestroy()
    }
}

/** Restarts the shake flashlight after the phone boots (only if it was turned ON). */
class ShakeBoot : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED && Util.pref(c).getBoolean("shake_on", false)) ShakeService.start(c)
    }
}
