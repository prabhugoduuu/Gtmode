package com.prabhu.gamebooster

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.*

/** Landscape "RedMagic Game Space" style dashboard: left rail / centre hub / right rail + bottom tabs. */
class MainActivity : Activity() {
    companion object { private var welcomeShown = false }
    private val h = Handler(Looper.getMainLooper())
    private val meter = FpsMeter()
    private lateinit var hub: HubView
    private lateinit var cpuRing: MiniRing
    private lateinit var gpuRing: MiniRing
    private lateinit var cpuBars: SlantBars
    private lateinit var gpuBars: SlantBars
    private lateinit var chipBat: StatChip
    private lateinit var chipTemp: StatChip
    private lateinit var chipRam: StatChip
    private lateinit var chipNet: StatChip
    private lateinit var bCpu: BarView
    private lateinit var bGpu: BarView
    private lateinit var bRam: BarView
    private lateinit var bTemp: BarView
    private lateinit var info: TextView
    private lateinit var result: TextView
    private lateinit var modeDesc: TextView
    private lateinit var modes: ModeList
    private lateinit var gameSub: TextView
    private lateinit var gameNameTv: TextView
    private lateinit var shakeTile: TileView
    private lateinit var sideTile: TileView
    private lateinit var gameIconBox: FrameLayout
    private lateinit var gameTag: TextView
    private lateinit var ovBtn: TileView
    private lateinit var setupBox: LinearLayout
    private lateinit var lobbyPage: View
    private lateinit var basePage: View
    private lateinit var tabLobby: TextView
    private lateinit var tabBase: TextView
    private var gpuName = "Detecting..."
    private var cpuNm = ""
    @Volatile private var ping = -1L
    private var alive = true

    private fun dp(v: Int) = Util.dp(this, v)
    private fun full() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(2), dp(5), dp(2), dp(5)) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
        background = Util.glass(this@MainActivity, 18)
        layoutParams = full()
    }

    private fun section(t: String) = Util.sectionHeader(this, t)

    private fun gradText(t: TextView) {
        t.post { t.paint.shader = LinearGradient(0f, 0f, t.paint.measureText(t.text.toString()), 0f, Util.ACC, Util.ACC2, Shader.TileMode.CLAMP); t.invalidate() }
    }

    private fun syncOv() { ovBtn.setLabel(if (OverlayService.running) "STOP OVERLAY" else "START OVERLAY"); ovBtn.setOn(OverlayService.running) }

    private fun changeTheme(i: Int) {
        Util.setTheme(this, i)
        OverlayService.refreshTheme?.invoke()
        recreate()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) hideBars() }

    private fun showTab(lobby: Boolean) {
        lobbyPage.visibility = if (lobby) View.VISIBLE else View.GONE
        basePage.visibility = if (lobby) View.GONE else View.VISIBLE
        tabLobby.setTextColor(if (lobby) Util.ACC else Util.MUTED); tabBase.setTextColor(if (lobby) Util.MUTED else Util.ACC)
        tabLobby.background = if (lobby) Util.glassOn(this, 14) else null
        tabBase.background = if (lobby) null else Util.glassOn(this, 14)
    }

    private fun tab(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 11f; typeface = Util.HEAD; letterSpacing = 0.12f; gravity = Gravity.CENTER
        setPadding(dp(26), dp(7), dp(26), dp(7)); setOnClickListener { onClick() } }

    private fun scroll(v: View, w: Float) = ScrollView(this).apply {
        isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER
        addView(v, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w).apply { setMargins(dp(6), 0, dp(6), 0) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Apps.load(this)
        Util.initTheme(this)
        window.statusBarColor = Util.BG; window.navigationBarColor = Util.BG
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        hideBars()

        val frame = FrameLayout(this)
        frame.addView(BgView(this), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(30), dp(8), dp(30), dp(6)) }
        frame.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // ================= TOP BAR =================
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), 0, dp(4), dp(4)) }
        top.addView(TextView(this).apply {
            text = "⚡"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(Util.ON_ACC)
            background = Util.accGrad(this@MainActivity, 12)
            layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(10) } })
        val tt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tt.addView(TextView(this).apply { text = "PRABHU"; textSize = 8.5f; setTextColor(Util.ACC); typeface = Util.BOLD; letterSpacing = 0.45f })
        val gb = TextView(this).apply { text = "GAME BOOSTER"; textSize = 17f; typeface = Util.HEAD; setTextColor(Color.WHITE); letterSpacing = 0.04f }
        gradText(gb); tt.addView(gb)
        top.addView(tt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        chipBat = StatChip(this, "BATTERY"); chipTemp = StatChip(this, "TEMP"); chipRam = StatChip(this, "RAM"); chipNet = StatChip(this, "PING")
        listOf(chipBat, chipTemp, chipRam, chipNet).forEach { top.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(6) }) }
        top.addView(TextView(this).apply {
            text = "v5.4"; textSize = 9f; typeface = Util.BOLD; setTextColor(Util.MUTED); letterSpacing = 0.06f; gravity = Gravity.CENTER
            setPadding(dp(9), dp(9), dp(9), dp(9)); background = Util.glass(this@MainActivity, 11)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(6) } })
        col.addView(top)

        // ================= PAGES =================
        val host = FrameLayout(this)
        col.addView(host, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // ---------- LOBBY: left rail | hub | right rail ----------
        val lobby = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        lobbyPage = lobby
        host.addView(lobby, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // LEFT RAIL: game card, CPU ring, performance modes
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val gc = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(9), dp(10), dp(9))
            background = Util.glassOn(this@MainActivity, 16); layoutParams = full() }
        gameIconBox = FrameLayout(this)
        gc.addView(gameIconBox, LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(10) })
        val gt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        gameNameTv = TextView(this).apply { text = Util.GAME_NAME; textSize = 12.5f; typeface = Util.HEAD; setTextColor(Color.WHITE); maxLines = 1 }
        gt.addView(gameNameTv)
        gameSub = TextView(this).apply { textSize = 9.5f; setTextColor(Util.MUTED); maxLines = 1 }
        gt.addView(gameSub)
        gc.addView(gt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        gameTag = TextView(this).apply { textSize = 8.5f; typeface = Util.BOLD; letterSpacing = 0.06f; setPadding(dp(8), dp(4), dp(8), dp(4)) }
        gc.addView(gameTag)
        gc.setOnClickListener { openApps() }
        gameTag.setOnClickListener { if (!Util.gameInstalled(this)) Util.openStore(this) else openApps() }
        left.addView(gc)

        cpuRing = MiniRing(this, "CPU"); cpuBars = SlantBars(this, false)
        left.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutParams = full()
            addView(cpuBars); addView(cpuRing, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) })

        left.addView(section("PERFORMANCE MODE"))
        modes = ModeList(this, Modes.names, listOf("🍃", "⚖", "🎮", "🤖", "🏆")) { Modes.set(this, it); modeDesc.text = Modes.desc[it] }
        modes.select(Modes.get(this))
        left.addView(modes)
        modeDesc = TextView(this).apply { textSize = 9.5f; setTextColor(Util.MUTED); setPadding(dp(4), dp(4), dp(4), dp(8)); text = Modes.desc[Modes.get(this@MainActivity)] }
        left.addView(modeDesc)
        lobby.addView(scroll(left, 27f))

        // CENTRE: hub + boost button
        val centre = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val hubBox = FrameLayout(this)
        hub = HubView(this)
        hubBox.addView(hub, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        result = TextView(this).apply {
            textSize = 11f; setTextColor(Color.WHITE); visibility = View.GONE; setLineSpacing(0f, 1.15f)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = Util.round(this@MainActivity, Color.parseColor("#F00B1A16"), 16, Util.GREEN)
            setOnClickListener { visibility = View.GONE } }
        hubBox.addView(result, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply { setMargins(dp(6), 0, dp(6), dp(4)) })
        centre.addView(hubBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        centre.addView(Util.primary(this, "BOOST  &  PLAY   ▶") { doBoost(true) }.apply {
            textSize = 14f; setPadding(dp(10), dp(11), dp(10), dp(11))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(24), dp(2), dp(24), dp(4)) } })
        lobby.addView(centre, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 46f))

        // RIGHT RAIL: GPU ring + quick action tiles
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        gpuRing = MiniRing(this, "GPU"); gpuBars = SlantBars(this, true)
        right.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutParams = full()
            addView(gpuRing, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); addView(gpuBars) })
        right.addView(section("QUICK ACTIONS"))
        ovBtn = TileView(this, "🧩", "START OVERLAY", true) { toggleOverlay() }
        shakeTile = TileView(this, "🔦", "SHAKE TORCH: OFF", true) { toggleShake() }
        shakeTile.setOnLongClickListener { shakeOptions(); true }
        sideTile = TileView(this, "🫧", sideLabel(), true) { cycleSide() }
        val styleTile = TileView(this, "🎨", "LAUNCHER STYLE", true) {
            startActivity(Intent(this, LauncherActivity::class.java).putExtra("open_style", true)) }
        val tiles = listOf(
            TileView(this, "🚀", "BOOST NOW", true) { doBoost(false) },
            ovBtn,
            TileView(this, "🎮", "OPEN GAME", true) {
                GtIntro.play(this, { Util.launchGame(this) }) { toast("${Util.GAME_NAME} not installed"); Util.openStore(this) } },
            TileView(this, "📶", "FIX PING (DNS)", true) {
                result.visibility = View.VISIBLE
                result.text = "Set Private DNS to:\ndns.google\nor 1dot1dot1dot1.cloudflare-dns.com"
                startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) },
            TileView(this, "🔋", "BATTERY SAVER", true) {
                if (PowerTools.batterySaver(this)) toast("Battery saver ON") else toast("Switch Battery saver ON here") },
            TileView(this, "🔌", "CHARGE MODE", true) { PowerTools.startCharge(this) },
            TileView(this, "📱", "GT LAUNCHER", true) { startActivity(Intent(this, LauncherActivity::class.java)) },
            shakeTile,
            sideTile,
            styleTile,
            TileView(this, "🎨", "THEME: ${Util.THEMES[Util.themeIdx].name}", true) { changeTheme((Util.themeIdx + 1) % Util.THEMES.size) })
        tiles.chunked(3).forEach { rowTiles ->
            right.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                rowTiles.forEach { t -> addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }) } })
        }
        lobby.addView(scroll(right, 27f))
        if (Build.VERSION.SDK_INT >= 23 && Util.pref(this).getBoolean("shake_on", false) && !ShakeService.running) ShakeService.start(this)
        syncShakeTile()

        // ---------- SUPER BASE: setup | system + theme ----------
        val base = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
        basePage = base
        host.addView(base, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val bl = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        bl.addView(section("SETUP"))
        setupBox = card(); bl.addView(setupBox)
        bl.addView(section("THEME"))
        val tc = card()
        tc.addView(Util.themeRow(this) { changeTheme(it) })
        bl.addView(tc)
        base.addView(scroll(bl, 1f))

        val br = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        br.addView(section("SYSTEM"))
        val sys = card()
        bCpu = BarView(this, "CPU"); bGpu = BarView(this, "GPU"); bRam = BarView(this, "RAM"); bTemp = BarView(this, "TEMP")
        sys.addView(bCpu); sys.addView(bGpu); sys.addView(bRam); sys.addView(bTemp)
        info = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 10f; setTextColor(Color.parseColor("#BFCBE6")); setLineSpacing(0f, 1.25f)
            setPadding(0, dp(10), 0, 0) }
        sys.addView(info)
        br.addView(sys)
        br.addView(TextView(this).apply {
            text = "Frame rate = the screen's real refresh rate measured live (reading the game's own FPS needs root). Boost cleans background apps, turns on Do Not Disturb and keeps the screen awake per mode. It does not overclock the CPU/GPU. Some phones block CPU/GPU load readings; those show \"--\"."
            textSize = 9.5f; setTextColor(Util.MUTED); setPadding(dp(4), dp(10), dp(4), dp(10)) })
        base.addView(scroll(br, 1f))

        // ================= BOTTOM TABS =================
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(2), 0, 0) }
        tabLobby = tab("🏠  GAME LOBBY") { showTab(true) }
        tabBase = tab("🛠  SUPER BASE") { showTab(false) }
        tabs.addView(tabLobby); tabs.addView(tabBase)
        col.addView(tabs)
        showTab(true)

        setContentView(frame)

        // "WELCOME TO GT" animation, once each time the app is opened (not on rotation / theme change)
        if (intent?.getStringExtra("launch_pkg") != null) welcomeShown = true   // shortcut start: skip welcome, game intro plays instead
        if (!welcomeShown) {
            welcomeShown = true
            val wv = GtModeBurst(this, true).apply { setOnTouchListener { _, _ -> true } }
            frame.addView(wv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            ValueAnimator.ofFloat(0f, 2.6f).apply {
                duration = 2600; interpolator = LinearInterpolator()
                addUpdateListener { wv.update(it.animatedValue as Float) }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(a: Animator) { wv.animate().alpha(0f).setDuration(350).withEndAction { frame.removeView(wv) }.start() }
                })
                start()
            }
        }

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        if (intent?.getBooleanExtra("ask_music", false) == true) askMusic()
        if (intent?.getBooleanExtra("pick_music", false) == true) pickSongs()
        Thread { val n = SysInfo.gpuName(); val c = SysInfo.cpuName(); h.post { gpuName = n; cpuNm = c } }.start()
        tick()
        handleLaunch(intent)
    }

    override fun onResume() { super.onResume(); meter.start(); refreshAll() }
    override fun onPause() { meter.stop(); super.onPause() }

    private fun refreshAll() { refreshGame(); refreshSetup(); syncOv() }

    private fun isHome(): Boolean {
        val r = packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
        return r?.activityInfo?.packageName == packageName
    }

    private fun openApps() = AppPicker.manage(this) { Apps.load(this); refreshGame(); refreshSetup() }

    /** Started from a home-screen shortcut made by this app: select that app, then BOOST & PLAY. */
    private fun handleLaunch(i: Intent?) {
        if (i == null) return
        val p = i.getStringExtra("launch_pkg") ?: return
        i.removeExtra("launch_pkg")
        Apps.setActive(this, p)
        refreshGame()
        h.postDelayed({ doBoost(true) }, 400)
    }

    private fun refreshGame() {
        val ok = Util.gameInstalled(this)
        gameNameTv.text = Util.GAME_NAME
        gameIconBox.removeAllViews()
        gameIconBox.addView(AppPicker.iconView(this, Util.GAME_PKG, 40))
        gameSub.text = if (ok) "Tap to change app / logo" else "Not installed  •  tap to change app"
        gameTag.text = if (ok) "● READY" else "INSTALL"
        gameTag.setTextColor(if (ok) Util.GREEN else Util.AMBER)
        gameTag.background = Util.round(this, Util.alpha(if (ok) Util.GREEN else Util.AMBER, 0x22), 10, Util.alpha(if (ok) Util.GREEN else Util.AMBER, 0x66))
    }

    private fun setupRow(title: String, sub: String, ok: Boolean, onClick: () -> Unit): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(7), 0, dp(7)) }
        row.addView(View(this).apply {
            background = Util.round(this@MainActivity, if (ok) Util.GREEN else Util.alpha(Util.MUTED, 0x88), 5)
            layoutParams = LinearLayout.LayoutParams(dp(9), dp(9)).apply { rightMargin = dp(12) } })
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tx.addView(TextView(this).apply { text = title; textSize = 13f; typeface = Util.BOLD; setTextColor(Color.WHITE) })
        tx.addView(TextView(this).apply { text = sub; textSize = 10.5f; setTextColor(Util.MUTED) })
        row.addView(tx, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = if (ok) "✓ ON" else "ENABLE"; textSize = 10.5f; typeface = Util.BOLD; gravity = Gravity.CENTER; letterSpacing = 0.06f
            setTextColor(if (ok) Util.GREEN else Util.ON_ACC); setPadding(dp(14), dp(8), dp(14), dp(8))
            background = if (ok) Util.round(this@MainActivity, Util.alpha(Util.GREEN, 0x22), 12, Util.alpha(Util.GREEN, 0x66)) else Util.accGrad(this@MainActivity, 12)
            setOnClickListener { if (!ok) onClick() } })
        return row
    }

    private fun refreshSetup() {
        val ov = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val dn = Build.VERSION.SDK_INT < 23 || nm.isNotificationPolicyAccessGranted
        setupBox.removeAllViews()
        setupBox.addView(setupRow("Display over other apps", "Required for the in-game GT panel", ov) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) })
        setupBox.addView(setupRow("Usage access", "Shows the panel only inside ${Util.GAME_NAME} / your added apps + auto-boost", Util.hasUsage(this)) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        setupBox.addView(setupRow("Use as home launcher", "Change any app's icon / name from the GT Launcher (like Nova)", isHome()) {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) })
        setupBox.addView(setupRow("Do Not Disturb access", "Silences notifications while gaming", dn) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) })
        setupBox.addView(setupRow("Music files", "Needed for the music player", Music.hasPerm(this)) { askMusic() })
        setupBox.addView(setupRow("Microphone", "Optional: lets the music bars follow the real beat", Util.hasMic(this)) { askMic() })
    }

    private fun askMusic() { if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Music.perm()), 3) }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i); setIntent(i)
        handleLaunch(i)
        if (i?.getBooleanExtra("ask_music", false) == true) askMusic()
        if (i?.getBooleanExtra("pick_music", false) == true) pickSongs()
    }

    private fun pickSongs() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try { startActivityForResult(i, 77) } catch (e: Exception) { toast("No file picker found") }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == AppPicker.REQ_LOGO) {
            val pkg = AppPicker.pendingPkg; val u = data?.data
            if (res == RESULT_OK && pkg != null && u != null) {
                toast(if (Apps.setIconFromUri(this, pkg, u)) "Logo changed" else "Could not read that image")
                Apps.load(this); refreshGame(); AppPicker.refresh?.invoke()
            }
            AppPicker.pendingPkg = null
            return
        }
        if (req != 77 || res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.clipData?.let { cd -> for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri) }
        data.data?.let { if (uris.isEmpty()) uris.add(it) }
        for (u in uris) try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
        Music.addExtras(this, uris)
        toast("${uris.size} song(s) added. Open the MUSIC tab.")
    }

    private fun askMic() { if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2) }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r); refreshSetup()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun tick() {
        if (!alive) return
        val cpu = SysInfo.cpuLoad(); val gpu = SysInfo.gpuLoad(); val ram = Util.ramPercent(this); val t = Util.temp(this)
        val fps = meter.fps; val bat = Util.battery(this); val maxHz = Util.displayHz(this)
        hub.setValue(if (fps <= 0) "--" else "$fps", "FPS", "${maxHz}Hz  •  LIVE")
        chipBat.set("$bat%", if (bat < 20) Util.RED else Util.GREEN)
        chipTemp.set("%.0f°C".format(t), if (t >= 42) Util.RED else if (t >= 38) Util.ORANGE else Util.GREEN)
        chipRam.set("$ram%", Util.loadColor(ram))
        chipNet.set(if (ping < 0) "--" else "${ping}ms", if (ping < 0) Util.MUTED else if (ping < 60) Util.GREEN else if (ping < 120) Util.ORANGE else Util.RED)
        val f = SysInfo.cpuFreq()
        cpuRing.set(cpu, if (f != null) "%.2f".format(f[0] / 1000.0) else if (cpu < 0) "--" else "$cpu", if (f != null) "GHz" else "%",
            Util.loadColor(cpu), if (cpu < 0) cpuNm.take(24) else "LOAD $cpu%  •  ${SysInfo.cores} cores")
        gpuRing.set(gpu, if (gpu < 0) "--" else "$gpu", "%", Util.loadColor(gpu), gpuName.take(24))
        cpuBars.set(cpu, Util.loadColor(cpu)); gpuBars.set(gpu, Util.loadColor(gpu))
        bCpu.set(cpu, if (cpu < 0) "--" else "$cpu%", Util.loadColor(cpu))
        bGpu.set(gpu, if (gpu < 0) "--" else "$gpu%", Util.loadColor(gpu))
        bRam.set(ram, "$ram%", Util.loadColor(ram))
        bTemp.set(((t - 25f) / 25f * 100).toInt().coerceIn(0, 100), "%.0f°C".format(t), if (t >= 42) Util.RED else if (t >= 38) Util.ORANGE else Util.GREEN)
        info.text = "DEVICE   ${Build.MANUFACTURER} ${Build.MODEL}  |  Android ${Build.VERSION.RELEASE}\n" +
            "CPU      ${SysInfo.cpuName()}  |  ${SysInfo.cores} cores" + (if (f != null) "  |  ${f[0]}/${f[1]} MHz" else "") + "\n" +
            "GPU      $gpuName\n" +
            "MEMORY   ${Util.totalRam(this)}\n" +
            "STATUS   Thermal ${SysInfo.thermal(this)}"
        Util.ping { ping = it }
        syncOv()
        h.postDelayed({ tick() }, 2000)
    }

    private fun doBoost(play: Boolean) {
        result.visibility = View.VISIBLE; result.text = "Boosting..."
        val mode = Modes.get(this)
        if (play && !OverlayService.running && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) startOverlay(false)
        Util.boost(this) { freed, avail ->
            val dnd = Modes.dnd(mode) && Util.dnd(this, true)
            val t = Util.temp(this)
            result.text = "GAME BOOSTED  |  ${Modes.names[mode]}\n\n" +
                (if (freed > 0) "RAM freed: $freed MB" else "RAM already clean") +
                "\nFree RAM: $avail MB\nTemperature: %.0f°C".format(t) + (if (dnd) "\nDo Not Disturb: ON" else "") +
                (if (t >= 42) "\nPhone is hot. Take a short break." else "")
            result.alpha = 0f; result.scaleX = 0.92f; result.scaleY = 0.92f
            result.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(300).start()
            if (play) GtIntro.play(this, { Util.launchGame(this) }) { result.append("\n${Util.GAME_NAME} not found on this phone."); Util.openStore(this) }
        }
    }

    private fun sideLabel(): String {
        val sec = Util.pref(this).getInt("rail_sec", 5)
        return if (sec == 0) "SIDE PANEL: ALWAYS ON" else "SIDE PANEL: HIDES IN ${sec}s"
    }

    private fun cycleSide() {
        val p = Util.pref(this)
        val next = when (p.getInt("rail_sec", 5)) { 5 -> 10; 10 -> 0; else -> 5 }
        p.edit().putInt("rail_sec", next).apply()
        sideTile.setLabel(sideLabel())
        toast(if (next == 0) "Side panel tab stays ON while you play" else "Side panel tab hides after $next s. Bring it back: tap the left edge 3 times")
        if (OverlayService.running) startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_SHOW))
    }

    private fun syncShakeTile() {
        val on = Util.pref(this).getBoolean("shake_on", false)
        shakeTile.setLabel(if (on) "SHAKE TORCH: ON" else "SHAKE TORCH: OFF"); shakeTile.setOn(on)
    }

    private fun toggleShake() {
        if (Build.VERSION.SDK_INT < 23) { toast("Needs Android 6 or newer"); return }
        val on = !Util.pref(this).getBoolean("shake_on", false)
        Util.pref(this).edit().putBoolean("shake_on", on).apply()
        if (on) { ShakeService.start(this); toast("Shake the phone twice = flashlight. Long-press this tile for options.") }
        else { ShakeService.stop(this); toast("Shake flashlight OFF") }
        syncShakeTile()
    }

    private fun shakeOptions() {
        val p = Util.pref(this)
        val names = arrayOf("Low (hard shake)", "Medium", "High (light shake)")
        val lvl = p.getInt("shake_lvl", 1).coerceIn(0, 2)
        val wl = p.getBoolean("shake_wl", false)
        val items = arrayOf("Sensitivity: ${names[lvl]}   (tap to change)",
            "Works with screen off: ${if (wl) "ON" else "OFF"}   (tap to change, ON uses more battery)")
        android.app.AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Shake flashlight")
            .setItems(items) { _, w ->
                if (w == 0) p.edit().putInt("shake_lvl", (lvl + 1) % 3).apply() else p.edit().putBoolean("shake_wl", !wl).apply()
                if (Build.VERSION.SDK_INT >= 23 && p.getBoolean("shake_on", false)) { ShakeService.stop(this); h.postDelayed({ ShakeService.start(this) }, 400) }
                toast("Saved")
            }.show()
    }

    private fun toggleOverlay() {
        if (OverlayService.running) { stopService(Intent(this, OverlayService::class.java)); ovBtn.setLabel("START OVERLAY"); ovBtn.setOn(false) }
        else startOverlay(true)
    }

    private fun startOverlay(say: Boolean) {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { toast("Enable 'Display over other apps' first"); return }
        val i = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        ovBtn.setLabel("STOP OVERLAY"); ovBtn.setOn(true)
        if (say) toast("Overlay started. Tap the side tab for the panel. If it hides: tap the left edge 3 times, or notification > Show side tab.")
    }

    override fun onDestroy() { alive = false; meter.stop(); h.removeCallbacksAndMessages(null); super.onDestroy() }
}
