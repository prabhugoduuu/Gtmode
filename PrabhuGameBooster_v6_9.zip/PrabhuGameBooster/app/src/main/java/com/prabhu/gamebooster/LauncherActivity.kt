package com.prabhu.gamebooster

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ScrollView
import android.graphics.drawable.GradientDrawable
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

private const val MP = ViewGroup.LayoutParams.MATCH_PARENT
private const val WC = ViewGroup.LayoutParams.WRAP_CONTENT

/** Launcher look: layout, icon shape, ring, names, size (all saved). */
object LStyle {
    const val GRID = 0; const val HONEY = 1; const val LIST = 2; const val COMPACT = 3; const val LARGE = 4
    val LAYOUTS = arrayOf("Grid", "Honeycomb bubbles", "List", "Compact (no names)", "Large icons")
    val SHAPES = arrayOf("Rounded square", "Circle", "Squircle", "Square", "Hexagon")
    val SIZES = arrayOf("Small", "Medium", "Large")
    private fun oldFlat(c: Context): Boolean {
        val p = Util.pref(c); return p.contains("launcher_bubble") && !p.getBoolean("launcher_bubble", true)
    }
    fun layout(c: Context): Int {
        val p = Util.pref(c)
        if (!p.contains("l_layout") && oldFlat(c)) return GRID
        return p.getInt("l_layout", HONEY).coerceIn(0, LAYOUTS.size - 1)
    }
    fun shape(c: Context): Int {
        val p = Util.pref(c)
        if (!p.contains("l_shape") && oldFlat(c)) return 0
        return p.getInt("l_shape", 1).coerceIn(0, SHAPES.size - 1)
    }
    fun ring(c: Context) = Util.pref(c).getBoolean("l_ring", true)
    fun names(c: Context) = Util.pref(c).getBoolean("l_names", true)
    fun size(c: Context) = Util.pref(c).getInt("l_size", 1).coerceIn(0, 2)
}

/** Saved home-screen layout: pages of app packages + a small dock. */
object HomeData {
    private const val K_PAGES = "home_pages"
    private const val K_DOCK = "home_dock"
    fun has(c: Context) = Util.pref(c).contains(K_PAGES)
    fun pages(c: Context): MutableList<MutableList<String>> {
        val s = Util.pref(c).getString(K_PAGES, "") ?: ""
        return s.split(";").map { p -> p.split(",").filter { it.isNotBlank() }.toMutableList() }.toMutableList()
    }
    fun savePages(c: Context, p: List<List<String>>) {
        Util.pref(c).edit().putString(K_PAGES, p.joinToString(";") { it.joinToString(",") }).apply()
    }
    fun dock(c: Context): MutableList<String> =
        (Util.pref(c).getString(K_DOCK, "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()
    fun saveDock(c: Context, d: List<String>) { Util.pref(c).edit().putString(K_DOCK, d.joinToString(",")).apply() }
}

/**
 * GT Launcher.  HOME mode: swipe left/right between as many pages as you like, each with the apps you chose + a dock.
 * DRAWER mode: swipe up (or tap the ▦ button) to see ALL apps with search.
 * Long-press any app: change logo / rename / add to home / move page / dock / hide / info / uninstall.
 */
class LauncherActivity : Activity() {
    private class Entry(val pkg: String, val label: String, val bmp: Bitmap)

    /** Horizontal pager that snaps to whole pages. */
    private class Pager(c: Context) : HorizontalScrollView(c) {
        var onPage: ((Int) -> Unit)? = null
        private var flung = false
        init { isHorizontalScrollBarEnabled = false; isFillViewport = true; overScrollMode = OVER_SCROLL_NEVER }
        private fun count(): Int = (getChildAt(0) as? ViewGroup)?.childCount ?: 0
        fun current(): Int = if (width == 0) 0 else Math.round(scrollX.toFloat() / width)
        fun snap(p: Int) { smoothScrollTo(p.coerceIn(0, maxOf(0, count() - 1)) * width, 0) }
        override fun fling(velocityX: Int) {
            flung = true
            val base = if (width == 0) 0 else scrollX / width
            snap(if (velocityX > 0) base + 1 else base)
        }
        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) flung = false
            val r = super.onTouchEvent(ev)
            if ((ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) && !flung) snap(current())
            return r
        }
        override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
            super.onScrollChanged(l, t, oldl, oldt); onPage?.invoke(current())
        }
    }

    private class Act(val label: String, val run: () -> Unit)

    private var all: List<Entry> = emptyList()
    private var shown: List<Entry> = emptyList()
    private var byPkg: Map<String, Entry> = emptyMap()
    private var showHidden = false
    private var curPage = 0
    private var cap = 20
    private var drawerOpen = false
    private lateinit var drawerScroll: ScrollView
    private lateinit var drawerList: LinearLayout
    private lateinit var search: EditText
    private lateinit var homeLayer: LinearLayout
    private lateinit var drawerLayer: LinearLayout
    private lateinit var pager: Pager
    private lateinit var pageHolder: LinearLayout
    private lateinit var dots: LinearLayout
    private lateinit var dockRow: LinearLayout
    private lateinit var swipe: GestureDetector
    private val placeholder: Bitmap by lazy { Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888) }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { reload() }
    }

    private fun dp(v: Int) = Util.dp(this, v)
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Apps.load(this)
        Util.initTheme(this)
        if (!HomeData.has(this)) HomeData.savePages(this, listOf(Apps.list(this) + packageName))

        val root = FrameLayout(this).apply { setBackgroundColor(Color.argb(90, 0, 0, 0)); isFocusableInTouchMode = true }

        // ---------------- HOME (pages + dock) ----------------
        homeLayer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(12), 0) }
        top.addView(barBtn("⚡") { startActivity(Intent(this, MainActivity::class.java)) })
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(barBtn("⋮") { homeMenu() })
        homeLayer.addView(top, LinearLayout.LayoutParams(MP, WC))

        pager = Pager(this)
        pageHolder = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        pager.addView(pageHolder, FrameLayout.LayoutParams(WC, MP))
        pager.onPage = { p -> if (p != curPage) { curPage = p; updateDots() } }
        homeLayer.addView(pager, LinearLayout.LayoutParams(MP, 0, 1f))

        dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        homeLayer.addView(dots, LinearLayout.LayoutParams(MP, WC))
        dockRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4)); background = Util.glass(this@LauncherActivity, 24)
        }
        homeLayer.addView(dockRow, LinearLayout.LayoutParams(MP, WC).apply { setMargins(dp(12), dp(4), dp(12), dp(10)) })
        root.addView(homeLayer, FrameLayout.LayoutParams(MP, MP))

        // ---------------- DRAWER (all apps + search) ----------------
        drawerLayer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.argb(232, 5, 7, 13))
            setPadding(dp(10), dp(8), dp(10), dp(4)); visibility = View.GONE
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        search = EditText(this).apply {
            hint = "Search apps"; setHintTextColor(Util.MUTED); setTextColor(Color.WHITE); textSize = 13f
            setSingleLine(); setPadding(dp(14), dp(9), dp(14), dp(9)); background = Util.glass(this@LauncherActivity, 20)
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { applyFilter() }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
        }
        bar.addView(search, LinearLayout.LayoutParams(0, WC, 1f))
        bar.addView(barBtn("⌄") { closeDrawer() })
        bar.addView(barBtn("⋮") { drawerMenu() })
        drawerLayer.addView(bar, LinearLayout.LayoutParams(MP, WC))
        drawerList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(20)) }
        drawerScroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(drawerList, ViewGroup.LayoutParams(MP, WC)) }
        drawerLayer.addView(drawerScroll, LinearLayout.LayoutParams(MP, 0, 1f).apply { topMargin = dp(8) })
        root.addView(drawerLayer, FrameLayout.LayoutParams(MP, MP))
        setContentView(root)
        root.requestFocus()
        if (intent?.getBooleanExtra("open_style", false) == true) { intent.removeExtra("open_style"); window.decorView.post { styleDialog() } }

        // swipe UP on the home screen = open the drawer
        swipe = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (!drawerOpen && e1 != null && vy < -1200f && abs(vy) > abs(vx) * 1.5f && e1.y - e2.y > dp(80)) openDrawer()
                return false
            }
        })
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!drawerOpen) swipe.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun barBtn(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        background = Util.glass(this@LauncherActivity, 20)
        layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply { leftMargin = dp(8) }
        setOnClickListener { onClick() }
    }


    override fun onConfigurationChanged(c: Configuration) { super.onConfigurationChanged(c); rebuildDrawer(); rebuildHome() }

    override fun onStart() {
        super.onStart()
        Apps.load(this)
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        }
        try { registerReceiver(pkgReceiver, f) } catch (e: Exception) {}
        reload()
    }

    override fun onStop() {
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) {}
        super.onStop()
    }

    // Home button pressed again: close drawer, back to the first page
    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        if (i?.getBooleanExtra("open_style", false) == true) { i.removeExtra("open_style"); styleDialog(); return }
        closeDrawer(); search.setText("")
        curPage = 0; pager.smoothScrollTo(0, 0)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerOpen) { if (search.text.isNotEmpty()) search.setText("") else closeDrawer() }
    }

    // ---------------- drawer open / close ----------------
    private fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        search.setText(""); drawerScroll.scrollTo(0, 0)
        drawerLayer.visibility = View.VISIBLE
        drawerLayer.translationY = resources.displayMetrics.heightPixels.toFloat()
        drawerLayer.animate().translationY(0f).setDuration(220).start()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        try {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        } catch (e: Exception) {}
        search.clearFocus()
        drawerLayer.animate().translationY(resources.displayMetrics.heightPixels.toFloat()).setDuration(200)
            .withEndAction { if (!drawerOpen) drawerLayer.visibility = View.GONE }.start()
    }

    // ---------------- loading apps ----------------
    private fun reload() {
        Thread {
            val hidden = Apps.hidden(this)
            val items = ArrayList<Entry>()
            items.add(Entry(packageName, Apps.label(this, packageName), Apps.iconBitmap(this, packageName, 144)))
            for (a in Apps.launchables(this)) items.add(Entry(a.pkg, Apps.label(this, a.pkg), Apps.iconBitmap(this, a.pkg, 144)))
            items.sortBy { it.label.lowercase() }
            runOnUiThread {
                if (!isFinishing) {
                    byPkg = items.associateBy { it.pkg }
                    all = items.filter { showHidden || it.pkg !in hidden || it.pkg == packageName }
                    applyFilter(); rebuildHome()
                }
            }
        }.start()
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        shown = if (q.isEmpty()) all else all.filter { it.label.lowercase().contains(q) }
        rebuildDrawer()
    }

    // ---------------- style helpers ----------------
    private fun lay() = LStyle.layout(this)
    private fun showNames() = LStyle.names(this) && lay() != LStyle.COMPACT
    private fun iconSizeDp(): Int {
        val base = when (LStyle.size(this)) { 0 -> 46; 2 -> 64; else -> 54 }
        return when (lay()) { LStyle.LARGE -> base + 18; LStyle.COMPACT -> base - 6; else -> base }
    }
    private fun cellW(): Int = dp(iconSizeDp() + when (lay()) { LStyle.HONEY -> 36; LStyle.LARGE -> 40; LStyle.COMPACT -> 16; else -> 30 })
    private fun rowH(): Int = if (lay() == LStyle.LIST) dp(58) else dp(iconSizeDp() + 10 + (if (showNames()) 26 else 12))

    private fun rebuildDrawer() {
        drawerList.removeAllViews()
        for (r in buildViews(shown, resources.displayMetrics.widthPixels - dp(20))) drawerList.addView(r)
    }

    /** App views for the chosen layout. Honeycomb = every second row has one cell less, so it sits half a cell sideways. */
    private fun buildViews(list: List<Entry>, availW: Int): List<View> {
        val out = ArrayList<View>()
        if (lay() == LStyle.LIST) {
            for (e in list) out.add(listRow(e).also { it.layoutParams = LinearLayout.LayoutParams(MP, WC).apply { setMargins(dp(4), dp(3), dp(4), dp(3)) } })
            return out
        }
        val cp = cellW()
        val cols = maxOf(2, availW / cp)
        val honey = lay() == LStyle.HONEY
        var i = 0; var r = 0
        while (i < list.size) {
            val n = if (honey && r % 2 == 1) cols - 1 else cols
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_HORIZONTAL }
            for (k in 0 until n) {
                val e = list.getOrNull(i + k)
                if (e != null) row.addView(cell(e, showNames()), LinearLayout.LayoutParams(cp, WC))
            }
            out.add(row); i += n; r++
        }
        return out
    }

    /** Ring drawable that matches the icon shape (null = no ring: hexagon or ring switched off). */
    private fun ringDrawable(shape: Int, sizeDp: Int): GradientDrawable? {
        if (!LStyle.ring(this) || shape == 4) return null
        return GradientDrawable().apply {
            this.shape = if (shape == 1) GradientDrawable.OVAL else GradientDrawable.RECTANGLE
            cornerRadius = dp(sizeDp) * (when (shape) { 2 -> 0.36f; 3 -> 0.06f; else -> 0.22f })
            setColor(Util.alpha(Color.WHITE, 0x1F)); setStroke(dp(1), Util.alpha(Util.ACC, 0x99))
        }
    }

    private fun iconFor(bmp: Bitmap, sizeDp: Int = iconSizeDp()): View {
        val sh = LStyle.shape(this)
        val ic = AppPicker.iconView(this, "", sizeDp, bmp, sh)
        val rd = ringDrawable(sh, sizeDp + 10) ?: return ic
        val box = FrameLayout(this).apply { background = rd; layoutParams = LinearLayout.LayoutParams(dp(sizeDp + 10), dp(sizeDp + 10)) }
        box.addView(ic, FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp), Gravity.CENTER))
        return box
    }

    /** One app cell (icon + optional name). */
    private fun cell(e: Entry, label: Boolean): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(2), dp(5), dp(2), dp(3))
        addView(iconFor(e.bmp))
        if (label) addView(TextView(this@LauncherActivity).apply {
            textSize = if (lay() == LStyle.LARGE) 12f else 10.5f; setTextColor(Color.WHITE); maxLines = 1; gravity = Gravity.CENTER
            ellipsize = TextUtils.TruncateAt.END; setShadowLayer(4f, 0f, 1f, Color.BLACK); setPadding(0, dp(4), 0, 0)
            text = e.label
        })
        setOnClickListener { launch(e) }
        setOnLongClickListener { itemMenu(e); true }
    }

    /** One row of the LIST layout. */
    private fun listRow(e: Entry): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(10), dp(6), dp(10), dp(6)); background = Util.glass(this@LauncherActivity, 14)
        val ic = iconFor(e.bmp, 40)
        (ic.layoutParams as LinearLayout.LayoutParams).rightMargin = dp(12)
        addView(ic)
        addView(TextView(this@LauncherActivity).apply {
            text = e.label; textSize = 14f; typeface = Util.BOLD; setTextColor(Color.WHITE); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, WC, 1f))
        setOnClickListener { launch(e) }
        setOnLongClickListener { itemMenu(e); true }
    }

    private fun styleDialog() {
        val p = Util.pref(this)
        val items = arrayOf(
            "Layout:  ${LStyle.LAYOUTS[LStyle.layout(this)]}",
            "Icon shape:  ${LStyle.SHAPES[LStyle.shape(this)]}",
            "Ring around icons:  ${if (LStyle.ring(this)) "ON" else "OFF"}",
            "App names:  ${if (LStyle.names(this)) "ON" else "OFF"}",
            "Icon size:  ${LStyle.SIZES[LStyle.size(this)]}")
        themed().setTitle("Launcher style  (tap an option = next choice)").setItems(items) { _, w ->
            val e = p.edit()
            when (w) {
                0 -> e.putInt("l_layout", (LStyle.layout(this) + 1) % LStyle.LAYOUTS.size)
                1 -> e.putInt("l_shape", (LStyle.shape(this) + 1) % LStyle.SHAPES.size)
                2 -> e.putBoolean("l_ring", !LStyle.ring(this))
                3 -> e.putBoolean("l_names", !LStyle.names(this))
                else -> e.putInt("l_size", (LStyle.size(this) + 1) % 3)
            }
            e.apply()
            rebuildDrawer(); rebuildHome(); styleDialog()
        }.setPositiveButton("DONE", null).show()
    }

    // ---------------- HOME pages ----------------
    private fun exists(pkg: String) = byPkg.containsKey(pkg)

    private fun rebuildHome() {
        if (byPkg.isEmpty()) return
        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val cols = if (lay() == LStyle.LIST) 1 else maxOf(2, (w - dp(16)) / cellW())
        val rows = maxOf(2, (dm.heightPixels - dp(260)) / rowH())
        cap = if (lay() == LStyle.HONEY) cols * rows - rows / 2 else cols * rows

        val pages = HomeData.pages(this)
        var changed = false
        for (p in pages) {
            val itr = p.iterator()
            while (itr.hasNext()) { if (!exists(itr.next())) { itr.remove(); changed = true } }
        }
        if (changed) HomeData.savePages(this, pages)

        pageHolder.removeAllViews()
        for (list in pages) {
            val page = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), 0)
                setOnLongClickListener { homeMenu(); true }
            }
            for (r in buildViews(list.mapNotNull { byPkg[it] }, w - dp(16))) page.addView(r)
            pageHolder.addView(page, LinearLayout.LayoutParams(w, MP))
        }
        curPage = curPage.coerceIn(0, pages.size - 1)
        pager.post { pager.scrollTo(curPage * w, 0) }
        updateDots()

        dockRow.removeAllViews()
        for (pkg in HomeData.dock(this).filter { exists(it) }.take(4)) {
            byPkg[pkg]?.let { dockRow.addView(cell(it, false), LinearLayout.LayoutParams(0, WC, 1f)) }
        }
        dockRow.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER; setPadding(dp(2), dp(6), dp(2), dp(4))
            addView(TextView(this@LauncherActivity).apply {
                text = "▦"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                background = ringDrawable(LStyle.shape(this@LauncherActivity), 54) ?: Util.glass(this@LauncherActivity, 14)
                layoutParams = LinearLayout.LayoutParams(dp(54), dp(54))
            })
            setOnClickListener { openDrawer() }
        }, LinearLayout.LayoutParams(0, WC, 1f))
    }

    private fun updateDots() {
        val n = pageHolder.childCount
        dots.removeAllViews()
        for (i in 0 until n) dots.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(7), dp(7)).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }
            background = Util.round(this@LauncherActivity, if (i == curPage) Color.WHITE else Util.alpha(Color.WHITE, 0x55), 4)
        })
    }

    private fun addToHome(pkg: String) {
        val pages = HomeData.pages(this)
        if (pages.any { pkg in it }) { toast("Already on the home screen"); return }
        var idx = curPage.coerceIn(0, pages.size - 1)
        if (pages[idx].size >= cap) {
            idx = pages.indexOfFirst { it.size < cap }
            if (idx < 0) { pages.add(mutableListOf()); idx = pages.size - 1 }
        }
        pages[idx].add(pkg)
        HomeData.savePages(this, pages)
        toast("Added to home page ${idx + 1}")
        rebuildHome()
    }

    private fun removeFromHome(pkg: String) {
        val pages = HomeData.pages(this)
        pages.forEach { it.remove(pkg) }
        HomeData.savePages(this, pages); rebuildHome()
    }

    private fun moveHome(pkg: String, delta: Int) {
        val pages = HomeData.pages(this)
        val from = pages.indexOfFirst { pkg in it }
        if (from < 0) return
        val to = from + delta
        if (to < 0) { toast("Already the first page"); return }
        if (to >= pages.size) pages.add(mutableListOf())
        if (pages[to].size >= cap) { toast("That page is full"); return }
        pages[from].remove(pkg); pages[to].add(pkg)
        HomeData.savePages(this, pages)
        curPage = to; rebuildHome(); toast("Moved to page ${to + 1}")
    }

    private fun addPage() {
        val pages = HomeData.pages(this)
        pages.add(mutableListOf())
        HomeData.savePages(this, pages)
        curPage = pages.size - 1; rebuildHome(); toast("Page ${pages.size} added")
    }

    private fun deletePage() {
        val pages = HomeData.pages(this)
        if (pages.size <= 1) { toast("You need at least one page"); return }
        val i = curPage.coerceIn(0, pages.size - 1)
        themed().setTitle("Delete page ${i + 1}?").setMessage("The apps stay in the drawer, only this page is removed.")
            .setPositiveButton("DELETE") { _, _ ->
                val pg = HomeData.pages(this)
                if (i < pg.size && pg.size > 1) { pg.removeAt(i); HomeData.savePages(this, pg); curPage = maxOf(0, i - 1); rebuildHome() }
            }.setNegativeButton("CANCEL", null).show()
    }

    private fun addToDock(pkg: String) {
        val d = HomeData.dock(this)
        if (pkg in d) return
        if (d.size >= 4) { toast("Dock is full (4 apps). Remove one first."); return }
        d.add(pkg); HomeData.saveDock(this, d); rebuildHome(); toast("Added to dock")
    }

    private fun removeFromDock(pkg: String) {
        val d = HomeData.dock(this); d.remove(pkg); HomeData.saveDock(this, d); rebuildHome()
    }

    // ---------------- open an app ----------------
    private fun launch(e: Entry) {
        closeDrawer()
        if (e.pkg == packageName) { startActivity(Intent(this, MainActivity::class.java)); return }
        if (e.pkg in Apps.list(this)) {
            // one of your booster apps: select it, clean RAM, GT intro, open
            Apps.setActive(this, e.pkg)
            Util.clean(this)
            GtIntro.play(this, { Util.launchGame(this, e.pkg) }) { toast("${e.label} not installed") }
            return
        }
        val li = packageManager.getLaunchIntentForPackage(e.pkg)
        if (li != null) startActivity(li) else toast("Cannot open ${e.label}")
    }

    // ---------------- menus ----------------
    private fun themed(): AlertDialog.Builder = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun showActs(title: String?, acts: List<Act>) {
        val b = themed()
        if (title != null) b.setTitle(title)
        b.setItems(acts.map { it.label }.toTypedArray()) { _, which -> acts[which].run() }.show()
    }

    private fun itemMenu(e: Entry) {
        val hid = e.pkg in Apps.hidden(this)
        val listed = e.pkg in Apps.list(this)
        val pages = HomeData.pages(this)
        val pageIdx = pages.indexOfFirst { e.pkg in it }
        val inDock = e.pkg in HomeData.dock(this)
        val acts = ArrayList<Act>()
        acts.add(Act("🖼  Change logo (from gallery)") {
            AppPicker.pendingPkg = e.pkg
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }
            try { startActivityForResult(Intent.createChooser(i, "Choose logo"), AppPicker.REQ_LOGO) }
            catch (ex: Exception) { toast("No gallery / file picker found") }
        })
        acts.add(Act("↺  Reset to original logo") { Apps.clearIcon(this, e.pkg); toast("Original logo restored"); reload() })
        acts.add(Act("✏  Rename") {
            val et = EditText(this).apply { setText(e.label); setSingleLine(); setSelectAllOnFocus(true) }
            themed().setTitle("Rename").setView(et)
                .setPositiveButton("SAVE") { _, _ -> Apps.setLabel(this, e.pkg, et.text.toString()); Apps.load(this); reload() }
                .setNegativeButton("CANCEL", null).show()
        })
        if (pageIdx >= 0) {
            acts.add(Act("✖  Remove from home screen") { removeFromHome(e.pkg) })
            acts.add(Act("⬅  Move to previous page") { moveHome(e.pkg, -1) })
            acts.add(Act("➡  Move to next page") { moveHome(e.pkg, 1) })
        } else acts.add(Act("📌  Add to home screen") { addToHome(e.pkg) })
        if (inDock) acts.add(Act("▽  Remove from dock") { removeFromDock(e.pkg) })
        else acts.add(Act("⬇  Add to dock") { addToDock(e.pkg) })
        acts.add(Act(if (hid) "👁  Unhide from drawer" else "🙈  Hide from drawer") {
            Apps.setHidden(this, e.pkg, !hid); toast(if (hid) "App unhidden" else "Hidden from drawer (⋮ > Show hidden apps)"); reload()
        })
        acts.add(Act(if (listed) "➖  Remove from booster list" else "🎮  Add to booster (game) list") {
            if (listed) Apps.unlist(this, e.pkg) else Apps.add(this, e.pkg)
            toast(if (listed) "Removed from booster" else "Added to booster")
        })
        acts.add(Act("ℹ  App info") {
            try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${e.pkg}"))) }
            catch (ex: Exception) { toast("Cannot open app info") }
        })
        if (e.pkg != packageName) acts.add(Act("🗑  Uninstall") {
            try { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${e.pkg}"))) } catch (ex: Exception) { toast("Cannot uninstall") }
        })
        showActs(e.label, acts)
    }

    private fun wallpaper() {
        try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper")) }
        catch (ex: Exception) { toast("No wallpaper picker found") }
    }

    private fun homeSettings() {
        try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        catch (ex: Exception) { toast("Open Settings > Apps > Default apps > Home app") }
    }

    private fun homeMenu() {
        showActs(null, listOf(
            Act("🧩  Open app drawer") { openDrawer() },
            Act("🎨  Launcher style (layout, icon shape...)") { styleDialog() },
            Act("➕  Add new page") { addPage() },
            Act("🗑  Delete this page (page ${curPage + 1})") { deletePage() },
            Act("🖼  Change wallpaper") { wallpaper() },
            Act("⚡  Booster dashboard") { startActivity(Intent(this, MainActivity::class.java)) },
            Act("🏠  Default home app settings") { homeSettings() }))
    }

    private fun drawerMenu() {
        showActs(null, listOf(
            Act("🎨  Launcher style (layout, icon shape...)") { styleDialog() },
            Act(if (showHidden) "🙈  Stop showing hidden apps" else "👁  Show hidden apps") { showHidden = !showHidden; reload() },
            Act("⚡  Booster dashboard") { startActivity(Intent(this, MainActivity::class.java)) },
            Act("🖼  Change wallpaper") { wallpaper() },
            Act("🏠  Default home app settings") { homeSettings() }))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != AppPicker.REQ_LOGO) return
        val pkg = AppPicker.pendingPkg; val u = data?.data
        if (res == RESULT_OK && pkg != null && u != null) {
            toast(if (Apps.setIconFromUri(this, pkg, u)) "Logo changed" else "Could not read that image")
            reload()
        }
        AppPicker.pendingPkg = null
    }
}
